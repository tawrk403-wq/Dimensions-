# DIMENSIONS Security Specification & Red-Team Attack Matrix

## 1. Security Pillars & Data Invariants
- **Default Deny**: All unspecified collections/subcollections return `false`.
- **Identity & Ownership**:
  - `users/{userId}`: Publicly readable profile/stats/achievements (strictly zero PII — `email` is rejected if included on `users/{userId}`). Writable only when `request.auth.uid == userId` and `uid` matches.
  - `users/{userId}/private/{docId}`: Strictly owner-only (`request.auth.uid == userId`) for both read and write; `role` must stay `'player'` and cannot be escalated.
  - `users/{userId}/saves/{slotId}`: Strictly owner-only (`request.auth.uid == userId`), `slotId` constrained to `['auto', 'slot1', 'slot2', 'slot3']`, `chapter` in `[1, 2, 3]`, `difficulty` in `['normal', 'hard', 'nightmare']`, `clientUpdatedAtMs` bounded integer/number >= 0, `progress` size bounded.
  - `leaderboard/{entryId}`: Publicly readable; writable only when `entryId == request.auth.uid` and `request.resource.data.uid == request.auth.uid`. Score bounded `0..1000000`, bottles `0..9`, letters `0..13`, truthClues `0..10`, endingId in `['bad', 'normal', 'good', 'true', 'secret']`.
- **Schema & Type Strictness**:
  - `hasOnly(...)` and `hasAll(...)` enforced on all writes to prevent extra injected keys or missing invariants.
  - Server-derived `updatedAt` and immutable `createdAt` / `uid` enforced on updates.
  - Boot connection test doc `/test/connection` allowed read-only (`allow get: if true; allow list, write: if false;`) for offline/online server connectivity probing.

## 2. Dirty Dozen Attack Payloads Tested
1. **Unauthenticated read of private save**: `GET /users/victim/saves/auto` with `auth == null` -> **DENY**.
2. **Cross-user read of private account PII**: `GET /users/victim/private/account` as `attacker` -> **DENY**.
3. **Cross-user save overwrite**: `WRITE /users/victim/saves/slot1` as `attacker` -> **DENY**.
4. **Role privilege escalation**: `UPDATE /users/attacker/private/account` setting `role: 'admin'` -> **DENY**.
5. **UID spoofing in leaderboard**: `CREATE /leaderboard/victim` as `attacker` -> **DENY**.
6. **Leaderboard score overflow / negative injection**: `CREATE /leaderboard/attacker` with `score: 999999999` or `score: -50` -> **DENY**.
7. **PII leak into public profile**: `CREATE /users/attacker` including `email: 'x@y.com'` -> **DENY** (`hasOnly` drops unapproved keys).
8. **Invalid save slot ID or chapter injection**: `CREATE /users/attacker/saves/hacked` or `chapter: 99` -> **DENY**.
9. **Immutable `uid` / `createdAt` tampering on update**: `UPDATE /users/attacker` mutating `uid` or `createdAt` -> **DENY**.
10. **Bogus arbitrary collections**: `READ/WRITE /admin/config` or `/secrets/keys` -> **DENY**.
11. **Oversized displayName / stats injection**: `CREATE /users/attacker` with 500-char `displayName` -> **DENY**.
12. **Client timestamp/field spoofing**: `UPDATE /leaderboard/attacker` with `bottlesCollected: 999` -> **DENY**.
