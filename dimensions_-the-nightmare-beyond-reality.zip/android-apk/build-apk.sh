#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="$(pwd)"
export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
export PATH="$ANDROID_HOME/build-tools/34.0.0:$PATH"

KEYSTORE_PATH="$APP_ROOT/android-apk/dimensions-release.jks"
KEY_ALIAS="dimensions"
KEY_PASS="dimensions2026"

# 1. Ensure persistent release keystore exists (so updates always share one signing certificate)
if [ ! -f "$KEYSTORE_PATH" ]; then
  keytool -genkeypair -noprompt \
    -keystore "$KEYSTORE_PATH" \
    -storetype PKCS12 \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass "$KEY_PASS" \
    -keypass "$KEY_PASS" \
    -dname "CN=DIMENSIONS Studio, OU=Game Engineering, O=DIMENSIONS, L=Lahore, ST=Punjab, C=PK"
fi

# 2. Build fresh production web bundle (dist/)
rm -rf dist && npm run build

# 3. Prepare clean Capacitor 6 Android build workspace in /tmp/cap-build
BUILD_DIR="/tmp/cap-build"
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

cp "$APP_ROOT/android-apk/capacitor.config.json" "$BUILD_DIR/capacitor.config.json"
sed -i 's|"../dist"|"dist"|g' "$BUILD_DIR/capacitor.config.json"
cp -r dist "$BUILD_DIR/dist"

cd "$BUILD_DIR"
npm init -y >/dev/null 2>&1
npm install @capacitor/core@6 @capacitor/cli@6 @capacitor/android@6 >/dev/null 2>&1
npx cap add android
npx cap sync android

# 4. Install hardened AndroidManifest.xml and MainActivity.java
cp "$APP_ROOT/android-apk/AndroidManifest.landscape.xml" android/app/src/main/AndroidManifest.xml
cp "$APP_ROOT/android-apk/MainActivity.java" android/app/src/main/java/com/dimensions/nightmare/MainActivity.java

# 5. Generate density-accurate adaptive & legacy launcher icons + landscape splash
cat > android/app/src/main/res/values/ic_launcher_background.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#050608</color>
</resources>
EOF

resize_icon() {
  local src="$1"
  local size="$2"
  local dest="$3"
  if command -v convert >/dev/null 2>&1; then
    convert "$src" -resize "${size}x${size}" PNG32:"$dest"
  else
    cp "$src" "$dest"
  fi
}

resize_icon "$APP_ROOT/public/pwa-512x512.png" 48 android/app/src/main/res/mipmap-mdpi/ic_launcher.png
resize_icon "$APP_ROOT/public/pwa-512x512.png" 48 android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png
resize_icon "$APP_ROOT/public/pwa-maskable-512x512.png" 108 android/app/src/main/res/mipmap-mdpi/ic_launcher_foreground.png

resize_icon "$APP_ROOT/public/pwa-512x512.png" 72 android/app/src/main/res/mipmap-hdpi/ic_launcher.png
resize_icon "$APP_ROOT/public/pwa-512x512.png" 72 android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png
resize_icon "$APP_ROOT/public/pwa-maskable-512x512.png" 162 android/app/src/main/res/mipmap-hdpi/ic_launcher_foreground.png

resize_icon "$APP_ROOT/public/pwa-512x512.png" 96 android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
resize_icon "$APP_ROOT/public/pwa-512x512.png" 96 android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png
resize_icon "$APP_ROOT/public/pwa-maskable-512x512.png" 216 android/app/src/main/res/mipmap-xhdpi/ic_launcher_foreground.png

resize_icon "$APP_ROOT/public/pwa-512x512.png" 144 android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
resize_icon "$APP_ROOT/public/pwa-512x512.png" 144 android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png
resize_icon "$APP_ROOT/public/pwa-maskable-512x512.png" 324 android/app/src/main/res/mipmap-xxhdpi/ic_launcher_foreground.png

resize_icon "$APP_ROOT/public/pwa-512x512.png" 192 android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
resize_icon "$APP_ROOT/public/pwa-512x512.png" 192 android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png
resize_icon "$APP_ROOT/public/pwa-maskable-512x512.png" 432 android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png

if [ -f "$APP_ROOT/public/splash-landscape.jpg" ]; then
  rm -f android/app/src/main/res/drawable/splash.png
  cp "$APP_ROOT/public/splash-landscape.jpg" android/app/src/main/res/drawable/splash.jpg
  for sdir in android/app/src/main/res/drawable-land-*; do
    if [ -d "$sdir" ]; then
      rm -f "$sdir/splash.png"
      cp "$APP_ROOT/public/splash-landscape.jpg" "$sdir/splash.jpg"
    fi
  done
  for sdir in android/app/src/main/res/drawable-port-*; do
    if [ -d "$sdir" ]; then
      rm -f "$sdir/splash.png"
      if command -v convert >/dev/null 2>&1; then
        convert "$APP_ROOT/public/splash-landscape.jpg" -resize 720x720 -background "#050608" -gravity center -extent 720x1280 -quality 88 "$sdir/splash.jpg"
      else
        cp "$APP_ROOT/public/splash-landscape.jpg" "$sdir/splash.jpg"
      fi
    fi
  done
fi

# 6. Configure Release signing + bumped versionCode/versionName in android/app/build.gradle
KEYSTORE_PATH="$KEYSTORE_PATH" KEY_PASS="$KEY_PASS" KEY_ALIAS="$KEY_ALIAS" python3 - << 'PYEOF'
import os
from pathlib import Path

gradle_file = Path("android/app/build.gradle")
text = gradle_file.read_text()
text = text.replace("versionCode 1", "versionCode 2")
text = text.replace('versionName "1.0"', 'versionName "1.2.0"')

ks_path = os.environ["KEYSTORE_PATH"]
ks_pass = os.environ["KEY_PASS"]
ks_alias = os.environ["KEY_ALIAS"]

signing_block = f"""    signingConfigs {{
        release {{
            storeFile file("{ks_path}")
            storePassword "{ks_pass}"
            keyAlias "{ks_alias}"
            keyPassword "{ks_pass}"
        }}
    }}
    buildTypes {{
        release {{
            signingConfig signingConfigs.release"""

text = text.replace("    buildTypes {\n        release {", signing_block, 1)
text = text + "\nandroid { lint { checkReleaseBuilds false; abortOnError false } }\n"
gradle_file.write_text(text)
PYEOF

# 7. Compile signed Release APK + Release AAB sequentially (memory-capped for 4 GiB containers)
export GRADLE_OPTS="-Xmx512m -XX:MaxMetaspaceSize=256m"
cd android
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > local.properties
sed -i 's/-Xmx[0-9]*m/-Xmx512m/g' gradle.properties 2>/dev/null || true
printf '\norg.gradle.workers.max=1\norg.gradle.parallel=false\nkotlin.daemon.jvm.options=-Xmx256m\n' >> gradle.properties
chmod +x gradlew

./gradlew assembleRelease -x lintVitalAnalyzeRelease --no-daemon --max-workers=1 -Dorg.gradle.jvmargs="-Xmx512m -XX:MaxMetaspaceSize=256m"
./gradlew bundleRelease -x lintVitalAnalyzeRelease --no-daemon --max-workers=1 -Dorg.gradle.jvmargs="-Xmx512m -XX:MaxMetaspaceSize=256m"

# 8. Explicitly zipalign (4-byte page aligned) and sign with v1 + v2 + v3 schemes
RAW_APK="app/build/outputs/apk/release/app-release.apk"
ALIGNED_APK="app/build/outputs/apk/release/app-release-aligned.apk"
FINAL_APK="app/build/outputs/apk/release/DIMENSIONS-nightmare-signed.apk"
FINAL_AAB="app/build/outputs/bundle/release/app-release.aab"

zipalign -f -p 4 "$RAW_APK" "$ALIGNED_APK"
apksigner sign \
  --ks "$KEYSTORE_PATH" \
  --ks-key-alias "$KEY_ALIAS" \
  --ks-pass "pass:${KEY_PASS}" \
  --key-pass "pass:${KEY_PASS}" \
  --v1-signing-enabled true \
  --v2-signing-enabled true \
  --v3-signing-enabled true \
  --out "$FINAL_APK" \
  "$ALIGNED_APK"

zipalign -c -v 4 "$FINAL_APK" | tail -n 5
apksigner verify --verbose --print-certs "$FINAL_APK" | head -n 20

# 9. Publish signed Release APK & AAB into workspace folders
mkdir -p "$APP_ROOT/Taha'apk" "$APP_ROOT/android-apk"
cp "$FINAL_APK" "$APP_ROOT/android-apk/DIMENSIONS-nightmare.apk"
cp "$FINAL_APK" "$APP_ROOT/DIMENSIONS-nightmare.apk"
cp "$FINAL_APK" "$APP_ROOT/src/DIMENSIONS-nightmare.apk"
cp "$FINAL_APK" "$APP_ROOT/Taha'apk/DIMENSIONS-nightmare.apk"

cp "$FINAL_AAB" "$APP_ROOT/android-apk/DIMENSIONS-nightmare.aab"
cp "$FINAL_AAB" "$APP_ROOT/Taha'apk/DIMENSIONS-nightmare.aab"

echo "Release APK & AAB generated cleanly:"
ls -lh "$APP_ROOT/Taha'apk/DIMENSIONS-nightmare.apk" "$APP_ROOT/Taha'apk/DIMENSIONS-nightmare.aab"

