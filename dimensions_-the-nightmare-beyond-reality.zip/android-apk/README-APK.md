# Android Release APK & AAB (`DIMENSIONS: The Nightmare Beyond Reality`)

The signed, zipaligned Android **Release APK** (`DIMENSIONS-nightmare.apk`, `com.dimensions.nightmare`, `v1.2.0`, `versionCode 2`, `minSdk 22`, `targetSdk 34`) and **Android App Bundle** (`DIMENSIONS-nightmare.aab`) are built using **Capacitor 6**, **OpenJDK 17**, and **Android SDK 34** with `android:screenOrientation="sensorLandscape"`, sticky fullscreen immersive mode, hardware-accelerated WebView, and v1+v2+v3 APK signatures using the persistent release keystore (`android-apk/dimensions-release.jks`).

## Output Files & Direct Download Routes
- Release APK: `Taha'apk/DIMENSIONS-nightmare.apk`, `android-apk/DIMENSIONS-nightmare.apk`, `DIMENSIONS-nightmare.apk`
- Release AAB: `Taha'apk/DIMENSIONS-nightmare.aab`, `android-apk/DIMENSIONS-nightmare.aab`
- Direct HTTP downloads when server is running:
  - `/DIMENSIONS-nightmare.apk`
  - `/DIMENSIONS-nightmare.aab`

## Rebuild Locally or in CI
Requirements: **Node.js 18+**, **JDK 17+**, and **Android SDK (API 34)**.
```bash
bash android-apk/build-apk.sh
```
GitHub Actions workflow `.github/workflows/build-android-apk.yml` also automates this release build and uploads `DIMENSIONS-nightmare-apk` and `DIMENSIONS-nightmare-aab`.
