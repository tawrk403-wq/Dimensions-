import assert from 'node:assert/strict';
import fs from 'node:fs';

/**
 * Security Rules Structural & Dirty-Dozen Invariant Verification Suite
 * Verifies production firestore.rules guards against every vector in security_spec.md.
 */
const rulesText = fs.readFileSync('firestore.rules', 'utf8');

const requiredGuards = [
  'match /{document=**}',
  'allow read, write: if false',
  'match /users/{userId}',
  'allow list: if false',
  'match /private/account',
  'match /saves/{slotId}',
  'match /leaderboard/{entryId}',
  'isOwner(userId)',
  'isOwner(entryId)',
  'request.resource.data.uid == resource.data.uid',
  'request.resource.data.role == resource.data.role',
  'request.resource.data.createdAt == resource.data.createdAt',
  "val in ['auto', 'slot1', 'slot2', 'slot3']",
  "val in ['normal', 'hard', 'nightmare']",
  "val in ['bad', 'normal', 'good', 'true', 'secret']",
  'data.score is int && data.score >= 0 && data.score <= 1000000',
  'data.bottlesCollected is int && data.bottlesCollected >= 0 && data.bottlesCollected <= 9',
  'data.lettersCollected is int && data.lettersCollected >= 0 && data.lettersCollected <= 13',
];

for (const guard of requiredGuards) {
  assert.ok(rulesText.includes(guard), `Missing required security guard in firestore.rules: ${guard}`);
}

// Verify PII isolation: email is NOT permitted inside public /users/{userId}
const userProfileFn = rulesText.slice(
  rulesText.indexOf('function isValidUserProfile'),
  rulesText.indexOf('function isValidPrivateAccount')
);
assert.ok(!userProfileFn.includes("'email'"), 'Public user profile must NOT accept PII email field');

console.log(`ALL ${requiredGuards.length + 1} FIRESTORE SECURITY RULE INVARIANTS VERIFIED`);
