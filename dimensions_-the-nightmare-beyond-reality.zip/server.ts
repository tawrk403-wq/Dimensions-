import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Direct APK & AAB download endpoints (available on dev & production URLs)
  app.get('/DIMENSIONS-nightmare.apk', (_req, res) => {
    const apkPath = path.join(__dirname, 'android-apk', 'DIMENSIONS-nightmare.apk');
    if (!fs.existsSync(apkPath)) {
      res.status(404).send('APK build not found.');
      return;
    }
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', 'attachment; filename="DIMENSIONS-nightmare.apk"');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(apkPath);
  });

  app.get('/DIMENSIONS-nightmare.aab', (_req, res) => {
    const aabPath = path.join(__dirname, 'android-apk', 'DIMENSIONS-nightmare.aab');
    if (!fs.existsSync(aabPath)) {
      res.status(404).send('AAB build not found.');
      return;
    }
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', 'attachment; filename="DIMENSIONS-nightmare.aab"');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');
    res.sendFile(aabPath);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DIMENSIONS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
