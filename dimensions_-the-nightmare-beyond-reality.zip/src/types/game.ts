export type Language = 'en' | 'ur';
export type Difficulty = 'normal' | 'hard' | 'nightmare';
export type CameraPerspective = 'first' | 'third';
export type GraphicsQuality = 'auto' | 'low' | 'medium' | 'high' | 'ultra';
export type ChapterId = 1 | 2 | 3;
export type EndingId = 'bad' | 'normal' | 'good' | 'true' | 'secret';
export type SyncStatus = 'offline' | 'idle' | 'syncing' | 'synced' | 'error';

export type ScreenMode =
  | 'title'
  | 'playing'
  | 'paused'
  | 'cinematic'
  | 'ending'
  | 'gameover';

export type ItemCategory = 'key' | 'bottle' | 'letter' | 'supply' | 'artifact' | 'map';

export interface InventoryItem {
  id: string;
  category: ItemCategory;
  nameEn: string;
  nameUr: string;
  descEn: string;
  descUr: string;
  clueEn?: string;
  clueUr?: string;
  liquidColor?: string;
  symbol?: string;
  quantity: number;
  consumable?: boolean;
  combineWith?: string;
  combineResult?: string;
}

export interface LetterEntry {
  id: string;
  chapter: ChapterId;
  doorNumber?: number;
  titleEn: string;
  titleUr: string;
  authorEn: string;
  authorUr: string;
  bodyEn: string;
  bodyUr: string;
  isMisleading?: boolean;
  clueTag?: string;
}

export interface BottleEntry {
  id: string;
  doorNumber: number;
  nameEn: string;
  nameUr: string;
  liquidColor: string;
  symbol: string;
  labelEn: string;
  labelUr: string;
  secretHintEn: string;
  secretHintUr: string;
}

export type PuzzleType =
  | 'number_lock'
  | 'symbol_wheel'
  | 'bottle_altar'
  | 'sound_chime'
  | 'light_mirrors'
  | 'statue_alignment'
  | 'quantum_cipher';

export interface PuzzleDef {
  id: string;
  chapter: ChapterId;
  doorNumber?: number;
  type: PuzzleType;
  titleEn: string;
  titleUr: string;
  promptEn: string;
  promptUr: string;
  hintEn: string;
  hintUr: string;
  solution: string[];
  choices?: { id: string; labelEn: string; labelUr: string; symbol?: string; color?: string }[];
  rewardItemId?: string;
  unlocksTargetId?: string;
}

export interface DoorDef {
  doorNumber: number;
  id: string;
  nameEn: string;
  nameUr: string;
  style: 'rusted' | 'clockwork' | 'mirror' | 'flooded' | 'alchemist' | 'library' | 'portrait' | 'chapel' | 'sanctum';
  accentColor: string;
  requiredKeyId?: string;
  requiredPuzzleId?: string;
  bottleId: string;
  letterId: string;
  puzzleId?: string;
  storyNoteEn: string;
  storyNoteUr: string;
}

export interface MapRoomDef {
  id: string;
  chapter: ChapterId;
  nameEn: string;
  nameUr: string;
  x: number;
  z: number;
  w: number;
  d: number;
  isSecret?: boolean;
  doorNumber?: number;
}

export interface GameSettings {
  language: Language;
  difficulty: Difficulty;
  cameraPerspective: CameraPerspective;
  graphicsQuality: GraphicsQuality;
  resolutionScale: number; // 0.6 to 1.0
  shadowsEnabled: boolean;
  volumetricFog: boolean;
  targetFps: 30 | 60;
  brightness: number; // 0.85 to 1.6
  masterVolume: number; // 0 to 1
  musicVolume: number;
  environmentVolume: number;
  effectsVolume: number;
  dialogueVolume: number;
  joystickSensitivity: number; // 0.5 to 2.0
  lookSensitivity: number; // 0.4 to 2.0
  leftHandedLayout: boolean;
  subtitlesEnabled: boolean;
  muted: boolean;
}

export interface SubtitleLine {
  speakerEn: string;
  speakerUr: string;
  textEn: string;
  textUr: string;
  duration: number;
}

export interface CinematicSequence {
  id: string;
  titleEn: string;
  titleUr: string;
  lines: SubtitleLine[];
  cameraMode: 'title_pan' | 'house_approach' | 'ali_reunion' | 'graveyard_entry' | 'boss_intro' | 'dimension_rift' | 'ending';
  endingId?: EndingId;
  nextChapter?: ChapterId;
}

export interface EnemyHudStatus {
  nearestThreatDist: number;
  isChased: boolean;
  bossNameEn?: string;
  bossNameUr?: string;
  bossHealth?: number;
  bossMaxHealth?: number;
  bossPhase?: number;
}

export interface PlayerHudState {
  health: number;
  maxHealth: number;
  stamina: number;
  battery: number;
  flashlightOn: boolean;
  isCrouching: boolean;
  isHiding: boolean;
  noiseLevel: number; // 0 to 1
  chapter: ChapterId;
  objectiveEn: string;
  objectiveUr: string;
  interactPromptEn: string | null;
  interactPromptUr: string | null;
  interactTargetId: string | null;
  interactActionType: 'door' | 'pickup' | 'puzzle' | 'hide' | 'save' | 'ali' | 'portal' | 'brazier' | null;
  aliRescued: boolean;
  aliFollowing: boolean;
  aliSuspicion: number;
  playerPos: { x: number; y: number; z: number; yaw: number };
  currentRoomId: string;
  enemyStatus: EnemyHudStatus;
}

export interface GameProgressState {
  chapter: ChapterId;
  unlockedChapters: ChapterId[];
  health: number;
  stamina: number;
  battery: number;
  inventory: InventoryItem[];
  collectedBottleIds: string[];
  collectedLetterIds: string[];
  solvedPuzzleIds: string[];
  unlockedDoorIds: string[];
  discoveredRoomIds: string[];
  discoveredMapFragments: number;
  aliRescued: boolean;
  aliFollowing: boolean;
  aliSuspicionScore: number;
  defeatedBossIds: string[];
  truthCluesFound: number;
  secretRiftUnlocked: boolean;
  viewedCinematics: string[];
  playerPosition: { x: number; y: number; z: number; yaw: number };
  decisions: {
    trustedAli: boolean;
    freedZoya: boolean;
    challengedArchitect: boolean;
  };
  difficulty: Difficulty;
  playTimeSeconds: number;
}

export interface SaveSlot {
  slotId: string; // 'auto' | 'slot1' | 'slot2' | 'slot3'
  savedAt: string;
  clientUpdatedAtMs?: number;
  chapter: ChapterId;
  difficulty: Difficulty;
  progress: GameProgressState;
}

export interface UserStats {
  totalPlayTimeSec: number;
  endingsUnlocked: EndingId[];
  chaptersReached: number;
  bestBottles: number;
  bestLetters: number;
  bestTruthClues: number;
  bossesDefeated: number;
  puzzlesSolved: number;
  runsCompleted: number;
  deaths: number;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  avatarAccent: string;
  stats: UserStats;
  achievements: string[];
}

export interface LeaderboardEntry {
  uid: string;
  displayName: string;
  score: number;
  endingId: EndingId;
  difficulty: Difficulty;
  chapter: ChapterId;
  completionTimeSec: number;
  bottlesCollected: number;
  lettersCollected: number;
  truthClues: number;
}

export interface SaveConflictInfo {
  slotId: string;
  localSlot: SaveSlot;
  cloudSlot: SaveSlot;
}

export interface AchievementDef {
  id: string;
  titleEn: string;
  titleUr: string;
  descEn: string;
  descUr: string;
}
