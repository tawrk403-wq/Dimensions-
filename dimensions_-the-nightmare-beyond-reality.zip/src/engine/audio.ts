import { ChapterId, GameSettings } from '../types/game';

export class HorrorAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private envGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private dialogueGain: GainNode | null = null;

  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private envNoiseNode: AudioBufferSourceNode | null = null;
  private envFilter: BiquadFilterNode | null = null;
  private droneFilter: BiquadFilterNode | null = null;

  private initialized = false;
  private silencedUntil = 0;
  private lastFootstep = 0;
  private lastHeartbeat = 0;
  private lastWhisper = 0;
  private currentChapter: ChapterId = 1;

  public init() {
    if (this.initialized) {
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
      return;
    }

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;

    const ctx = new AudioCtx();
    this.ctx = ctx;

    this.masterGain = ctx.createGain();
    this.musicGain = ctx.createGain();
    this.envGain = ctx.createGain();
    this.sfxGain = ctx.createGain();
    this.dialogueGain = ctx.createGain();

    this.musicGain.connect(this.masterGain);
    this.envGain.connect(this.masterGain);
    this.sfxGain.connect(this.masterGain);
    this.dialogueGain.connect(this.masterGain);
    this.masterGain.connect(ctx.destination);

    // Subtle atmospheric sub-bass drone
    this.droneFilter = ctx.createBiquadFilter();
    this.droneFilter.type = 'lowpass';
    this.droneFilter.frequency.value = 140;
    this.droneFilter.connect(this.musicGain);

    const droneGain = ctx.createGain();
    droneGain.gain.value = 0.22;
    droneGain.connect(this.droneFilter);

    this.droneOsc1 = ctx.createOscillator();
    this.droneOsc1.type = 'sawtooth';
    this.droneOsc1.frequency.value = 46;
    this.droneOsc1.connect(droneGain);
    this.droneOsc1.start();

    this.droneOsc2 = ctx.createOscillator();
    this.droneOsc2.type = 'triangle';
    this.droneOsc2.frequency.value = 69.2;
    this.droneOsc2.connect(droneGain);
    this.droneOsc2.start();

    // Procedural wind / rain / room tone noise loop
    const bufferSize = ctx.sampleRate * 3;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + 0.03 * white) / 1.03;
      lastOut = data[i];
      data[i] *= 2.5;
    }

    this.envNoiseNode = ctx.createBufferSource();
    this.envNoiseNode.buffer = noiseBuffer;
    this.envNoiseNode.loop = true;

    this.envFilter = ctx.createBiquadFilter();
    this.envFilter.type = 'bandpass';
    this.envFilter.frequency.value = 340;
    this.envFilter.Q.value = 0.7;

    const envSubGain = ctx.createGain();
    envSubGain.gain.value = 0.25;

    this.envNoiseNode.connect(this.envFilter);
    this.envFilter.connect(envSubGain);
    envSubGain.connect(this.envGain);
    this.envNoiseNode.start();

    this.initialized = true;
  }

  public applySettings(settings: GameSettings) {
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const silenced = now < this.silencedUntil;
    const master = settings.muted ? 0 : settings.masterVolume;

    this.masterGain.gain.setTargetAtTime(silenced ? 0.05 * master : master, now, 0.08);
    this.musicGain?.gain.setTargetAtTime(settings.musicVolume * 0.8, now, 0.1);
    this.envGain?.gain.setTargetAtTime(settings.environmentVolume * 0.7, now, 0.1);
    this.sfxGain?.gain.setTargetAtTime(settings.effectsVolume, now, 0.05);
    this.dialogueGain?.gain.setTargetAtTime(settings.dialogueVolume, now, 0.05);
  }

  public setChapterAmbience(chapter: ChapterId) {
    this.currentChapter = chapter;
    if (!this.ctx || !this.droneOsc1 || !this.droneOsc2 || !this.envFilter || !this.droneFilter) return;
    const now = this.ctx.currentTime;
    if (chapter === 1) {
      this.droneOsc1.frequency.setTargetAtTime(44, now, 0.5);
      this.droneOsc2.frequency.setTargetAtTime(65.9, now, 0.5);
      this.droneFilter.frequency.setTargetAtTime(125, now, 0.5);
      this.envFilter.frequency.setTargetAtTime(280, now, 0.5);
    } else if (chapter === 2) {
      // Wind & distant rain feel
      this.droneOsc1.frequency.setTargetAtTime(38, now, 0.5);
      this.droneOsc2.frequency.setTargetAtTime(57, now, 0.5);
      this.droneFilter.frequency.setTargetAtTime(160, now, 0.5);
      this.envFilter.frequency.setTargetAtTime(580, now, 0.5);
    } else {
      // Surreal dissonant tritone drone
      this.droneOsc1.frequency.setTargetAtTime(52, now, 0.5);
      this.droneOsc2.frequency.setTargetAtTime(73.5, now, 0.5);
      this.droneFilter.frequency.setTargetAtTime(220, now, 0.5);
      this.envFilter.frequency.setTargetAtTime(840, now, 0.5);
    }
  }

  public updateListener(pos: { x: number; y: number; z: number }, yaw: number) {
    if (!this.ctx) return;
    const listener = this.ctx.listener;
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    if (listener.positionX) {
      listener.positionX.value = pos.x;
      listener.positionY.value = pos.y;
      listener.positionZ.value = pos.z;
      listener.forwardX.value = fx;
      listener.forwardY.value = 0;
      listener.forwardZ.value = fz;
      listener.upX.value = 0;
      listener.upY.value = 1;
      listener.upZ.value = 0;
    }
  }

  public triggerSuddenSilence(seconds = 1.6) {
    if (!this.ctx) return;
    this.silencedUntil = this.ctx.currentTime + seconds;
  }

  public playFootstep(sprinting: boolean, crouching: boolean) {
    if (!this.ctx || !this.sfxGain) return;
    const now = performance.now();
    const interval = crouching ? 650 : sprinting ? 290 : 450;
    if (now - this.lastFootstep < interval) return;
    this.lastFootstep = now;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    const baseFreq = this.currentChapter === 2 ? 95 : 115;
    osc.frequency.setValueAtTime(baseFreq + Math.random() * 22, t);
    osc.frequency.exponentialRampToValueAtTime(38, t + 0.08);

    const vol = crouching ? 0.05 : sprinting ? 0.22 : 0.12;
    gain.gain.setValueAtTime(vol, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.1);

    // Subtle floorboard creak in Chapter 1
    if (this.currentChapter === 1 && !crouching && Math.random() < 0.22) {
      const creak = this.ctx.createOscillator();
      const cGain = this.ctx.createGain();
      creak.type = 'sawtooth';
      creak.frequency.setValueAtTime(240 + Math.random() * 90, t);
      creak.frequency.linearRampToValueAtTime(170, t + 0.18);
      cGain.gain.setValueAtTime(0.03, t);
      cGain.gain.exponentialRampToValueAtTime(0.001, t + 0.19);
      creak.connect(cGain);
      cGain.connect(this.sfxGain);
      creak.start(t);
      creak.stop(t + 0.2);
    }
  }

  public playHeartbeat(threatProximity01: number) {
    if (!this.ctx || !this.sfxGain || threatProximity01 <= 0.1) return;
    const now = performance.now();
    const interval = 950 - threatProximity01 * 560;
    if (now - this.lastHeartbeat < interval) return;
    this.lastHeartbeat = now;

    const t = this.ctx.currentTime;
    const beat = (offset: number, amp: number) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(62, t + offset);
      osc.frequency.exponentialRampToValueAtTime(28, t + offset + 0.12);
      gain.gain.setValueAtTime(amp * threatProximity01 * 0.35, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.14);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t + offset);
      osc.stop(t + offset + 0.15);
    };
    beat(0, 1);
    beat(0.16, 0.65);
  }

  public play3DSound(
    type:
      | 'whisper'
      | 'knock'
      | 'groan'
      | 'scream'
      | 'thunder'
      | 'chime'
      | 'breathing'
      | 'zoya_footstep'
      | 'crawl_scrape'
      | 'water_drip'
      | 'fluorescent_buzz'
      | 'pipe_creak'
      | 'electrical_spark',
    worldPos: { x: number; y: number; z: number },
    pitchScale = 1
  ) {
    if (!this.ctx || !this.sfxGain) return;
    if (type === 'whisper' || type === 'breathing') {
      const now = performance.now();
      if (now - this.lastWhisper < 3200) return;
      this.lastWhisper = now;
    }

    const t = this.ctx.currentTime;
    const panner = this.ctx.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 3;
    panner.maxDistance = 36;
    panner.rolloffFactor = 1.4;
    panner.positionX.value = worldPos.x;
    panner.positionY.value = worldPos.y;
    panner.positionZ.value = worldPos.z;
    panner.connect(this.sfxGain);

    if (type === 'whisper' || type === 'groan') {
      const osc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();
      osc.type = type === 'whisper' ? 'sawtooth' : 'triangle';
      osc.frequency.setValueAtTime((type === 'whisper' ? 320 : 105) * pitchScale, t);
      osc.frequency.linearRampToValueAtTime((type === 'whisper' ? 210 : 72) * pitchScale, t + 1.1);
      filter.type = 'bandpass';
      filter.frequency.value = type === 'whisper' ? 1100 : 280;
      filter.Q.value = 3.2;

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(type === 'whisper' ? 0.16 : 0.25, t + 0.25);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 1.2);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(panner);
      osc.start(t);
      osc.stop(t + 1.25);
    } else if (type === 'breathing') {
      // Unsettling cold ragged breath cycle using filtered noise burst
      const dur = 0.85;
      const buf = this.ctx.createBuffer(1, Math.floor(this.ctx.sampleRate * dur), this.ctx.sampleRate);
      const ch = buf.getChannelData(0);
      for (let i = 0; i < ch.length; i++) ch[i] = (Math.random() * 2 - 1) * 0.7;
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const bp = this.ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(520 * pitchScale, t);
      bp.frequency.linearRampToValueAtTime(340 * pitchScale, t + dur);
      bp.Q.value = 2.6;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.001, t);
      g.gain.linearRampToValueAtTime(0.22, t + 0.22);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      src.connect(bp);
      bp.connect(g);
      g.connect(panner);
      src.start(t);
      src.stop(t + dur + 0.05);
    } else if (type === 'zoya_footstep' || type === 'crawl_scrape') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = type === 'crawl_scrape' ? 'sawtooth' : 'triangle';
      osc.frequency.setValueAtTime((type === 'crawl_scrape' ? 280 : 145) * pitchScale, t);
      osc.frequency.exponentialRampToValueAtTime(48, t + (type === 'crawl_scrape' ? 0.14 : 0.09));
      g.gain.setValueAtTime(type === 'crawl_scrape' ? 0.14 : 0.19, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + (type === 'crawl_scrape' ? 0.15 : 0.1));
      osc.connect(g);
      g.connect(panner);
      osc.start(t);
      osc.stop(t + 0.17);
    } else if (type === 'water_drip') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1180 * pitchScale, t);
      osc.frequency.exponentialRampToValueAtTime(1750 * pitchScale, t + 0.045);
      g.gain.setValueAtTime(0.11, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
      osc.connect(g);
      g.connect(panner);
      osc.start(t);
      osc.stop(t + 0.18);
    } else if (type === 'fluorescent_buzz' || type === 'electrical_spark') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(type === 'electrical_spark' ? 960 : 120, t);
      if (type === 'electrical_spark') osc.frequency.exponentialRampToValueAtTime(190, t + 0.12);
      g.gain.setValueAtTime(type === 'electrical_spark' ? 0.14 : 0.055, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + (type === 'electrical_spark' ? 0.14 : 0.32));
      osc.connect(g);
      g.connect(panner);
      osc.start(t);
      osc.stop(t + 0.35);
    } else if (type === 'pipe_creak') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(210 * pitchScale, t);
      osc.frequency.linearRampToValueAtTime(165 * pitchScale, t + 0.55);
      g.gain.setValueAtTime(0.001, t);
      g.gain.linearRampToValueAtTime(0.08, t + 0.18);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.65);
      osc.connect(g);
      g.connect(panner);
      osc.start(t);
      osc.stop(t + 0.7);
    } else if (type === 'knock') {
      [0, 0.22, 0.44].forEach((offset) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(140, t + offset);
        osc.frequency.exponentialRampToValueAtTime(48, t + offset + 0.12);
        g.gain.setValueAtTime(0.35, t + offset);
        g.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.13);
        osc.connect(g);
        g.connect(panner);
        osc.start(t + offset);
        osc.stop(t + offset + 0.15);
      });
    } else if (type === 'scream') {
      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc2.type = 'square';
      osc.frequency.setValueAtTime(520 * pitchScale, t);
      osc.frequency.exponentialRampToValueAtTime(190 * pitchScale, t + 0.65);
      osc2.frequency.setValueAtTime(760 * pitchScale, t);
      osc2.frequency.exponentialRampToValueAtTime(250 * pitchScale, t + 0.65);

      gain.gain.setValueAtTime(0.24, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(panner);
      osc.start(t);
      osc2.start(t);
      osc.stop(t + 0.72);
      osc2.stop(t + 0.72);
    } else if (type === 'chime') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440 * pitchScale, t);
      g.gain.setValueAtTime(0.24, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 1.1);
      osc.connect(g);
      g.connect(panner);
      osc.start(t);
      osc.stop(t + 1.15);
    } else if (type === 'thunder') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(78, t);
      osc.frequency.exponentialRampToValueAtTime(26, t + 1.8);
      g.gain.setValueAtTime(0.35, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 1.9);
      osc.connect(g);
      g.connect(panner);
      osc.start(t);
      osc.stop(t + 2.0);
    }
  }

  public playSfx(kind: 'click' | 'door_creak' | 'pickup' | 'bottle' | 'paper' | 'unlock' | 'hit' | 'heal' | 'chime_low' | 'chime_mid' | 'chime_high') {
    if (!this.ctx || !this.sfxGain) return;
    const t = this.ctx.currentTime;

    if (kind === 'click') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(920, t);
      osc.frequency.exponentialRampToValueAtTime(320, t + 0.04);
      g.gain.setValueAtTime(0.14, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.055);
    } else if (kind === 'door_creak') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(160, t);
      osc.frequency.linearRampToValueAtTime(235, t + 0.35);
      osc.frequency.linearRampToValueAtTime(130, t + 0.7);
      g.gain.setValueAtTime(0.09, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.72);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.75);
    } else if (kind === 'pickup' || kind === 'unlock' || kind === 'heal') {
      const freqs = kind === 'unlock' ? [330, 440, 587] : kind === 'heal' ? [392, 523] : [480, 640];
      freqs.forEach((f, idx) => {
        if (!this.ctx || !this.sfxGain) return;
        const osc = this.ctx.createOscillator();
        const g = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, t + idx * 0.07);
        g.gain.setValueAtTime(0.16, t + idx * 0.07);
        g.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.07 + 0.22);
        osc.connect(g);
        g.connect(this.sfxGain);
        osc.start(t + idx * 0.07);
        osc.stop(t + idx * 0.07 + 0.24);
      });
    } else if (kind === 'bottle') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1320, t);
      osc.frequency.exponentialRampToValueAtTime(980, t + 0.18);
      g.gain.setValueAtTime(0.2, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.36);
    } else if (kind === 'paper') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(620, t);
      osc.frequency.exponentialRampToValueAtTime(210, t + 0.11);
      g.gain.setValueAtTime(0.11, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.13);
    } else if (kind === 'hit') {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(125, t);
      osc.frequency.exponentialRampToValueAtTime(34, t + 0.35);
      g.gain.setValueAtTime(0.4, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.38);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.4);
    } else if (kind === 'chime_low' || kind === 'chime_mid' || kind === 'chime_high') {
      const f = kind === 'chime_low' ? 220 : kind === 'chime_mid' ? 349.2 : 587.3;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, t);
      g.gain.setValueAtTime(0.26, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.9);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.95);
    }
  }
}

export const audioEngine = new HorrorAudioEngine();
