import * as THREE from 'three';
import { BOTTLES, DOORS, LETTERS, PUZZLES } from '../data/gameData';
import { ChapterId, GameProgressState } from '../types/game';
import {
  buildBasementBreakerPanelModel,
  buildDeadTreeModel,
  buildDoorInteriorProps,
  buildDrinkBottleModel,
  buildExaminationTableModel,
  buildFluorescentFixtureModel,
  buildHidingWardrobeModel,
  buildHospitalBedModel,
  buildMorgueDrawerBankModel,
  buildMysteriousDoorModel,
  buildOperationTheatreRig,
  buildSaveShrineModel,
  buildWheelchairModel,
} from './models';
import {
  getBasementConcretePBRTextures,
  getBloodDecalTexture,
  getDimensionRunePBRTextures,
  getHospitalTilePBRTextures,
  getHospitalWallPBRTextures,
  getStoneSoilPBRTextures,
  getWallPBRTextures,
  getWoodPBRTextures,
} from './textures';

export interface BoxCollider {
  id?: string;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  active: boolean;
}

export interface FloorZone {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  yStart: number;
  yEnd: number;
  axis?: 'z' | 'x';
  overrideBase?: boolean; // Allows subterranean basements/morgues with negative Y
}

export interface WorldBounds {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface InteractableObj {
  id: string;
  type: 'door' | 'pickup' | 'puzzle' | 'hide' | 'save' | 'ali' | 'portal' | 'brazier';
  mesh: THREE.Object3D;
  position: THREE.Vector3;
  radius: number;
  labelEn: string;
  labelUr: string;
  itemId?: string;
  letterId?: string;
  bottleId?: string;
  puzzleId?: string;
  doorNumber?: number;
  isCollected?: boolean;
  isLit?: boolean;
  hideLookAt?: THREE.Vector3;
}

export interface FlickerLight {
  light: THREE.PointLight;
  baseIntensity: number;
  phase: number;
  kind?: 'warm' | 'fluorescent' | 'emergency' | 'cold';
}

export interface FlickerTube {
  mat: THREE.MeshBasicMaterial;
  baseColor: number;
  phase: number;
  broken: boolean;
}

export interface WaterDripEmitter {
  mesh: THREE.Mesh;
  origin: THREE.Vector3;
  floorY: number;
  phase: number;
  speed: number;
}

export interface DoorRuntime {
  doorNumber: number;
  id: string;
  group: THREE.Group;
  doorLeaf: THREE.Group;
  statusOrbMat: THREE.MeshBasicMaterial;
  collider: BoxCollider;
  openProgress: number;
  isOpen: boolean;
  isUnlocked: boolean;
}

export interface LevelBuildResult {
  root: THREE.Group;
  colliders: BoxCollider[];
  floorZones: FloorZone[];
  bounds: WorldBounds;
  interactables: InteractableObj[];
  doors: DoorRuntime[];
  flickerLights: FlickerLight[];
  flickerTubes: FlickerTube[];
  dripEmitters: WaterDripEmitter[];
  lodProps: { obj: THREE.Object3D; maxDistSq: number }[];
  patrolWaypoints: THREE.Vector3[];
  playerSpawn: THREE.Vector3;
  aliSpawn: THREE.Vector3;
  bossSpawn: THREE.Vector3;
  quantumShiftObjects: THREE.Object3D[];
  mistUniforms?: { uTime: { value: number } };
  dispose: () => void;
}

function evalZoneHeight(fz: FloorZone, x: number, z: number): number {
  if (fz.yStart === fz.yEnd) return fz.yStart;
  if (fz.axis === 'x') {
    const t = (x - fz.minX) / Math.max(0.001, fz.maxX - fz.minX);
    return fz.yStart + (fz.yEnd - fz.yStart) * Math.max(0, Math.min(1, t));
  }
  const t = (fz.maxZ - z) / Math.max(0.001, fz.maxZ - fz.minZ);
  return fz.yStart + (fz.yEnd - fz.yStart) * Math.max(0, Math.min(1, t));
}

/**
 * Deterministic fast O(N) floor height lookup supporting stairs, ramps, basements, morgues & graveyard terrain.
 */
export function computeGroundHeight(
  x: number,
  z: number,
  chapter: ChapterId,
  floorZones: FloorZone[]
): number {
  let overrideMatch: number | null = null;
  let maxY = 0;

  if (chapter === 2) {
    const inMorgueFootprint =
      (x >= 15.2 && x <= 33.0 && z >= -23.2 && z <= -4.4) ||
      (x >= 17.5 && x <= 23.5 && z >= -4.5 && z <= 2.2);
    if (!inMorgueFootprint) {
      const absX = Math.abs(x);
      if (absX > 3.6 && z > -14 && z < 26) {
        const blendX = Math.min(1, (absX - 3.6) / 3.5);
        const undulation = (Math.sin(x * 0.22) * Math.cos(z * 0.18) + 1) * 0.18;
        maxY = Math.max(maxY, blendX * undulation);
      }
    }
  }

  for (let i = 0; i < floorZones.length; i++) {
    const fz = floorZones[i];
    if (x >= fz.minX && x <= fz.maxX && z >= fz.minZ && z <= fz.maxZ) {
      const h = evalZoneHeight(fz, x, z);
      if (fz.overrideBase) {
        overrideMatch = overrideMatch === null ? h : Math.max(overrideMatch, h);
      } else if (h > maxY) {
        maxY = h;
      }
    }
  }

  return overrideMatch !== null ? overrideMatch : maxY;
}

export function buildChapterLevel(
  chapter: ChapterId,
  progress: GameProgressState,
  anisotropy: number,
  qualityTier: 'low' | 'medium' | 'high' | 'ultra' = 'medium'
): LevelBuildResult {
  const root = new THREE.Group();
  const colliders: BoxCollider[] = [];
  const floorZones: FloorZone[] = [];
  const interactables: InteractableObj[] = [];
  const doors: DoorRuntime[] = [];
  const flickerLights: FlickerLight[] = [];
  const flickerTubes: FlickerTube[] = [];
  const dripEmitters: WaterDripEmitter[] = [];
  const lodProps: { obj: THREE.Object3D; maxDistSq: number }[] = [];
  const patrolWaypoints: THREE.Vector3[] = [];
  const quantumShiftObjects: THREE.Object3D[] = [];
  let mistUniforms: { uTime: { value: number } } | undefined;

  const useDetailMaps = qualityTier !== 'low';
  const maxLights =
    qualityTier === 'low' ? 3 : qualityTier === 'medium' ? 5 : qualityTier === 'high' ? 7 : 10;

  // Shared pickup geometries
  const paperGeo = new THREE.BoxGeometry(0.32, 0.015, 0.4);
  const sealGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.02, 7);
  const batteryGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.22, 8);
  const bandageGeo = new THREE.BoxGeometry(0.24, 0.12, 0.24);
  const mapGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.34, 8);
  const shardGeo = new THREE.OctahedronGeometry(0.14, 0);
  const glintHaloGeo = new THREE.RingGeometry(0.14, 0.2, 12);
  const bloodPlaneGeo = new THREE.PlaneGeometry(1.9, 1.9);
  const dripGeo = new THREE.SphereGeometry(0.032, 5, 5);
  const dripMat = new THREE.MeshBasicMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.72 });

  const paperMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.85, emissive: 0x3b2f12, emissiveIntensity: 0.25 });
  const sealMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.4 });
  const batteryMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.5, roughness: 0.35, emissive: 0x78350f, emissiveIntensity: 0.55 });
  const bandageMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.85, emissive: 0x166534, emissiveIntensity: 0.45 });
  const mapMat = new THREE.MeshStandardMaterial({ color: 0xd6d3d1, roughness: 0.8, emissive: 0x1e293b, emissiveIntensity: 0.35 });
  const shardMat = new THREE.MeshStandardMaterial({ color: 0xfbbf24, emissive: 0xb45309, emissiveIntensity: 0.95, metalness: 0.8, roughness: 0.2 });

  const bloodDecalMat = new THREE.MeshBasicMaterial({
    map: getBloodDecalTexture(),
    transparent: true,
    opacity: 0.82,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
  });

  const registerLod = (obj: THREE.Object3D, dist = 24) => {
    lodProps.push({ obj, maxDistSq: dist * dist });
  };

  const addBloodDecal = (x: number, y: number, z: number, scale = 1, rotY = 0) => {
    const m = new THREE.Mesh(bloodPlaneGeo, bloodDecalMat);
    m.rotation.x = -Math.PI / 2;
    m.rotation.z = rotY;
    m.scale.setScalar(scale);
    m.position.set(x, y + 0.018, z);
    m.userData.sharedAsset = true;
    root.add(m);
    registerLod(m, 26);
  };

  const addDripEmitter = (x: number, ceilY: number, floorY: number, phase: number) => {
    const drop = new THREE.Mesh(dripGeo, dripMat);
    drop.position.set(x, ceilY - 0.1, phase);
    drop.userData.sharedAsset = true;
    root.add(drop);
    dripEmitters.push({
      mesh: drop,
      origin: new THREE.Vector3(x, ceilY - 0.12, phase),
      floorY,
      phase: Math.abs(x + phase) * 0.7,
      speed: 2.8 + (Math.abs(x) % 1.2),
    });
  };

  const addWall = (
    x: number,
    z: number,
    w: number,
    h: number,
    d: number,
    mat: THREE.Material,
    hasCollider = true,
    baseY = 0
  ) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    mesh.position.set(x, baseY + h / 2, z);
    if (qualityTier === 'high' || qualityTier === 'ultra') {
      mesh.castShadow = true;
      mesh.receiveShadow = true;
    }
    root.add(mesh);
    if (hasCollider) {
      colliders.push({
        minX: x - w / 2,
        maxX: x + w / 2,
        minZ: z - d / 2,
        maxZ: z + d / 2,
        active: true,
      });
    }
    return mesh;
  };

  const addStairsAlongZ = (
    centerX: number,
    width: number,
    startZ: number,
    endZ: number,
    startY: number,
    endY: number,
    steps: number,
    stepMat: THREE.Material,
    runnerMat?: THREE.Material,
    overrideBase = false
  ) => {
    floorZones.push({
      minX: centerX - width / 2,
      maxX: centerX + width / 2,
      minZ: Math.min(startZ, endZ),
      maxZ: Math.max(startZ, endZ),
      yStart: startY,
      yEnd: endY,
      axis: 'z',
      overrideBase,
    });

    const totalLen = Math.abs(startZ - endZ);
    const stepDepth = totalLen / steps;
    const lowY = Math.min(startY, endY);
    const dirZ = endZ < startZ ? -1 : 1;

    for (let i = 0; i < steps; i++) {
      const frac = (i + 1) / steps;
      const topY = startY + (endY - startY) * frac;
      const h = Math.max(0.08, topY - lowY);
      const sz = startZ + dirZ * (stepDepth * (i + 0.5));
      const stepMesh = new THREE.Mesh(new THREE.BoxGeometry(width, h, stepDepth + 0.03), stepMat);
      stepMesh.position.set(centerX, lowY + h / 2, sz);
      stepMesh.receiveShadow = true;
      root.add(stepMesh);

      if (runnerMat) {
        const runner = new THREE.Mesh(new THREE.BoxGeometry(width * 0.48, 0.02, stepDepth + 0.03), runnerMat);
        runner.position.set(centerX, topY + 0.01, sz);
        root.add(runner);
      }
    }
  };

  const addFlickerLight = (
    x: number,
    y: number,
    z: number,
    color: number,
    intensity: number,
    dist: number,
    kind: FlickerLight['kind'] = 'warm'
  ) => {
    if (flickerLights.length >= maxLights) return null;
    const l = new THREE.PointLight(color, intensity, dist, 1.55);
    l.position.set(x, y, z);
    root.add(l);
    flickerLights.push({ light: l, baseIntensity: intensity, phase: flickerLights.length * 1.9, kind });
    return l;
  };

  const addCeilingTube = (x: number, y: number, z: number, rotY = 0, broken = false) => {
    const built = buildFluorescentFixtureModel(broken);
    built.group.position.set(x, y, z);
    built.group.rotation.y = rotY;
    root.add(built.group);
    flickerTubes.push({
      mat: built.tubeMat,
      baseColor: broken ? 0x2a3b3b : 0xd1fae5,
      phase: x * 0.4 + z * 0.3,
      broken,
    });
    registerLod(built.group, 28);
  };

  const addPickup = (
    id: string,
    x: number,
    yOffset: number,
    z: number,
    kind: 'bottle' | 'letter' | 'battery' | 'bandage' | 'key' | 'map' | 'shard',
    opts: { bottleId?: string; letterId?: string; itemId?: string; color?: string; labelEn: string; labelUr: string }
  ) => {
    const alreadyDone =
      (opts.bottleId && progress.collectedBottleIds.includes(opts.bottleId)) ||
      (opts.letterId && progress.collectedLetterIds.includes(opts.letterId));
    if (alreadyDone) return;

    const groundY = computeGroundHeight(x, z, chapter, floorZones);
    const finalY = groundY + yOffset;

    let mesh: THREE.Object3D;
    if (kind === 'bottle') {
      mesh = buildDrinkBottleModel(opts.color || '#d9c589');
    } else if (kind === 'letter') {
      const grp = new THREE.Group();
      const paper = new THREE.Mesh(paperGeo, paperMat);
      const seal = new THREE.Mesh(sealGeo, sealMat);
      seal.position.set(0.06, 0.012, 0.08);
      grp.add(paper, seal);
      mesh = grp;
    } else if (kind === 'battery') {
      mesh = new THREE.Mesh(batteryGeo, batteryMat);
    } else if (kind === 'bandage') {
      mesh = new THREE.Mesh(bandageGeo, bandageMat);
    } else if (kind === 'map') {
      mesh = new THREE.Mesh(mapGeo, mapMat);
      mesh.rotation.z = Math.PI / 2;
    } else {
      mesh = new THREE.Mesh(shardGeo, shardMat);
    }

    const glintHalo = new THREE.Mesh(
      glintHaloGeo,
      new THREE.MeshBasicMaterial({
        color: kind === 'bottle' ? opts.color || '#f59e0b' : '#fde047',
        transparent: true,
        opacity: 0.45,
        side: THREE.DoubleSide,
        depthWrite: false,
      })
    );
    glintHalo.rotation.x = -Math.PI / 2;
    glintHalo.position.set(0, 0.02, 0);
    mesh.add(glintHalo);

    mesh.position.set(x, finalY, z);
    root.add(mesh);

    interactables.push({
      id,
      type: 'pickup',
      mesh,
      position: new THREE.Vector3(x, finalY, z),
      radius: 2.35,
      labelEn: opts.labelEn,
      labelUr: opts.labelUr,
      itemId: opts.itemId,
      letterId: opts.letterId,
      bottleId: opts.bottleId,
    });
  };

  const addPuzzleStation = (id: string, x: number, z: number, puzzleId: string) => {
    const puzzle = PUZZLES[puzzleId];
    if (!puzzle) return;
    const gy = computeGroundHeight(x, z, chapter, floorZones);
    const ped = new THREE.Group();
    const base = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 0.95, 0.65),
      new THREE.MeshStandardMaterial({ color: 0x1f2430, roughness: 0.6, metalness: 0.4 })
    );
    base.position.y = 0.475;
    const solved = progress.solvedPuzzleIds.includes(puzzleId);
    const rune = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.16, 0),
      new THREE.MeshBasicMaterial({ color: solved ? 0x10b981 : 0xe11d48 })
    );
    rune.position.y = 1.18;
    ped.add(base, rune);
    ped.position.set(x, gy, z);
    root.add(ped);

    colliders.push({ minX: x - 0.4, maxX: x + 0.4, minZ: z - 0.35, maxZ: z + 0.35, active: true });
    interactables.push({
      id,
      type: 'puzzle',
      mesh: ped,
      position: new THREE.Vector3(x, gy + 0.9, z),
      radius: 2.4,
      labelEn: `Examine: ${puzzle.titleEn}`,
      labelUr: `معائنہ: ${puzzle.titleUr}`,
      puzzleId,
    });
  };

  const addHideSpot = (id: string, x: number, z: number, rotY: number, isCrypt = false) => {
    const gy = computeGroundHeight(x, z, chapter, floorZones);
    const wardrobe = buildHidingWardrobeModel(isCrypt, anisotropy);
    wardrobe.position.set(x, gy, z);
    wardrobe.rotation.y = rotY;
    root.add(wardrobe);
    const outDir = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), rotY);
    interactables.push({
      id,
      type: 'hide',
      mesh: wardrobe,
      position: new THREE.Vector3(x, gy + 1.0, z),
      radius: 2.35,
      labelEn: isCrypt ? 'Hide inside Crypt Alcove' : 'Hide inside Wardrobe',
      labelUr: isCrypt ? 'مقبرے کی اوٹ میں چھپیں' : 'الماری میں چھپیں',
      hideLookAt: new THREE.Vector3(x + outDir.x * 3, gy + 1.4, z + outDir.z * 3),
    });
  };

  const addSaveShrine = (id: string, x: number, z: number) => {
    const gy = computeGroundHeight(x, z, chapter, floorZones);
    const shrine = buildSaveShrineModel();
    shrine.position.set(x, gy, z);
    root.add(shrine);
    colliders.push({ minX: x - 0.45, maxX: x + 0.45, minZ: z - 0.35, maxZ: z + 0.35, active: true });
    interactables.push({
      id,
      type: 'save',
      mesh: shrine,
      position: new THREE.Vector3(x, gy + 0.9, z),
      radius: 2.35,
      labelEn: 'Safe Lantern Shrine (Save & Rest)',
      labelUr: 'محفوظ لالٹین (کھیل محفوظ کریں)',
    });
  };

  const disposeRoot = () => {
    root.traverse((obj) => {
      const m = obj as THREE.Mesh;
      if (m.geometry && !m.userData?.sharedAsset && !m.userData?.sharedGeo) {
        m.geometry.dispose();
      }
      if (m.material && !m.userData?.sharedAsset) {
        if (Array.isArray(m.material)) {
          m.material.forEach((mat) => mat.dispose());
        } else {
          m.material.dispose();
        }
      }
    });
  };

  // ============================================================================
  // CHAPTER 1: HAUNTED HOSPITAL CORRIDOR, OPERATION THEATRE & HOSPITAL BASEMENT
  // ============================================================================
  if (chapter === 1) {
    const hospitalTilePbr = getHospitalTilePBRTextures(anisotropy, false);
    hospitalTilePbr.map.repeat.set(16, 16);
    hospitalTilePbr.bumpMap.repeat.set(16, 16);
    hospitalTilePbr.roughnessMap.repeat.set(16, 16);

    const hospitalWallPbr = getHospitalWallPBRTextures(anisotropy);
    const darkManorWallPbr = getWallPBRTextures(anisotropy, '#241f28');
    const woodPbr = getWoodPBRTextures(anisotropy, true);
    const basementPbr = getBasementConcretePBRTextures(anisotropy);

    const hospWallMat = new THREE.MeshStandardMaterial({
      map: hospitalWallPbr.map,
      bumpMap: useDetailMaps ? hospitalWallPbr.bumpMap : null,
      bumpScale: 0.045,
      roughnessMap: useDetailMaps ? hospitalWallPbr.roughnessMap : null,
      roughness: 0.84,
      metalness: 0.06,
    });
    const manorWallMat = new THREE.MeshStandardMaterial({
      map: darkManorWallPbr.map,
      bumpMap: useDetailMaps ? darkManorWallPbr.bumpMap : null,
      bumpScale: 0.04,
      roughnessMap: useDetailMaps ? darkManorWallPbr.roughnessMap : null,
      roughness: 0.86,
      metalness: 0.06,
    });
    const hospFloorMat = new THREE.MeshStandardMaterial({
      map: hospitalTilePbr.map,
      bumpMap: useDetailMaps ? hospitalTilePbr.bumpMap : null,
      bumpScale: 0.038,
      roughnessMap: useDetailMaps ? hospitalTilePbr.roughnessMap : null,
      roughness: 0.6,
      metalness: 0.08,
    });
    const basementConcreteMat = new THREE.MeshStandardMaterial({
      map: basementPbr.map,
      bumpMap: useDetailMaps ? basementPbr.bumpMap : null,
      bumpScale: 0.055,
      roughnessMap: useDetailMaps ? basementPbr.roughnessMap : null,
      roughness: 0.82,
      metalness: 0.12,
    });
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x3f2a20, metalness: 0.72, roughness: 0.56 });
    const stairWoodMat = new THREE.MeshStandardMaterial({ map: woodPbr.map, color: 0x2c1d14, roughness: 0.74 });
    const runnerMat = new THREE.MeshStandardMaterial({ color: 0x45121b, roughness: 0.9 });
    const ceilingMat = new THREE.MeshStandardMaterial({ color: 0x101213, roughness: 0.94 });

    const bounds: WorldBounds = { minX: -24.2, maxX: 24.2, minZ: -39.2, maxZ: 13.2 };

    // Main Hospital Ground Slab (leaving North-West Basement cutout x in [-24.5..-13.5], z in [-40..-17])
    const southFloor = new THREE.Mesh(new THREE.PlaneGeometry(52, 31), hospFloorMat);
    southFloor.rotation.x = -Math.PI / 2;
    southFloor.position.set(0, 0, -1.5);
    southFloor.receiveShadow = true;
    root.add(southFloor);

    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(54, 58), ceilingMat);
    ceil.rotation.x = Math.PI / 2;
    ceil.position.set(0, 4.6, -13);
    root.add(ceil);

    // Ceiling structural ribs (InstancedMesh: 1 draw call)
    const beamCount = 9;
    const beamGeo = new THREE.BoxGeometry(49.5, 0.24, 0.32);
    const beamInst = new THREE.InstancedMesh(beamGeo, pipeMat, beamCount);
    const beamDummy = new THREE.Object3D();
    for (let bi = 0; bi < beamCount; bi++) {
      beamDummy.position.set(0, 4.48, 10 - bi * 6);
      beamDummy.updateMatrix();
      beamInst.setMatrixAt(bi, beamDummy.matrix);
    }
    beamInst.instanceMatrix.needsUpdate = true;
    root.add(beamInst);

    // Entry Porch Raised Dais + Steps
    const entryDais = new THREE.Mesh(new THREE.BoxGeometry(8, 0.24, 4.5), stairWoodMat);
    entryDais.position.set(0, 0.12, 11.25);
    root.add(entryDais);
    floorZones.push({ minX: -4, maxX: 4, minZ: 9.0, maxZ: 13.5, yStart: 0.24, yEnd: 0.24 });
    addStairsAlongZ(0, 8, 7.8, 9.0, 0, 0.24, 2, stairWoodMat, runnerMat);

    // Grand North Gallery & Operation Theatre Terrace (x = -13.5..24.8 at y = 0.72, plus NW basement landing)
    const mainTerrace = new THREE.Mesh(new THREE.BoxGeometry(38.3, 0.72, 27), hospFloorMat);
    mainTerrace.position.set(5.65, 0.36, -26.5);
    mainTerrace.receiveShadow = true;
    root.add(mainTerrace);
    floorZones.push({ minX: -13.5, maxX: 24.8, minZ: -40, maxZ: -13.0, yStart: 0.72, yEnd: 0.72 });

    const nwLanding = new THREE.Mesh(new THREE.BoxGeometry(11.0, 0.72, 4.2), hospFloorMat);
    nwLanding.position.set(-19.0, 0.36, -15.1);
    nwLanding.receiveShadow = true;
    root.add(nwLanding);
    floorZones.push({ minX: -24.5, maxX: -13.5, minZ: -17.2, maxZ: -13.0, yStart: 0.72, yEnd: 0.72 });

    // West Hospital Corridor steps up onto NW Basement Landing (clear of Door III & Mirror Puzzle)
    addStairsAlongZ(-21.5, 4.0, -10.5, -13.0, 0, 0.72, 3, stairWoodMat, runnerMat);

    // Grand Central Staircase ascending into North Gallery
    addStairsAlongZ(0, 5.2, -9.5, -13.0, 0, 0.72, 5, stairWoodMat, runnerMat);

    // Exterior perimeter walls
    addWall(0, 14, 52, 4.6, 0.8, hospWallMat);
    addWall(0, -40, 52, 4.6, 0.8, manorWallMat);
    addWall(-25, -13, 0.8, 4.6, 54, hospWallMat);
    addWall(25, -13, 0.8, 4.6, 54, hospWallMat);

    // Interior Hospital Corridor dividers
    addWall(-9, 7.5, 0.6, 4.6, 12, hospWallMat);
    addWall(-9, -7.5, 0.6, 4.6, 12, hospWallMat);
    addWall(9, 7.5, 0.6, 4.6, 12, hospWallMat);
    addWall(9, -7.5, 0.6, 4.6, 12, hospWallMat);
    addWall(-6.8, -12.6, 8.2, 4.6, 0.6, hospWallMat);
    addWall(6.8, -12.6, 8.2, 4.6, 0.6, hospWallMat);

    // Grand Foyer Crimson Runner Carpet
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 11), runnerMat);
    rug.rotation.x = -Math.PI / 2;
    rug.position.set(0, 0.02, 0);
    root.add(rug);

    // --------------------------------------------------------------------------
    // 1. HAUNTED HOSPITAL CORRIDOR PROPS (Beds, Wheelchairs, Blood, Fluorescents)
    // --------------------------------------------------------------------------
    const bedSpots: [number, number, number][] = [
      [-11.0, 4.0, Math.PI / 2],
      [-21.8, -4.6, -Math.PI / 2],
      [11.0, -4.2, -Math.PI / 2],
      [21.8, 4.6, Math.PI / 2],
    ];
    bedSpots.forEach(([bx, bz, rot], idx) => {
      const bed = buildHospitalBedModel(idx % 2 === 0);
      bed.position.set(bx, 0, bz);
      bed.rotation.y = rot;
      root.add(bed);
      colliders.push({ minX: bx - 1.05, maxX: bx + 1.05, minZ: bz - 0.6, maxZ: bz + 0.6, active: true });
      registerLod(bed, 25);
    });

    const chairSpots: [number, number, number][] = [
      [-13.8, -1.5, 0.5],
      [13.8, 2.8, -0.7],
      [13.2, -10.8, 2.4],
    ];
    chairSpots.forEach(([cx, cz, rot]) => {
      const gy = computeGroundHeight(cx, cz, 1, floorZones);
      const wc = buildWheelchairModel();
      wc.position.set(cx, gy, cz);
      wc.rotation.y = rot;
      root.add(wc);
      colliders.push({ minX: cx - 0.45, maxX: cx + 0.45, minZ: cz - 0.45, maxZ: cz + 0.45, active: true });
      registerLod(wc, 22);
    });

    // Cracked corridor blood smears
    addBloodDecal(-16, 0, 3.2, 1.2, 0.4);
    addBloodDecal(-16, 0, -4.8, 1.4, -0.7);
    addBloodDecal(16, 0, 1.4, 1.1, 1.1);
    addBloodDecal(16, 0, -6.5, 1.5, 0.2);

    // Ceiling fluorescent tube lights along West & East hospital corridors
    [
      [-16, 4.35, 5.5, 0, false],
      [-16, 4.35, 0.0, 0, true],
      [-16, 4.35, -5.5, 0, false],
      [16, 4.35, 5.5, 0, true],
      [16, 4.35, 0.0, 0, false],
      [16, 4.35, -5.5, 0, false],
    ].forEach(([tx, ty, tz, ry, broken]) => {
      addCeilingTube(tx as number, ty as number, tz as number, ry as number, broken as boolean);
    });

    // --------------------------------------------------------------------------
    // 2. ABANDONED OPERATION THEATRE (North-East Gallery Suite, y = 0.72)
    // --------------------------------------------------------------------------
    addWall(13.5, -21.8, 0.45, 3.88, 6.4, hospWallMat, true, 0.72); // West theatre partition with open south entry
    addWall(19.0, -25.2, 11.4, 3.88, 0.45, hospWallMat, true, 0.72); // North theatre wall

    // Observation frosted glass window framed into west wall
    const obsGlass = new THREE.Mesh(
      new THREE.PlaneGeometry(3.4, 1.5),
      new THREE.MeshPhysicalMaterial({
        color: 0x94a3b8,
        roughness: 0.28,
        metalness: 0.15,
        transparent: true,
        opacity: 0.34,
      })
    );
    obsGlass.position.set(13.24, 2.65, -21.8);
    obsGlass.rotation.y = Math.PI / 2;
    root.add(obsGlass);

    const opTheatre = buildOperationTheatreRig(anisotropy);
    opTheatre.group.position.set(18.6, 0.72, -19.8);
    root.add(opTheatre.group);
    colliders.push({ minX: 17.5, maxX: 19.7, minZ: -21.1, maxZ: -18.5, active: true });
    addBloodDecal(18.6, 0.72, -19.8, 1.65, 0.8);
    addCeilingTube(18.6, 4.35, -16.8, Math.PI / 2, false);

    // Extra surgical room reward supplies
    addPickup('pickup_c1_op_bat', 21.8, 0.25, -22.2, 'battery', {
      itemId: 'battery',
      labelEn: 'Surgical Cart Battery',
      labelUr: 'آپریشن ٹرالی سے بیٹری اٹھائیں',
    });
    addPickup('pickup_c1_op_band', 21.8, 0.25, -17.5, 'bandage', {
      itemId: 'bandage',
      labelEn: 'Sterile Field Bandage',
      labelUr: 'طبی پٹی اٹھائیں',
    });

    // --------------------------------------------------------------------------
    // 3. HOSPITAL PIPE BASEMENT (North-West Sub-Level descending to y = -1.6)
    // --------------------------------------------------------------------------
    addStairsAlongZ(-19.0, 5.2, -17.2, -22.5, 0.72, -1.6, 8, basementConcreteMat, undefined, true);
    // Concrete stairwell flanking walls so player walks straight down the enclosed chute
    addWall(-23.1, -19.85, 3.0, 4.0, 5.3, basementConcreteMat, true, -1.6);
    addWall(-14.9, -19.85, 3.0, 4.0, 5.3, basementConcreteMat, true, -1.6);
    floorZones.push({
      minX: -24.5,
      maxX: -13.5,
      minZ: -39.2,
      maxZ: -22.5,
      yStart: -1.6,
      yEnd: -1.6,
      overrideBase: true,
    });
    const basementFloor = new THREE.Mesh(new THREE.PlaneGeometry(11.4, 17.4), basementConcreteMat);
    basementFloor.rotation.x = -Math.PI / 2;
    basementFloor.position.set(-19.0, -1.6, -31.0);
    basementFloor.receiveShadow = true;
    root.add(basementFloor);

    // Basement concrete retaining walls + overhead ceiling slab (leaving stairwell opening z > -22.5)
    addWall(-13.4, -28.0, 0.6, 6.2, 23.2, basementConcreteMat, true, -1.6);
    addWall(-24.6, -28.0, 0.6, 6.2, 23.2, basementConcreteMat, true, -1.6);
    addWall(-19.0, -39.4, 11.4, 6.2, 0.6, basementConcreteMat, true, -1.6);
    const basementCeil = new THREE.Mesh(new THREE.BoxGeometry(11.2, 0.28, 17.2), basementConcreteMat);
    basementCeil.position.set(-19.0, 1.35, -31.0);
    root.add(basementCeil);

    // Rusted overhead pipes & vertical pipe columns with red gate valve
    const overheadPipeGeo = new THREE.CylinderGeometry(0.11, 0.11, 16.5, 8);
    overheadPipeGeo.rotateX(Math.PI / 2);
    [-16.4, -18.8, -21.2].forEach((px) => {
      const p = new THREE.Mesh(overheadPipeGeo, pipeMat);
      p.position.set(px, 0.95, -30.5);
      root.add(p);
      registerLod(p, 24);
    });
    const vertPipeGeo = new THREE.CylinderGeometry(0.09, 0.09, 2.7, 7);
    [[-14.2, -25.5], [-14.2, -33.5], [-23.8, -29.0]].forEach(([px, pz]) => {
      const vp = new THREE.Mesh(vertPipeGeo, pipeMat);
      vp.position.set(px, -0.25, pz);
      root.add(vp);
      colliders.push({ minX: px - 0.25, maxX: px + 0.25, minZ: pz - 0.25, maxZ: pz + 0.25, active: true });
    });

    // Sparked Electrical Breaker Box & Emergency Red Beacon
    const breaker = buildBasementBreakerPanelModel();
    breaker.group.position.set(-13.85, -1.6, -29.5);
    breaker.group.rotation.y = -Math.PI / 2;
    root.add(breaker.group);

    // Ceiling water leaks & wet puddles
    addDripEmitter(-18.8, 0.85, -1.58, -27.5);
    addDripEmitter(-16.4, 0.85, -1.58, -34.2);

    // Basement metal storage shelves & supplies
    const shelfMat = new THREE.MeshStandardMaterial({ color: 0x2f353b, metalness: 0.65, roughness: 0.5 });
    [[-23.2, -27.5], [-23.2, -33.5]].forEach(([sx, sz]) => {
      const shelf = new THREE.Mesh(new THREE.BoxGeometry(1.1, 2.1, 2.4), shelfMat);
      shelf.position.set(sx, -0.55, sz);
      root.add(shelf);
      colliders.push({ minX: sx - 0.65, maxX: sx + 0.65, minZ: sz - 1.3, maxZ: sz + 1.3, active: true });
      registerLod(shelf, 24);
    });

    addPickup('pickup_c1_base_bat', -18.5, 0.2, -36.5, 'battery', {
      itemId: 'battery',
      labelEn: 'Basement Emergency Battery',
      labelUr: 'تہہ خانے کی ایمرجنسی بیٹری',
    });
    addPickup('pickup_c1_base_band', -21.2, 0.2, -31.0, 'bandage', {
      itemId: 'bandage',
      labelEn: 'Basement First-Aid Kit',
      labelUr: 'تہہ خانے کی ابتدائی طبی پٹی',
    });
    addHideSpot('hide_c1_basement', -21.6, -37.2, Math.PI / 4, true);

    // Strategic Lighting: Corridor fluorescents, Operation Theatre sterile glow & Basement emergency red
    addFlickerLight(0, 3.8, 4, 0xfbbf24, 2.3, 21, 'warm');
    addFlickerLight(-16, 3.8, 1.5, 0xd1fae5, 2.0, 20, 'fluorescent');
    addFlickerLight(16, 3.8, -1.5, 0xd1fae5, 2.0, 20, 'fluorescent');
    addFlickerLight(18.6, 3.5, -19.8, 0x6ee7b7, 2.3, 18, 'fluorescent');
    addFlickerLight(-18.5, 0.7, -30.5, 0xef4444, 2.2, 19, 'emergency');
    addFlickerLight(0, 4.2, -21, 0xa78bfa, 2.0, 22, 'cold');
    addFlickerLight(-8, 3.1, -5.5, 0xf59e0b, 1.4, 15, 'warm');
    addFlickerLight(8, 3.1, -5.5, 0xe11d48, 1.4, 15, 'emergency');

    const doorPlacements: { doorIdx: number; x: number; z: number; rotY: number; roomX: number; roomZ: number }[] = [
      { doorIdx: 0, x: -16, z: 8, rotY: 0, roomX: -16, roomZ: 11 },
      { doorIdx: 1, x: -20.5, z: 0, rotY: Math.PI / 2, roomX: -22.5, roomZ: 0 },
      { doorIdx: 2, x: -16, z: -8, rotY: Math.PI, roomX: -16, roomZ: -11 },
      { doorIdx: 3, x: 16, z: 8, rotY: 0, roomX: 16, roomZ: 11 },
      { doorIdx: 4, x: 20.5, z: 0, rotY: -Math.PI / 2, roomX: 22.5, roomZ: 0 },
      { doorIdx: 5, x: 16, z: -8, rotY: Math.PI, roomX: 16, roomZ: -11 },
      { doorIdx: 6, x: -8, z: -20, rotY: Math.PI, roomX: -8, roomZ: -24 },
      { doorIdx: 7, x: 8, z: -20, rotY: Math.PI, roomX: 8, roomZ: -24 },
      { doorIdx: 8, x: 0, z: -25, rotY: 0, roomX: 0, roomZ: -32 },
    ];

    const pedGeo = new THREE.BoxGeometry(0.75, 0.72, 0.55);
    const pedMat = new THREE.MeshStandardMaterial({ color: 0x261a14, roughness: 0.78 });

    doorPlacements.forEach(({ doorIdx, x, z, rotY, roomX, roomZ }) => {
      const def = DOORS[doorIdx];
      const gyDoor = computeGroundHeight(x, z, chapter, floorZones);
      const gyRoom = computeGroundHeight(roomX, roomZ, chapter, floorZones);
      const isUnlocked =
        (!def.requiredKeyId && !def.requiredPuzzleId) || progress.unlockedDoorIds.includes(def.id);
      const built = buildMysteriousDoorModel(def, isUnlocked, anisotropy, useDetailMaps);
      built.group.position.set(x, gyDoor, z);
      built.group.rotation.y = rotY;
      root.add(built.group);

      if (def.doorNumber === 9) {
        addWall(-6.5, -25, 11.2, 4.0, 0.5, manorWallMat, true, gyDoor);
        addWall(6.5, -25, 11.2, 4.0, 0.5, manorWallMat, true, gyDoor);
      }

      const collider: BoxCollider = {
        id: def.id,
        minX: x - 0.9,
        maxX: x + 0.9,
        minZ: z - 0.9,
        maxZ: z + 0.9,
        active: true,
      };
      colliders.push(collider);

      doors.push({
        doorNumber: def.doorNumber,
        id: def.id,
        group: built.group,
        doorLeaf: built.doorLeaf,
        statusOrbMat: built.statusOrbMat,
        collider,
        openProgress: 0,
        isOpen: false,
        isUnlocked,
      });

      interactables.push({
        id: `interact_${def.id}`,
        type: 'door',
        mesh: built.group,
        position: new THREE.Vector3(x, gyDoor + 1.3, z),
        radius: 2.4,
        labelEn: `${def.nameEn}`,
        labelUr: `${def.nameUr}`,
        doorNumber: def.doorNumber,
      });

      const bottle = BOTTLES.find((b) => b.id === def.bottleId)!;
      const letter = LETTERS.find((l) => l.id === def.letterId)!;

      const ped = new THREE.Mesh(pedGeo, pedMat);
      ped.position.set(roomX, gyRoom + 0.36, roomZ);
      root.add(ped);

      const props = buildDoorInteriorProps(def.style);
      props.position.set(roomX, gyRoom, roomZ);
      root.add(props);

      addPickup(`pickup_${bottle.id}`, roomX - 0.16, 0.74, roomZ, 'bottle', {
        bottleId: bottle.id,
        color: bottle.liquidColor,
        labelEn: `Collect ${bottle.nameEn}`,
        labelUr: `${bottle.nameUr} اٹھائیں`,
      });
      addPickup(`pickup_${letter.id}`, roomX + 0.18, 0.74, roomZ, 'letter', {
        letterId: letter.id,
        labelEn: `Read ${letter.titleEn}`,
        labelUr: `${letter.titleUr} پڑھیں`,
      });
    });

    // 3 Ward Seals (Purifying breaks Zoya's Chapter 1 Manor Anchor)
    const standGeo = new THREE.CylinderGeometry(0.28, 0.36, 0.95, 8);
    const orbGeo = new THREE.OctahedronGeometry(0.2, 0);
    const standMat = new THREE.MeshStandardMaterial({ color: 0x1c1418, roughness: 0.7 });
    [[-11.5, -18], [11.5, -18], [0, -29.5]].forEach(([wx, wz], idx) => {
      const gy = computeGroundHeight(wx, wz, chapter, floorZones);
      const sealGrp = new THREE.Group();
      const stand = new THREE.Mesh(standGeo, standMat);
      stand.position.y = 0.475;
      const orb = new THREE.Mesh(
        orbGeo,
        new THREE.MeshStandardMaterial({ color: 0xe11d48, emissive: 0xe11d48, emissiveIntensity: 1.5 })
      );
      orb.position.y = 1.15;
      sealGrp.add(stand, orb);
      sealGrp.position.set(wx, gy, wz);
      root.add(sealGrp);
      interactables.push({
        id: `ward_c1_${idx}`,
        type: 'brazier',
        mesh: sealGrp,
        position: new THREE.Vector3(wx, gy + 1.0, wz),
        radius: 2.5,
        labelEn: 'Purify Zoya’s Ward Seal',
        labelUr: 'مقدس مہر روشن کریں',
        isLit: false,
      });
    });

    addPickup('pickup_letter_0', 0, 0.74, 5.5, 'letter', {
      letterId: 'letter_0',
      labelEn: 'Read Faded Entry Note',
      labelUr: 'دروازے کا مدھم خط پڑھیں',
    });
    const foyerTable = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 0.72, 0.8),
      new THREE.MeshStandardMaterial({ color: 0x2c1d14, roughness: 0.75 })
    );
    foyerTable.position.set(0, 0.36, 5.5);
    root.add(foyerTable);
    colliders.push({ minX: -0.7, maxX: 0.7, minZ: 5.1, maxZ: 5.9, active: true });

    addPickup('pickup_c1_bat1', -4.5, 0.15, 7, 'battery', {
      itemId: 'battery',
      labelEn: 'Dry Cell Battery',
      labelUr: 'خشک بیٹری',
    });
    addPickup('pickup_c1_bat2', 12.5, 0.15, 5, 'battery', {
      itemId: 'battery',
      labelEn: 'Dry Cell Battery',
      labelUr: 'خشک بیٹری',
    });
    addPickup('pickup_c1_band1', -12.5, 0.15, -5, 'bandage', {
      itemId: 'bandage',
      labelEn: 'Herbal Cloth Bandage',
      labelUr: 'جڑی بوٹیوں والی پٹی',
    });
    addPickup('pickup_c1_map1', 4.5, 0.15, -14, 'map', {
      itemId: 'map_fragment',
      labelEn: 'Torn Blueprint Fragment',
      labelUr: 'نقشے کا پھٹا ہوا ٹکڑا',
    });

    addPuzzleStation('puz_1', -13.5, 10.5, 'puzzle_nursery_clock');
    addPuzzleStation('puz_3', -13.5, -10.5, 'puzzle_mirror_light');
    addPuzzleStation('puz_5', 19.5, -2.5, 'puzzle_bottle_scale');
    addPuzzleStation('puz_6', 13.5, -10.5, 'puzzle_chime_organ');
    addPuzzleStation('puz_7', -8.0, -17.0, 'puzzle_portrait_year');

    addHideSpot('hide_c1_1', -7.8, 4.5, Math.PI / 2);
    addHideSpot('hide_c1_2', -11.5, -3.5, Math.PI / 2);
    addHideSpot('hide_c1_3', 11.5, 3.5, -Math.PI / 2);
    addHideSpot('hide_c1_4', 6.5, -15.5, 0);

    addSaveShrine('save_c1_foyer', 5.8, 7.2);

    const portalY = computeGroundHeight(0, -37.5, chapter, floorZones);
    const exitPortal = new THREE.Mesh(
      new THREE.TorusGeometry(1.1, 0.12, 8, 20),
      new THREE.MeshBasicMaterial({ color: 0x38bdf8 })
    );
    exitPortal.position.set(0, portalY + 1.5, -37.5);
    root.add(exitPortal);
    interactables.push({
      id: 'portal_to_ch2',
      type: 'portal',
      mesh: exitPortal,
      position: new THREE.Vector3(0, portalY + 1.5, -37.5),
      radius: 2.5,
      labelEn: 'Descend to Chapter II: The Haunted Graveyard & Morgue',
      labelUr: 'باب دوم کی طرف جائیں: قبرستان اور سردخانہ',
    });

    patrolWaypoints.push(
      new THREE.Vector3(0, 0, -4),
      new THREE.Vector3(-16, 0, 2),
      new THREE.Vector3(-16, 0, -6),
      new THREE.Vector3(-18.5, -1.6, -28),
      new THREE.Vector3(16.5, 0.72, -16),
      new THREE.Vector3(16, 0, -4),
      new THREE.Vector3(16, 0, 4)
    );

    return {
      root,
      colliders,
      floorZones,
      bounds,
      interactables,
      doors,
      flickerLights,
      flickerTubes,
      dripEmitters,
      lodProps,
      patrolWaypoints,
      playerSpawn: new THREE.Vector3(0, computeGroundHeight(0, 10.5, chapter, floorZones), 10.5),
      aliSpawn: new THREE.Vector3(0, computeGroundHeight(0, -33.5, chapter, floorZones), -33.5),
      bossSpawn: new THREE.Vector3(0, computeGroundHeight(0, -29.0, chapter, floorZones), -29.0),
      quantumShiftObjects,
      dispose: disposeRoot,
    };
  }

  // ============================================================================
  // CHAPTER 2: HAUNTED GRAVEYARD + UNDERGROUND MORGUE
  // ============================================================================
  if (chapter === 2) {
    const groundPbr = getStoneSoilPBRTextures(anisotropy, true);
    const cryptPbr = getStoneSoilPBRTextures(anisotropy, false);
    const morgueTilePbr = getHospitalTilePBRTextures(anisotropy, true);
    morgueTilePbr.map.repeat.set(6, 6);
    morgueTilePbr.bumpMap.repeat.set(6, 6);
    morgueTilePbr.roughnessMap.repeat.set(6, 6);
    const basementPbr = getBasementConcretePBRTextures(anisotropy);

    const groundMat = new THREE.MeshStandardMaterial({
      map: groundPbr.map,
      bumpMap: useDetailMaps ? groundPbr.bumpMap : null,
      bumpScale: 0.055,
      roughnessMap: useDetailMaps ? groundPbr.roughnessMap : null,
      roughness: 0.92,
      metalness: 0.04,
    });
    const stoneMat = new THREE.MeshStandardMaterial({
      map: cryptPbr.map,
      bumpMap: useDetailMaps ? cryptPbr.bumpMap : null,
      bumpScale: 0.04,
      roughnessMap: useDetailMaps ? cryptPbr.roughnessMap : null,
      color: 0x454952,
      roughness: 0.84,
      metalness: 0.1,
    });
    const morgueFloorMat = new THREE.MeshStandardMaterial({
      map: morgueTilePbr.map,
      bumpMap: useDetailMaps ? morgueTilePbr.bumpMap : null,
      bumpScale: 0.036,
      roughnessMap: useDetailMaps ? morgueTilePbr.roughnessMap : null,
      roughness: 0.45,
      metalness: 0.12,
    });
    const morgueWallMat = new THREE.MeshStandardMaterial({
      map: basementPbr.map,
      bumpMap: useDetailMaps ? basementPbr.bumpMap : null,
      bumpScale: 0.05,
      roughness: 0.82,
      metalness: 0.14,
    });
    const ironMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5, metalness: 0.78 });
    const treeBarkMat = new THREE.MeshStandardMaterial({ color: 0x1c1714, roughness: 0.95 });
    const bounds: WorldBounds = { minX: -29.2, maxX: 32.8, minZ: -33.2, maxZ: 29.2 };

    // Moon & pale moonlight halo above Haunted Graveyard
    const moon = new THREE.Mesh(
      new THREE.SphereGeometry(3.4, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0xe2e8f0 })
    );
    moon.position.set(-22, 34, -46);
    const moonHalo = new THREE.Mesh(
      new THREE.SphereGeometry(6.8, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.18, depthWrite: false })
    );
    moonHalo.position.copy(moon.position);
    root.add(moon, moonHalo);

    // Volumetric low-lying drifting graveyard ground mist + morgue condensation
    mistUniforms = { uTime: { value: 0 } };
    const mistPlane = new THREE.Mesh(
      new THREE.PlaneGeometry(78, 78, 1, 1),
      new THREE.ShaderMaterial({
        uniforms: mistUniforms,
        transparent: true,
        depthWrite: false,
        vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          uniform float uTime;
          varying vec2 vUv;
          void main() {
            vec2 p = vUv * 5.5;
            float w1 = sin(p.x * 2.1 + uTime * 0.25) * cos(p.y * 1.9 - uTime * 0.18);
            float w2 = sin(p.x * 4.3 - uTime * 0.32 + p.y * 2.7);
            float density = clamp(0.45 + 0.3 * w1 + 0.2 * w2, 0.0, 0.85);
            float edge = smoothstep(0.0, 0.18, vUv.x) * smoothstep(1.0, 0.82, vUv.x) *
                         smoothstep(0.0, 0.18, vUv.y) * smoothstep(1.0, 0.82, vUv.y);
            gl_FragColor = vec4(0.45, 0.56, 0.68, density * edge * 0.22);
          }
        `,
      })
    );
    mistPlane.rotation.x = -Math.PI / 2;
    mistPlane.position.set(0, 0.36, 0);
    mistPlane.visible = qualityTier !== 'low';
    mistPlane.userData.isVolumetricMist = true;
    root.add(mistPlane);

    // Register Mausoleum Terrace & Underground Morgue FloorZones FIRST so terrain displaces cleanly
    floorZones.push({ minX: -6.5, maxX: 6.5, minZ: -29.0, maxZ: -16.0, yStart: 0.9, yEnd: 0.9 });
    addStairsAlongZ(0, 4.6, -12.5, -16.0, 0, 0.9, 5, stoneMat);

    // Underground Morgue Descent (East Wing: x in [16..32.5], z in [-22.5..2.0])
    addStairsAlongZ(20.5, 4.8, 1.5, -4.5, 0.0, -1.8, 9, stoneMat, undefined, true);
    floorZones.push({
      minX: 16.0,
      maxX: 32.5,
      minZ: -22.5,
      maxZ: -4.5,
      yStart: -1.8,
      yEnd: -1.8,
      overrideBase: true,
    });

    // Terrain grid displaced around hills + cleanly sunken under Morgue footprint
    const terrainGeo = new THREE.PlaneGeometry(140, 140, 56, 56);
    terrainGeo.rotateX(-Math.PI / 2);
    const posAttr = terrainGeo.getAttribute('position') as THREE.BufferAttribute;
    for (let i = 0; i < posAttr.count; i++) {
      const vx = posAttr.getX(i);
      const vz = posAttr.getZ(i);
      const inMorgueRoom = vx >= 15.0 && vx <= 33.5 && vz >= -23.5 && vz <= -4.4;
      const inMorgueStairs = vx >= 17.5 && vx <= 23.5 && vz >= -4.5 && vz <= 2.2;
      if (inMorgueRoom || inMorgueStairs) {
        posAttr.setY(i, Math.min(-0.15, computeGroundHeight(vx, vz, 2, floorZones) - 0.12));
      } else {
        posAttr.setY(i, computeGroundHeight(vx, vz, 2, []));
      }
    }
    terrainGeo.computeVertexNormals();
    const terrain = new THREE.Mesh(terrainGeo, groundMat);
    terrain.receiveShadow = true;
    root.add(terrain);

    // --------------------------------------------------------------------------
    // UNDERGROUND MORGUE ARCHITECTURE & PROPS (Steel Drawers, Exam Tables, Cold Vapour)
    // --------------------------------------------------------------------------
    const morgueFloor = new THREE.Mesh(new THREE.PlaneGeometry(16.8, 18.4), morgueFloorMat);
    morgueFloor.rotation.x = -Math.PI / 2;
    morgueFloor.position.set(24.25, -1.8, -13.5);
    morgueFloor.receiveShadow = true;
    root.add(morgueFloor);

    // Morgue concrete retaining walls & ceiling slab (leaving ONLY stairwell x in [18.1..22.9] open at z=-4.5)
    addWall(15.7, -13.6, 0.6, 5.2, 18.4, morgueWallMat, true, -1.8);
    addWall(32.8, -13.6, 0.6, 5.2, 18.4, morgueWallMat, true, -1.8);
    addWall(24.25, -22.7, 17.4, 5.2, 0.6, morgueWallMat, true, -1.8);
    addWall(16.8, -4.5, 2.4, 3.6, 0.6, morgueWallMat, true, -1.8);
    addWall(28.0, -4.5, 10.2, 3.6, 0.6, morgueWallMat, true, -1.8);
    addWall(17.8, -1.5, 0.6, 4.4, 6.2, stoneMat, true, -1.8);
    addWall(23.2, -1.5, 0.6, 4.4, 6.2, stoneMat, true, -1.8);
    const morgueCeil = new THREE.Mesh(new THREE.BoxGeometry(17.2, 0.35, 18.2), morgueWallMat);
    morgueCeil.position.set(24.25, 1.35, -13.5);
    root.add(morgueCeil);

    // Morgue surface entrance portal stone arch so player spots descent from graveyard
    addWall(17.8, 1.6, 0.6, 2.8, 2.2, stoneMat, true, 0);
    addWall(23.2, 1.6, 0.6, 2.8, 2.2, stoneMat, true, 0);
    const morgueArchCap = new THREE.Mesh(new THREE.BoxGeometry(6.0, 0.55, 2.2), stoneMat);
    morgueArchCap.position.set(20.5, 2.9, 1.6);
    root.add(morgueArchCap);

    // Two Banks of Stainless Steel Body Storage Drawers (each with one half-opened tray!)
    const bankNorth = buildMorgueDrawerBankModel(anisotropy);
    bankNorth.position.set(24.25, -1.8, -21.5);
    root.add(bankNorth);
    colliders.push({ minX: 23.0, maxX: 25.5, minZ: -22.2, maxZ: -20.8, active: true });

    const bankEast = buildMorgueDrawerBankModel(anisotropy);
    bankEast.position.set(31.4, -1.8, -12.5);
    bankEast.rotation.y = -Math.PI / 2;
    root.add(bankEast);
    colliders.push({ minX: 30.7, maxX: 32.1, minZ: -13.7, maxZ: -11.3, active: true });

    // Cold Stainless Steel Examination Tables inside Morgue
    const exam1 = buildExaminationTableModel(anisotropy);
    exam1.position.set(24.0, -1.8, -11.0);
    root.add(exam1);
    colliders.push({ minX: 23.45, maxX: 24.55, minZ: -12.15, maxZ: -9.85, active: true });

    const exam2 = buildExaminationTableModel(anisotropy);
    exam2.position.set(24.0, -1.8, -16.2);
    root.add(exam2);
    colliders.push({ minX: 23.45, maxX: 24.55, minZ: -17.35, maxZ: -15.05, active: true });

    addBloodDecal(24.0, -1.8, -11.0, 1.5, 0.3);
    addBloodDecal(24.8, -1.8, -19.2, 1.2, 1.1);
    addCeilingTube(24.0, 1.1, -9.5, 0, false);
    addCeilingTube(24.0, 1.1, -16.5, 0, true);
    addDripEmitter(26.5, 1.1, -1.78, -14.0);

    // Cold low-lying morgue condensation fog plane
    if (qualityTier !== 'low') {
      const morgueVapor = new THREE.Mesh(
        new THREE.PlaneGeometry(15, 16),
        new THREE.MeshBasicMaterial({
          color: 0x93c5fd,
          transparent: true,
          opacity: 0.14,
          depthWrite: false,
        })
      );
      morgueVapor.rotation.x = -Math.PI / 2;
      morgueVapor.position.set(24.25, -1.5, -13.5);
      morgueVapor.userData.isVolumetricMist = true;
      root.add(morgueVapor);
    }

    const path = new THREE.Mesh(
      new THREE.PlaneGeometry(4.2, 46),
      new THREE.MeshStandardMaterial({ color: 0x26282d, roughness: 0.9 })
    );
    path.rotation.x = -Math.PI / 2;
    path.position.set(0, 0.03, 4);
    root.add(path);

    // Mausoleum Terrace Slab (visual box matching floorZone)
    const mausoleumFloor = new THREE.Mesh(new THREE.BoxGeometry(13, 0.9, 13), stoneMat);
    mausoleumFloor.position.set(0, 0.45, -22.5);
    root.add(mausoleumFloor);

    // Perimeter stone fences
    addWall(0, 30, 62, 2.2, 0.8, stoneMat);
    addWall(0, -34, 62, 2.2, 0.8, stoneMat);
    addWall(-30, -2, 0.8, 2.2, 64, stoneMat);
    addWall(33.4, -2, 0.8, 2.2, 64, stoneMat);

    const treeCoords = [
      [-18, 22], [18, 20], [-24, 6], [22, 10], [-22, -16], [26, -27],
      [-34, -10], [-36, 15], [38, 12], [12, -36], [-14, -38],
    ];
    treeCoords.forEach(([tx, tz], idx) => {
      const tree = buildDeadTreeModel(0.9 + (idx % 3) * 0.25, treeBarkMat);
      tree.position.set(tx, computeGroundHeight(tx, tz, chapter, floorZones), tz);
      tree.rotation.y = idx * 1.1;
      root.add(tree);
      if (Math.abs(tx) < 30 && Math.abs(tz) < 30) {
        colliders.push({ minX: tx - 0.5, maxX: tx + 0.5, minZ: tz - 0.5, maxZ: tz + 0.5, active: true });
      }
    });

    // InstancedMesh for Tombstones & Grave Mounds (clear of East Morgue corridor!)
    const tombPositions: { gx: number; gz: number; gy: number; tilt: number }[] = [];
    for (let row = -2; row <= 2; row++) {
      for (let col = -3; col <= 3; col++) {
        if (Math.abs(col) < 1 && Math.abs(row) < 2) continue;
        const gx = col * 5.5 + (row % 2) * 1.2;
        const gz = row * 6.5;
        if (gz <= -12 && Math.abs(gx) <= 8) continue;
        if (gx >= 13.5 && gz <= 5.0) continue; // Keep Underground Morgue stairwell clear
        const gy = computeGroundHeight(gx, gz, chapter, floorZones);
        const tilt = Math.sin(gx * 1.7 + gz * 2.3) * 0.09;
        tombPositions.push({ gx, gz, gy, tilt });
        colliders.push({ minX: gx - 0.55, maxX: gx + 0.55, minZ: gz - 0.4, maxZ: gz + 1.8, active: true });
      }
    }
    const slabGeo = new THREE.BoxGeometry(0.95, 1.35, 0.25);
    const moundGeo = new THREE.BoxGeometry(1.1, 0.18, 2.0);
    const slabInst = new THREE.InstancedMesh(slabGeo, stoneMat, tombPositions.length);
    const moundInst = new THREE.InstancedMesh(moundGeo, groundMat, tombPositions.length);
    const dummy = new THREE.Object3D();
    tombPositions.forEach((tp, idx) => {
      dummy.position.set(tp.gx, tp.gy + 0.68, tp.gz);
      dummy.rotation.set(0, 0, tp.tilt);
      dummy.updateMatrix();
      slabInst.setMatrixAt(idx, dummy.matrix);

      dummy.position.set(tp.gx, tp.gy + 0.09, tp.gz + 1.0);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      moundInst.setMatrixAt(idx, dummy.matrix);
    });
    slabInst.instanceMatrix.needsUpdate = true;
    moundInst.instanceMatrix.needsUpdate = true;
    root.add(slabInst, moundInst);

    // 4 Mausoleum Pillars + Roof
    [[-4.5, -17.5], [4.5, -17.5], [-4.5, -26.5], [4.5, -26.5]].forEach(([px, pz]) => {
      addWall(px, pz, 1.1, 4.2, 1.1, stoneMat, true, 0.9);
    });
    const mausRoof = new THREE.Mesh(new THREE.ConeGeometry(8.5, 2.6, 4), stoneMat);
    mausRoof.position.set(0, 6.4, -22);
    mausRoof.rotation.y = Math.PI / 4;
    root.add(mausRoof);

    // Four Weeping Statues
    const plinthGeo = new THREE.BoxGeometry(0.9, 1.0, 0.9);
    const sBodyGeo = new THREE.ConeGeometry(0.35, 1.3, 7);
    const sHeadGeo = new THREE.SphereGeometry(0.18, 8, 8);
    [[0, -5], [5, 0], [0, 5], [-5, 0]].forEach(([sx, sz]) => {
      const gy = computeGroundHeight(sx, sz, chapter, floorZones);
      const statue = new THREE.Group();
      const plinth = new THREE.Mesh(plinthGeo, stoneMat);
      plinth.position.y = 0.5;
      const body = new THREE.Mesh(sBodyGeo, stoneMat);
      body.position.y = 1.65;
      const head = new THREE.Mesh(sHeadGeo, stoneMat);
      head.position.y = 2.4;
      statue.add(plinth, body, head);
      statue.position.set(sx, gy, sz);
      root.add(statue);
      colliders.push({ minX: sx - 0.5, maxX: sx + 0.5, minZ: sz - 0.5, maxZ: sz + 0.5, active: true });
    });

    addPuzzleStation('puz_c2_statues', 0, -2.5, 'puzzle_statues');

    const bowlGeo = new THREE.CylinderGeometry(0.45, 0.25, 0.9, 8);
    const emberGeo = new THREE.SphereGeometry(0.22, 7, 7);
    [[-5.5, -18], [5.5, -18], [0, -26]].forEach(([bx, bz], idx) => {
      const gy = computeGroundHeight(bx, bz, chapter, floorZones);
      const brazier = new THREE.Group();
      const bowl = new THREE.Mesh(bowlGeo, ironMat);
      bowl.position.y = 0.45;
      const ember = new THREE.Mesh(
        emberGeo,
        new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0xea580c, emissiveIntensity: 0.65 })
      );
      ember.position.y = 0.92;
      brazier.add(bowl, ember);
      brazier.position.set(bx, gy, bz);
      root.add(brazier);

      interactables.push({
        id: `brazier_${idx}`,
        type: 'brazier',
        mesh: brazier,
        position: new THREE.Vector3(bx, gy + 0.9, bz),
        radius: 2.5,
        labelEn: 'Ignite Ward Brazier (Weakens Zoya’s Tether)',
        labelUr: 'مقدس مشعل روشن کریں',
        isLit: false,
      });
    });

    addPickup('pickup_letter_10', -3.2, 0.3, 14, 'letter', {
      letterId: 'letter_10',
      labelEn: 'Read Gravekeeper’s Log',
      labelUr: 'گورکن کا روزنامچہ پڑھیں',
    });
    addPickup('pickup_letter_11', 12, 0.3, -6, 'letter', {
      letterId: 'letter_11',
      labelEn: 'Inspect Unmarked Tomb Epitaph (A.A.)',
      labelUr: 'بے نام قبر کا کتبہ پڑھیں',
    });
    // Place Blackened Sun Medallion visibly inside the Underground Morgue!
    addPickup('pickup_shard_sun', 24.0, 0.98, -11.0, 'shard', {
      itemId: 'shard_sun',
      labelEn: 'Blackened Sun Medallion (Morgue Table)',
      labelUr: 'سیاہ سورج تمغہ (سردخانہ میز)',
    });
    addPickup('pickup_c2_bat1', -12, 0.2, 4, 'battery', {
      itemId: 'battery',
      labelEn: 'Dry Cell Battery',
      labelUr: 'خشک بیٹری',
    });
    addPickup('pickup_c2_band1', 21.5, 0.2, -14.0, 'bandage', {
      itemId: 'bandage',
      labelEn: 'Morgue Sterile Bandage',
      labelUr: 'سردخانے کی پٹی',
    });
    addPickup('pickup_c2_map2', -18, 0.2, -14, 'map', {
      itemId: 'map_fragment',
      labelEn: 'Morgue Blueprint Fragment',
      labelUr: 'سردخانے کا نقشہ',
    });

    addHideSpot('hide_c2_1', -10, 12, Math.PI / 2, true);
    addHideSpot('hide_c2_2', 10, -10, -Math.PI / 2, true);
    addHideSpot('hide_c2_morgue', 17.5, -18.5, Math.PI / 2, true);
    addSaveShrine('save_c2_gate', 4.5, 22);

    const postMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8, roughness: 0.35 });
    const lanternGlassMat = new THREE.MeshBasicMaterial({ color: 0xfde68a });
    [[-3.0, 14], [3.0, 4], [-3.0, -6]].forEach(([lx, lz]) => {
      const gy = computeGroundHeight(lx, lz, chapter, floorZones);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 3.0, 6), postMat);
      pole.position.set(lx, gy + 1.5, lz);
      const cap = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.32, 0.28), lanternGlassMat);
      cap.position.set(lx, gy + 3.05, lz);
      root.add(pole, cap);
    });

    addFlickerLight(0, 3.8, 22, 0xf59e0b, 2.2, 20, 'warm');
    addFlickerLight(0, 5.0, -22, 0x38bdf8, 2.0, 24, 'cold');
    addFlickerLight(24, 0.6, -11, 0xbae6fd, 2.3, 22, 'fluorescent');
    addFlickerLight(24, 0.6, -18, 0x93c5fd, 1.9, 18, 'fluorescent');
    addFlickerLight(0, 3.6, 4, 0xfde68a, 1.6, 18, 'warm');

    const pY = computeGroundHeight(0, -24.5, chapter, floorZones);
    const riftPortal = new THREE.Mesh(
      new THREE.TorusGeometry(1.3, 0.14, 8, 20),
      new THREE.MeshBasicMaterial({ color: 0xc084fc })
    );
    riftPortal.position.set(0, pY + 1.8, -24.5);
    root.add(riftPortal);
    interactables.push({
      id: 'portal_to_ch3',
      type: 'portal',
      mesh: riftPortal,
      position: new THREE.Vector3(0, pY + 1.8, -24.5),
      radius: 2.6,
      labelEn: 'Enter Chapter III: The Secret Dimension',
      labelUr: 'باب سوم میں داخل ہوں: خفیہ جہان',
    });

    patrolWaypoints.push(
      new THREE.Vector3(-10, 0, 8),
      new THREE.Vector3(12, 0, 6),
      new THREE.Vector3(24, -1.8, -12),
      new THREE.Vector3(-12, 0, -12),
      new THREE.Vector3(0, 0.9, -18)
    );

    return {
      root,
      colliders,
      floorZones,
      bounds,
      interactables,
      doors,
      flickerLights,
      flickerTubes,
      dripEmitters,
      lodProps,
      patrolWaypoints,
      playerSpawn: new THREE.Vector3(0, computeGroundHeight(0, 24, chapter, floorZones), 24),
      aliSpawn: new THREE.Vector3(-2.0, computeGroundHeight(-2.0, 25, chapter, floorZones), 25),
      bossSpawn: new THREE.Vector3(0, computeGroundHeight(0, -14, chapter, floorZones), -14),
      quantumShiftObjects,
      mistUniforms,
      dispose: disposeRoot,
    };
  }

  // ============================================================================
  // CHAPTER 3: THE SECRET DIMENSION (Fractured Memory Fragments)
  // ============================================================================
  const runePbr = getDimensionRunePBRTextures(anisotropy);
  const obsidianFloorMat = new THREE.MeshStandardMaterial({
    map: runePbr.map,
    bumpMap: useDetailMaps ? runePbr.bumpMap : null,
    bumpScale: 0.03,
    roughnessMap: useDetailMaps ? runePbr.roughnessMap : null,
    emissiveMap: useDetailMaps ? runePbr.emissiveMap : null,
    emissive: new THREE.Color(0x9d174d),
    emissiveIntensity: 0.65,
    color: 0x1b142d,
    roughness: 0.32,
    metalness: 0.68,
  });
  const pillarMat = new THREE.MeshStandardMaterial({
    color: 0x110c1c,
    roughness: 0.26,
    metalness: 0.74,
  });
  const bounds: WorldBounds = { minX: -32.8, maxX: 11.8, minZ: -34.8, maxZ: 29.8 };

  const createFlatPlatform = (x: number, z: number, w: number, d: number, topY: number) => {
    const plat = new THREE.Mesh(new THREE.BoxGeometry(w, 0.8, d), obsidianFloorMat);
    plat.position.set(x, topY - 0.4, z);
    root.add(plat);
    floorZones.push({
      minX: x - w / 2,
      maxX: x + w / 2,
      minZ: z - d / 2,
      maxZ: z + d / 2,
      yStart: topY,
      yEnd: topY,
    });
  };

  createFlatPlatform(0, 22, 16, 16, 0);
  createFlatPlatform(0, 0, 24, 20, 0.6);
  createFlatPlatform(0, -26, 22, 18, 1.4);
  createFlatPlatform(-26, -14, 14, 14, 1.1);

  addStairsAlongZ(0, 6, 14.0, 10.0, 0, 0.6, 4, obsidianFloorMat);
  addStairsAlongZ(0, 6, -10.0, -17.0, 0.6, 1.4, 5, obsidianFloorMat);

  floorZones.push({
    minX: -19.0,
    maxX: -12.0,
    minZ: -17.0,
    maxZ: -11.0,
    yStart: 1.1,
    yEnd: 0.6,
    axis: 'x',
  });
  for (let i = 0; i < 4; i++) {
    const stepX = -12.875 - i * 1.75;
    const h = 0.6 + ((i + 1) / 4) * 0.5;
    const s = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.4, 6), obsidianFloorMat);
    s.position.set(stepX, h - 0.2, -14);
    root.add(s);
  }
  createFlatPlatform(-12, -12, 8, 6, 0.6);

  addWall(0, 30.2, 17, 1.4, 0.5, pillarMat);
  addWall(-8.3, 22, 0.5, 1.4, 16, pillarMat);
  addWall(8.3, 22, 0.5, 1.4, 16, pillarMat);
  addWall(0, -35.2, 23, 1.4, 0.5, pillarMat);
  addWall(11.3, -26, 0.5, 1.4, 18, pillarMat, true, 1.4);
  addWall(-11.3, -26, 0.5, 1.4, 18, pillarMat, true, 1.4);
  addWall(12.2, 0, 0.5, 1.4, 20, pillarMat, true, 0.6);
  addWall(-33.2, -14, 0.5, 1.4, 14, pillarMat, true, 1.1);

  // Suspended fractured hospital memory remnants orbiting the void
  const suspendedBed = buildHospitalBedModel(false);
  suspendedBed.position.set(16, 4.2, -4);
  suspendedBed.rotation.set(0.25, 0.6, -0.18);
  root.add(suspendedBed);
  quantumShiftObjects.push(suspendedBed);

  const suspendedChair = buildWheelchairModel();
  suspendedChair.position.set(-15, 3.8, 8);
  suspendedChair.rotation.set(-0.2, 0.9, 0.14);
  root.add(suspendedChair);
  quantumShiftObjects.push(suspendedChair);

  const quantumGeo = new THREE.BoxGeometry(1.8, 7.5, 1.8);
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    const fx = Math.cos(angle) * 18;
    const fz = Math.sin(angle) * 22 - 4;
    const block = new THREE.Mesh(quantumGeo, pillarMat);
    block.position.set(fx, 4.5 + (i % 3) * 2.2, fz);
    block.rotation.set(0.15 * (i % 2), angle, 0.2);
    block.userData.sharedGeo = true;
    root.add(block);
    quantumShiftObjects.push(block);
  }

  const spireGeo = new THREE.OctahedronGeometry(0.42, 0);
  const anchorPedGeo = new THREE.CylinderGeometry(0.35, 0.5, 0.9, 6);
  [[-7, -23], [7, -23], [0, -31]].forEach(([ax, az], idx) => {
    const gy = computeGroundHeight(ax, az, chapter, floorZones);
    const anchor = new THREE.Group();
    const spire = new THREE.Mesh(
      spireGeo,
      new THREE.MeshStandardMaterial({ color: 0xe11d48, emissive: 0xbe123c, emissiveIntensity: 1.5 })
    );
    spire.position.y = 1.25;
    const ped = new THREE.Mesh(anchorPedGeo, pillarMat);
    ped.position.y = 0.45;
    anchor.add(ped, spire);
    anchor.position.set(ax, gy, az);
    root.add(anchor);
    interactables.push({
      id: `brazier_c3_${idx}`,
      type: 'brazier',
      mesh: anchor,
      position: new THREE.Vector3(ax, gy + 1.1, az),
      radius: 2.5,
      labelEn: 'Stabilize Reality Anchor',
      labelUr: 'حقیقت کا ستون بحال کریں',
      isLit: false,
    });
  });

  const crystalGeo = new THREE.OctahedronGeometry(0.35, 0);
  [[-21.5, -10], [-30.5, -10], [-21.5, -18], [-30.5, -18]].forEach(([sx, sz], idx) => {
    const gy = computeGroundHeight(sx, sz, chapter, floorZones);
    const shardGrp = new THREE.Group();
    const ped = new THREE.Mesh(anchorPedGeo, pillarMat);
    ped.position.y = 0.425;
    const crystal = new THREE.Mesh(
      crystalGeo,
      new THREE.MeshStandardMaterial({ color: 0xec4899, emissive: 0xdb2777, emissiveIntensity: 1.8 })
    );
    crystal.position.y = 1.2;
    shardGrp.add(ped, crystal);
    shardGrp.position.set(sx, gy, sz);
    root.add(shardGrp);
    interactables.push({
      id: `secret_shard_${idx}`,
      type: 'brazier',
      mesh: shardGrp,
      position: new THREE.Vector3(sx, gy + 1.0, sz),
      radius: 2.5,
      labelEn: 'Shatter Rift Soul Shard',
      labelUr: 'خفیہ خلائی شیشہ توڑیں',
      isLit: false,
    });
  });

  addPickup('pickup_letter_12', 0, 0.25, 17, 'letter', {
    letterId: 'letter_12',
    labelEn: 'Read The Architect’s Ledger (A.A.)',
    labelUr: 'معمار کی کتاب پڑھیں',
  });
  addPickup('pickup_c3_bat1', -7, 0.2, 2, 'battery', {
    itemId: 'battery',
    labelEn: 'Dry Cell Battery',
    labelUr: 'خشک بیٹری',
  });
  addPickup('pickup_c3_band1', 7, 0.2, -2, 'bandage', {
    itemId: 'bandage',
    labelEn: 'Herbal Cloth Bandage',
    labelUr: 'جڑی بوٹیوں والی پٹی',
  });

  addPuzzleStation('puz_c3_quantum', -9.5, -2.0, 'puzzle_quantum_cipher');
  addHideSpot('hide_c3_1', 8.5, 2.5, -Math.PI / 2, true);
  addSaveShrine('save_c3_start', 4.5, 22);

  const finalY = computeGroundHeight(0, -33.5, chapter, floorZones);
  const finalGate = new THREE.Mesh(
    new THREE.TorusGeometry(1.5, 0.16, 8, 20),
    new THREE.MeshBasicMaterial({ color: 0xf59e0b })
  );
  finalGate.position.set(0, finalY + 1.9, -33.5);
  root.add(finalGate);
  interactables.push({
    id: 'portal_final_truth',
    type: 'portal',
    mesh: finalGate,
    position: new THREE.Vector3(0, finalY + 1.9, -33.5),
    radius: 2.8,
    labelEn: 'Step Through the Final Reality Threshold',
    labelUr: 'آخری حقیقت کے دروازے سے گزریں',
  });

  const secretY = computeGroundHeight(-28, -14, chapter, floorZones);
  const secretAltar = new THREE.Mesh(
    new THREE.TorusGeometry(1.4, 0.16, 8, 20),
    new THREE.MeshBasicMaterial({ color: 0xec4899 })
  );
  secretAltar.position.set(-28, secretY + 1.9, -14);
  secretAltar.rotation.y = Math.PI / 2;
  root.add(secretAltar);
  interactables.push({
    id: 'portal_secret_ending',
    type: 'portal',
    mesh: secretAltar,
    position: new THREE.Vector3(-28, secretY + 1.9, -14),
    radius: 2.8,
    labelEn: 'Enter Secret Rift Sanctum (Ultimate Challenge)',
    labelUr: 'خفیہ خلائی دروازے میں داخل ہوں',
  });

  addFlickerLight(0, 4.5, 22, 0xa855f7, 2.0, 20, 'cold');
  addFlickerLight(0, 5.6, 0, 0xe11d48, 2.0, 22, 'emergency');
  addFlickerLight(0, 6.4, -26, 0xf59e0b, 2.2, 24, 'warm');
  addFlickerLight(-26, 5.2, -14, 0xec4899, 2.2, 20, 'emergency');

  patrolWaypoints.push(
    new THREE.Vector3(-6, 0.6, 4),
    new THREE.Vector3(6, 0.6, 4),
    new THREE.Vector3(6, 0.6, -4),
    new THREE.Vector3(-6, 0.6, -4)
  );

  return {
    root,
    colliders,
    floorZones,
    bounds,
    interactables,
    doors,
    flickerLights,
    flickerTubes,
    dripEmitters,
    lodProps,
    patrolWaypoints,
    playerSpawn: new THREE.Vector3(0, computeGroundHeight(0, 24, chapter, floorZones), 24),
    aliSpawn: new THREE.Vector3(-2.2, computeGroundHeight(-2.2, 25, chapter, floorZones), 25),
    bossSpawn: new THREE.Vector3(0, computeGroundHeight(0, -26, chapter, floorZones), -26),
    quantumShiftObjects,
    dispose: disposeRoot,
  };
}
