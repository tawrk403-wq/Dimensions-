import * as THREE from 'three';
import { DoorDef } from '../types/game';
import {
  getContactShadowTexture,
  getCRTMonitorTexture,
  getDoorPlaqueTexture,
  getGhostGownPBRTextures,
  getGhostSkinPBRTextures,
  getStainlessSteelPBRTextures,
  getStoneSoilPBRTextures,
  getWoodPBRTextures,
} from './textures';

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX'];

// Shared lightweight reusable geometry/material caches for low draw-call & GC overhead
let sharedShadowGeo: THREE.PlaneGeometry | null = null;
let sharedShadowMat: THREE.MeshBasicMaterial | null = null;
let sharedBottleGlassGeo: THREE.LatheGeometry | null = null;
let sharedBottleGlassMat: THREE.MeshPhysicalMaterial | null = null;
let sharedBottleLiquidGeo: THREE.CylinderGeometry | null = null;
let sharedBottleCorkGeo: THREE.CylinderGeometry | null = null;
let sharedBottleCorkMat: THREE.MeshStandardMaterial | null = null;
let sharedBottleLabelGeo: THREE.CylinderGeometry | null = null;
let sharedBottleLabelMat: THREE.MeshStandardMaterial | null = null;

export function createContactShadowPlane(radius = 0.65): THREE.Mesh {
  if (!sharedShadowGeo) {
    sharedShadowGeo = new THREE.PlaneGeometry(1, 1);
  }
  if (!sharedShadowMat) {
    sharedShadowMat = new THREE.MeshBasicMaterial({
      map: getContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.72,
    });
  }
  const mesh = new THREE.Mesh(sharedShadowGeo, sharedShadowMat);
  mesh.scale.set(radius * 2, radius * 2, 1);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.02;
  mesh.userData.sharedAsset = true;
  return mesh;
}

export interface FemaleGhostRig {
  group: THREE.Group;
  bodyPivot: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftForearm: THREE.Group;
  rightForearm: THREE.Group;
  leftLeg: THREE.Mesh;
  rightLeg: THREE.Mesh;
  veil: THREE.Mesh;
  shroudMat: THREE.MeshStandardMaterial;
  skinMat: THREE.MeshStandardMaterial;
  eyesMat: THREE.MeshBasicMaterial;
}

/**
 * SOLE FEMALE GHOST: ZOYA
 * Pale damaged corpse skin with veins, gaunt sunken skull & twisted jaw,
 * dense messy black hair strands hanging unevenly over shoulders/face,
 * torn blood-stained burial shroud, and full spine/limb articulation for
 * unnatural twitching walk & terrifying 4-limb floor crawl.
 */
export function buildFemaleGhostModel(): FemaleGhostRig {
  const group = new THREE.Group();
  const bodyPivot = new THREE.Group();
  bodyPivot.position.y = 0.88;
  group.add(bodyPivot);

  const skinTex = getGhostSkinPBRTextures();
  const gownTex = getGhostGownPBRTextures();

  const dressMat = new THREE.MeshStandardMaterial({
    map: gownTex.map,
    bumpMap: gownTex.bumpMap,
    bumpScale: 0.03,
    roughness: 0.9,
    metalness: 0.05,
  });
  const shroudMat = new THREE.MeshStandardMaterial({
    map: gownTex.map,
    color: 0x261d24,
    emissive: 0x28060f,
    emissiveIntensity: 0.32,
    transparent: true,
    opacity: 0.72,
    side: THREE.DoubleSide,
    depthWrite: false,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    map: skinTex.map,
    bumpMap: skinTex.bumpMap,
    bumpScale: 0.025,
    color: 0xcbd2da,
    roughness: 0.52,
    metalness: 0.04,
    emissive: 0x161c22,
    emissiveIntensity: 0.25,
  });
  const socketMat = new THREE.MeshStandardMaterial({ color: 0x050407, roughness: 0.96 });
  const mouthMat = new THREE.MeshStandardMaterial({ color: 0x140406, roughness: 0.88 });
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x050507, roughness: 0.88 });
  const eyesMat = new THREE.MeshBasicMaterial({ color: 0xe11d48 });
  const clawMat = new THREE.MeshStandardMaterial({ color: 0x19080b, roughness: 0.42, metalness: 0.28 });

  // Lower pelvis & articulated legs (for walking stride & splayed crawl posture)
  const legGeo = new THREE.CylinderGeometry(0.05, 0.032, 0.86, 7);
  legGeo.translate(0, -0.43, 0);
  const leftLeg = new THREE.Mesh(legGeo, skinMat);
  leftLeg.position.set(-0.1, 0, 0);
  const rightLeg = new THREE.Mesh(legGeo, skinMat);
  rightLeg.position.set(0.1, 0, 0);
  bodyPivot.add(leftLeg, rightLeg);

  // Ragged knee-to-ankle burial skirt wrapping torso lower half
  const skirtPts = [
    new THREE.Vector2(0.38, -0.82),
    new THREE.Vector2(0.28, -0.44),
    new THREE.Vector2(0.19, -0.1),
    new THREE.Vector2(0.15, 0.08),
  ];
  const skirt = new THREE.Mesh(new THREE.LatheGeometry(skirtPts, 11), dressMat);
  skirt.castShadow = true;
  bodyPivot.add(skirt);

  // Articulated upper spine/torso
  const torso = new THREE.Group();
  torso.position.y = 0.06;
  bodyPivot.add(torso);

  const chestMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.145, 0.165, 0.52, 9), dressMat);
  chestMesh.position.y = 0.28;
  chestMesh.castShadow = true;
  torso.add(chestMesh);

  const collarRuffle = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.032, 5, 11), dressMat);
  collarRuffle.rotation.x = Math.PI / 2;
  collarRuffle.position.y = 0.54;
  torso.add(collarRuffle);

  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.044, 0.052, 0.14, 7), skinMat);
  neck.position.y = 0.6;
  torso.add(neck);

  // Flowing tattered shroud behind spine
  const veil = new THREE.Mesh(new THREE.PlaneGeometry(0.68, 1.24, 4, 4), shroudMat);
  veil.position.set(0, -0.04, -0.18);
  veil.rotation.x = 0.16;
  torso.add(veil);

  // Sculpted gaunt horror face & jaw + long tangled black hair locks
  const head = new THREE.Group();
  head.position.set(0, 0.72, 0.02);

  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.128, 12, 10), skinMat);
  cranium.scale.set(0.88, 1.08, 0.96);
  head.add(cranium);

  const browRidge = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.024, 0.06), skinMat);
  browRidge.position.set(0, 0.045, 0.1);
  head.add(browRidge);

  const jaw = new THREE.Mesh(new THREE.CylinderGeometry(0.072, 0.042, 0.125, 8), skinMat);
  jaw.position.set(0, -0.095, 0.036);
  head.add(jaw);

  // Disturbing gaping dark mouth shadow
  const mouthCavity = new THREE.Mesh(new THREE.SphereGeometry(0.034, 7, 6), mouthMat);
  mouthCavity.scale.set(0.82, 1.25, 0.5);
  mouthCavity.position.set(0, -0.075, 0.092);
  head.add(mouthCavity);

  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.018, 0.048, 0.034), skinMat);
  nose.position.set(0, -0.008, 0.122);
  head.add(nose);

  const socketL = new THREE.Mesh(new THREE.SphereGeometry(0.031, 7, 7), socketMat);
  socketL.scale.set(1.1, 0.95, 0.55);
  socketL.position.set(-0.044, 0.02, 0.105);
  const socketR = socketL.clone();
  socketR.position.x = 0.044;
  head.add(socketL, socketR);

  // Subtle pinpoint sunken glint inside blackened sockets (eerie, not cartoonish)
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.009, 6, 6), eyesMat);
  eyeL.position.set(-0.044, 0.02, 0.12);
  const eyeR = eyeL.clone();
  eyeR.position.x = 0.044;
  head.add(eyeL, eyeR);

  // Multi-layered messy long black hair draping over shoulders & side of face
  const hairCrown = new THREE.Mesh(
    new THREE.SphereGeometry(0.138, 11, 8, 0, Math.PI * 2, 0, Math.PI * 0.56),
    hairMat
  );
  hairCrown.position.y = 0.022;
  head.add(hairCrown);

  const hairBack = new THREE.Mesh(new THREE.CylinderGeometry(0.135, 0.24, 0.88, 10, 1, true), hairMat);
  hairBack.position.set(0, -0.32, -0.035);
  head.add(hairBack);

  const strandSpec: [number, number, number, number, number][] = [
    [-0.105, -0.18, 0.08, 0.04, 0.62],
    [0.105, -0.22, 0.075, -0.06, 0.68],
    [-0.068, -0.14, 0.105, 0.09, 0.44],
    [0.055, -0.12, 0.11, -0.12, 0.38],
    [-0.12, -0.28, -0.02, 0.14, 0.72],
    [0.12, -0.26, -0.02, -0.14, 0.7],
  ];
  strandSpec.forEach(([sx, sy, sz, rz, len]) => {
    const strand = new THREE.Mesh(new THREE.BoxGeometry(0.032, len, 0.034), hairMat);
    strand.position.set(sx, sy, sz);
    strand.rotation.z = rz;
    head.add(strand);
  });

  torso.add(head);

  // Articulated Upper Arms + Forearms + Clawed Hands (2-bone reach for realistic crawl & walk)
  const upperArmGeo = new THREE.CylinderGeometry(0.034, 0.026, 0.36, 7);
  upperArmGeo.translate(0, -0.18, 0);
  const forearmGeo = new THREE.CylinderGeometry(0.025, 0.017, 0.36, 7);
  forearmGeo.translate(0, -0.18, 0);
  const clawGeo = new THREE.ConeGeometry(0.009, 0.075, 4);

  const makeArm = (side: -1 | 1) => {
    const upper = new THREE.Group();
    upper.position.set(side * 0.19, 0.51, 0);
    const upperMesh = new THREE.Mesh(upperArmGeo, skinMat);
    upperMesh.castShadow = true;
    upper.add(upperMesh);

    const fore = new THREE.Group();
    fore.position.set(0, -0.35, 0);
    const foreMesh = new THREE.Mesh(forearmGeo, skinMat);
    fore.add(foreMesh);

    [-0.013, 0, 0.013].forEach((cx) => {
      const cl = new THREE.Mesh(clawGeo, clawMat);
      cl.rotation.x = Math.PI;
      cl.position.set(cx, -0.37, 0.015);
      fore.add(cl);
    });
    upper.add(fore);
    torso.add(upper);
    return { upper, fore };
  };

  const armL = makeArm(-1);
  const armR = makeArm(1);

  group.add(createContactShadowPlane(0.62));

  return {
    group,
    bodyPivot,
    torso,
    head,
    leftArm: armL.upper,
    rightArm: armR.upper,
    leftForearm: armL.fore,
    rightForearm: armR.fore,
    leftLeg,
    rightLeg,
    veil,
    shroudMat,
    skinMat,
    eyesMat,
  };
}

/**
 * Abandoned Hospital Bed with Rusted Frame, Stained Mattress & IV Pole
 */
export function buildHospitalBedModel(hasIvStand = true): THREE.Group {
  const group = new THREE.Group();
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x3b3f44, metalness: 0.72, roughness: 0.48 });
  const mattressMat = new THREE.MeshStandardMaterial({ color: 0x8b8677, roughness: 0.92 });
  const stainMat = new THREE.MeshStandardMaterial({ color: 0x451215, roughness: 0.85 });
  const sheetMat = new THREE.MeshStandardMaterial({ color: 0x626b64, roughness: 0.9 });

  // Bed deck & stained mattress
  const frame = new THREE.Mesh(new THREE.BoxGeometry(1.06, 0.1, 2.08), metalMat);
  frame.position.y = 0.54;
  frame.castShadow = true;
  group.add(frame);

  const mattress = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.18, 1.98), mattressMat);
  mattress.position.y = 0.68;
  mattress.receiveShadow = true;
  group.add(mattress);

  const bloodPatch = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.015, 0.72), stainMat);
  bloodPatch.position.set(0.08, 0.775, 0.15);
  const pillow = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.1, 0.36), sheetMat);
  pillow.position.set(0, 0.82, -0.72);
  pillow.rotation.z = 0.06;
  group.add(bloodPatch, pillow);

  // 4 tubular corner legs & headboard/footboard rails
  const legGeo = new THREE.CylinderGeometry(0.025, 0.025, 0.56, 6);
  [[-0.48, -0.98], [0.48, -0.98], [-0.48, 0.98], [0.48, 0.98]].forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(legGeo, metalMat);
    leg.position.set(lx, 0.28, lz);
    group.add(leg);
  });

  const headRail = new THREE.Mesh(new THREE.BoxGeometry(1.04, 0.52, 0.05), metalMat);
  headRail.position.set(0, 0.88, -1.0);
  const footRail = new THREE.Mesh(new THREE.BoxGeometry(1.04, 0.36, 0.05), metalMat);
  footRail.position.set(0, 0.78, 1.0);
  group.add(headRail, footRail);

  if (hasIvStand) {
    const ivPole = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.022, 1.85, 6), metalMat);
    ivPole.position.set(0.66, 0.925, -0.78);
    const ivBase = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.2, 0.05, 6), metalMat);
    ivBase.position.set(0.66, 0.025, -0.78);
    const ivBag = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.2, 0.05), sheetMat);
    ivBag.position.set(0.66, 1.66, -0.78);
    group.add(ivPole, ivBase, ivBag);
  }

  return group;
}

/**
 * Abandoned Hospital Wheelchair with Spoked Drive Wheels & Caster Wheels
 */
export function buildWheelchairModel(): THREE.Group {
  const group = new THREE.Group();
  const steelMat = new THREE.MeshStandardMaterial({ color: 0x4b5158, metalness: 0.78, roughness: 0.42 });
  const leatherMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.88 });
  const rubberMat = new THREE.MeshStandardMaterial({ color: 0x101012, roughness: 0.92 });

  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.56, 0.06, 0.54), leatherMat);
  seat.position.set(0, 0.52, 0);
  const back = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.52, 0.06), leatherMat);
  back.position.set(0, 0.8, -0.26);
  group.add(seat, back);

  const armGeo = new THREE.BoxGeometry(0.05, 0.04, 0.48);
  const armL = new THREE.Mesh(armGeo, steelMat);
  armL.position.set(-0.29, 0.72, -0.02);
  const armR = armL.clone();
  armR.position.x = 0.29;
  group.add(armL, armR);

  // Rear big drive wheels + hubs
  const wheelGeo = new THREE.TorusGeometry(0.32, 0.028, 6, 16);
  const spokeGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.62, 4);
  [-0.33, 0.33].forEach((wx) => {
    const wheel = new THREE.Mesh(wheelGeo, rubberMat);
    wheel.rotation.y = Math.PI / 2;
    wheel.position.set(wx, 0.34, -0.08);
    group.add(wheel);

    for (let s = 0; s < 3; s++) {
      const sp = new THREE.Mesh(spokeGeo, steelMat);
      sp.position.set(wx, 0.34, -0.08);
      sp.rotation.x = (s / 3) * Math.PI;
      group.add(sp);
    }
  });

  // Small front caster wheels
  const casterGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.04, 10);
  [-0.26, 0.26].forEach((cx) => {
    const caster = new THREE.Mesh(casterGeo, rubberMat);
    caster.rotation.z = Math.PI / 2;
    caster.position.set(cx, 0.09, 0.28);
    group.add(caster);
  });

  return group;
}

/**
 * Hanging Ceiling Fluorescent Tube Light (Intact flickering or Broken dangling variant)
 */
export function buildFluorescentFixtureModel(broken = false): {
  group: THREE.Group;
  tubeMat: THREE.MeshBasicMaterial;
} {
  const group = new THREE.Group();
  const housingMat = new THREE.MeshStandardMaterial({ color: 0x3b4046, metalness: 0.65, roughness: 0.45 });
  const tubeMat = new THREE.MeshBasicMaterial({ color: broken ? 0x263232 : 0xd1fae5 });

  const bar = new THREE.Mesh(new THREE.BoxGeometry(1.75, 0.08, 0.26), housingMat);
  if (broken) {
    bar.rotation.z = 0.28;
    bar.position.y = -0.18;
  }
  group.add(bar);

  const tubeGeo = new THREE.CylinderGeometry(0.025, 0.025, 1.56, 6);
  tubeGeo.rotateZ(Math.PI / 2);
  const tubeA = new THREE.Mesh(tubeGeo, tubeMat);
  tubeA.position.set(0, broken ? -0.22 : -0.05, 0.06);
  if (broken) tubeA.rotation.z = 0.28;
  group.add(tubeA);

  if (!broken) {
    const tubeB = new THREE.Mesh(tubeGeo, tubeMat);
    tubeB.position.set(0, -0.05, -0.06);
    group.add(tubeB);
  }
  return { group, tubeMat };
}

/**
 * Underground Morgue Stainless Steel Body Storage Drawer Vault (3x2 grid, one drawer ajar!)
 */
export function buildMorgueDrawerBankModel(anisotropy = 2): THREE.Group {
  const group = new THREE.Group();
  const steelPbr = getStainlessSteelPBRTextures(anisotropy);
  const steelMat = new THREE.MeshStandardMaterial({
    map: steelPbr.map,
    bumpMap: steelPbr.bumpMap,
    bumpScale: 0.02,
    roughnessMap: steelPbr.roughnessMap,
    metalness: 0.85,
    roughness: 0.34,
  });
  const darkMetal = new THREE.MeshStandardMaterial({ color: 0x1e242a, metalness: 0.78, roughness: 0.45 });
  const shroudSheet = new THREE.MeshStandardMaterial({ color: 0xa8b0b8, roughness: 0.9 });

  const cabinet = new THREE.Mesh(new THREE.BoxGeometry(2.3, 2.35, 1.2), steelMat);
  cabinet.position.y = 1.175;
  cabinet.castShadow = true;
  cabinet.receiveShadow = true;
  group.add(cabinet);

  const doorGeo = new THREE.BoxGeometry(0.96, 0.64, 0.06);
  const handleGeo = new THREE.BoxGeometry(0.24, 0.05, 0.05);
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 2; col++) {
      const dx = (col === 0 ? -0.54 : 0.54);
      const dy = 0.42 + row * 0.74;
      const isAjar = row === 1 && col === 1;
      const zFace = isAjar ? 1.25 : 0.62;

      const door = new THREE.Mesh(doorGeo, steelMat);
      door.position.set(dx, dy, zFace);
      const handle = new THREE.Mesh(handleGeo, darkMetal);
      handle.position.set(dx, dy, zFace + 0.04);
      group.add(door, handle);

      if (isAjar) {
        const tray = new THREE.Mesh(new THREE.BoxGeometry(0.84, 0.06, 0.95), darkMetal);
        tray.position.set(dx, dy - 0.14, 0.88);
        const bodyForm = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.24, 0.82), shroudSheet);
        bodyForm.position.set(dx, dy - 0.02, 0.88);
        group.add(tray, bodyForm);
      }
    }
  }
  return group;
}

/**
 * Cold Stainless Steel Morgue Examination / Autopsy Table + Tray
 */
export function buildExaminationTableModel(anisotropy = 2): THREE.Group {
  const group = new THREE.Group();
  const steelPbr = getStainlessSteelPBRTextures(anisotropy);
  const steelMat = new THREE.MeshStandardMaterial({
    map: steelPbr.map,
    roughnessMap: steelPbr.roughnessMap,
    metalness: 0.88,
    roughness: 0.26,
  });
  const drainMat = new THREE.MeshStandardMaterial({ color: 0x3f0a0c, roughness: 0.3, metalness: 0.4 });

  const ped = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.84, 1.35), steelMat);
  ped.position.y = 0.42;
  const slab = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.08, 2.24), steelMat);
  slab.position.y = 0.88;
  slab.castShadow = true;
  slab.receiveShadow = true;
  const drain = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.02, 10), drainMat);
  drain.position.set(0, 0.925, 0.88);
  group.add(ped, slab, drain);

  return group;
}

/**
 * Operation Theatre Ensemble: Surgical Table + 4-Pod Overhead Lamp + Rolling Tray + Broken CRT Monitor
 */
export function buildOperationTheatreRig(anisotropy = 2): {
  group: THREE.Group;
  lampBulbMat: THREE.MeshBasicMaterial;
  crtMat: THREE.MeshStandardMaterial;
} {
  const group = new THREE.Group();
  const steelPbr = getStainlessSteelPBRTextures(anisotropy);
  const steelMat = new THREE.MeshStandardMaterial({
    map: steelPbr.map,
    roughnessMap: steelPbr.roughnessMap,
    metalness: 0.85,
    roughness: 0.28,
  });
  const padMat = new THREE.MeshStandardMaterial({ color: 0x1e2b27, roughness: 0.78 });
  const bloodSheetMat = new THREE.MeshStandardMaterial({ color: 0x4a1014, roughness: 0.85 });
  const darkMetal = new THREE.MeshStandardMaterial({ color: 0x1f2428, metalness: 0.7, roughness: 0.45 });

  // Central Operating Table
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.42, 0.76, 10), steelMat);
  base.position.y = 0.38;
  const tableTop = new THREE.Mesh(new THREE.BoxGeometry(0.86, 0.09, 2.15), steelMat);
  tableTop.position.y = 0.8;
  const pad = new THREE.Mesh(new THREE.BoxGeometry(0.78, 0.08, 1.98), padMat);
  pad.position.y = 0.88;
  const drape = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.03, 1.05), bloodSheetMat);
  drape.position.set(0, 0.93, 0.25);
  group.add(base, tableTop, pad, drape);

  // Overhead Articulated 4-Pod Surgical Lamp
  const ceilingStem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.15, 8), steelMat);
  ceilingStem.position.set(0, 3.1, 0);
  const lampDome = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.68, 0.14, 14), steelMat);
  lampDome.position.set(0, 2.48, 0);
  const lampBulbMat = new THREE.MeshBasicMaterial({ color: 0xd1fae5 });
  const lampGlow = new THREE.Mesh(new THREE.CircleGeometry(0.46, 12), lampBulbMat);
  lampGlow.rotation.x = Math.PI / 2;
  lampGlow.position.set(0, 2.405, 0);
  group.add(ceilingStem, lampDome, lampGlow);

  // Rolling Medical Instrument Tray beside table
  const trayStand = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.025, 0.94, 6), steelMat);
  trayStand.position.set(-0.92, 0.47, -0.3);
  const trayTop = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.03, 0.38), steelMat);
  trayTop.position.set(-0.92, 0.95, -0.3);
  const scalpel = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.015, 0.025), darkMetal);
  scalpel.position.set(-0.88, 0.975, -0.25);
  scalpel.rotation.y = 0.45;
  group.add(trayStand, trayTop, scalpel);

  // Broken Static CRT Vital-Signs Monitor
  const cart = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.05, 0.48), darkMetal);
  cart.position.set(1.08, 0.525, -0.55);
  const crtBox = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.42, 0.44), darkMetal);
  crtBox.position.set(1.08, 1.26, -0.55);
  crtBox.rotation.y = -0.35;
  const crtTex = getCRTMonitorTexture();
  const crtMat = new THREE.MeshStandardMaterial({
    map: crtTex,
    emissiveMap: crtTex,
    emissive: new THREE.Color(0x34d399),
    emissiveIntensity: 0.95,
    roughness: 0.22,
  });
  const crtScreen = new THREE.Mesh(new THREE.PlaneGeometry(0.38, 0.32), crtMat);
  crtScreen.position.set(1.0, 1.26, -0.33);
  crtScreen.rotation.y = -0.35;
  group.add(cart, crtBox, crtScreen);

  return { group, lampBulbMat, crtMat };
}

/**
 * Hospital Basement Sparked Electrical Breaker Box & Emergency Beacon
 */
export function buildBasementBreakerPanelModel(): {
  group: THREE.Group;
  beaconMat: THREE.MeshBasicMaterial;
} {
  const group = new THREE.Group();
  const rustedMat = new THREE.MeshStandardMaterial({ color: 0x3b2c25, metalness: 0.72, roughness: 0.58 });
  const darkPanel = new THREE.MeshStandardMaterial({ color: 0x16181c, roughness: 0.7 });

  const box = new THREE.Mesh(new THREE.BoxGeometry(0.85, 1.2, 0.24), rustedMat);
  box.position.y = 1.45;
  const openDoor = new THREE.Mesh(new THREE.BoxGeometry(0.42, 1.14, 0.04), rustedMat);
  openDoor.position.set(-0.56, 1.45, 0.24);
  openDoor.rotation.y = -1.05;
  const inner = new THREE.Mesh(new THREE.BoxGeometry(0.72, 1.04, 0.04), darkPanel);
  inner.position.set(0, 1.45, 0.13);

  const beaconMat = new THREE.MeshBasicMaterial({ color: 0xef4444 });
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), beaconMat);
  beacon.position.set(0, 2.2, 0.14);

  const conduit = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.4, 6), rustedMat);
  conduit.position.set(0.25, 2.75, 0.05);
  group.add(box, openDoor, inner, beacon, conduit);

  return { group, beaconMat };
}

/**
 * Realistic Humanoid Character (Ali Ahmed & 3rd-Person Player)
 */
export function buildHumanCharacterModel(jacketHex: number, isPlayer = false): {
  group: THREE.Group;
  leftLeg: THREE.Mesh;
  rightLeg: THREE.Mesh;
  leftArm: THREE.Mesh;
  rightArm: THREE.Mesh;
  head: THREE.Group;
} {
  const group = new THREE.Group();
  const jacketMat = new THREE.MeshStandardMaterial({ color: jacketHex, roughness: 0.68, metalness: 0.1 });
  const shirtMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.85 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.82 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xd9a886, roughness: 0.52, metalness: 0.02 });
  const hairMat = new THREE.MeshStandardMaterial({ color: 0x12100e, roughness: 0.78 });
  const bootMat = new THREE.MeshStandardMaterial({ color: 0x161210, roughness: 0.42, metalness: 0.25 });
  const buckleMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.28, metalness: 0.85 });

  const legGeo = new THREE.CylinderGeometry(0.078, 0.058, 0.72, 9);
  legGeo.translate(0, -0.36, 0);
  const leftLeg = new THREE.Mesh(legGeo, pantsMat);
  leftLeg.position.set(-0.11, 0.78, 0);
  leftLeg.castShadow = true;
  const rightLeg = new THREE.Mesh(legGeo, pantsMat);
  rightLeg.position.set(0.11, 0.78, 0);
  rightLeg.castShadow = true;

  const bootGeo = new THREE.BoxGeometry(0.135, 0.11, 0.24);
  const bootL = new THREE.Mesh(bootGeo, bootMat);
  bootL.position.set(0, -0.72, 0.045);
  leftLeg.add(bootL);
  const bootR = new THREE.Mesh(bootGeo, bootMat);
  bootR.position.set(0, -0.72, 0.045);
  rightLeg.add(bootR);
  group.add(leftLeg, rightLeg);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.56, 0.24), jacketMat);
  torso.position.y = 1.08;
  torso.castShadow = true;
  group.add(torso);

  const innerShirt = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.44, 0.04), shirtMat);
  innerShirt.position.set(0, 1.12, 0.115);
  group.add(innerShirt);

  const belt = new THREE.Mesh(new THREE.BoxGeometry(0.43, 0.06, 0.25), bootMat);
  belt.position.y = 0.83;
  const buckle = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.055, 0.025), buckleMat);
  buckle.position.set(0, 0.83, 0.125);
  group.add(belt, buckle);

  const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.125, 0.16, 0.1, 10), jacketMat);
  collar.position.y = 1.38;
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.062, 0.11, 8), skinMat);
  neck.position.y = 1.43;
  group.add(collar, neck);

  const head = new THREE.Group();
  head.position.y = 1.56;

  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.132, 12, 10), skinMat);
  cranium.scale.set(0.94, 1.06, 0.96);
  cranium.castShadow = true;
  head.add(cranium);

  const jaw = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.06, 0.09, 8), skinMat);
  jaw.position.set(0, -0.09, 0.032);
  head.add(jaw);

  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.048, 0.035), skinMat);
  nose.position.set(0, -0.008, 0.132);
  head.add(nose);

  const earGeo = new THREE.SphereGeometry(0.026, 6, 6);
  const earL = new THREE.Mesh(earGeo, skinMat);
  earL.scale.set(0.45, 1.1, 0.7);
  earL.position.set(-0.125, -0.01, 0);
  const earR = earL.clone();
  earR.position.x = 0.125;
  head.add(earL, earR);

  const hairTop = new THREE.Mesh(
    new THREE.SphereGeometry(0.142, 12, 9, 0, Math.PI * 2, 0, Math.PI * 0.56),
    hairMat
  );
  hairTop.position.y = 0.022;
  const hairFringe = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.045, 0.08), hairMat);
  hairFringe.position.set(0, 0.085, 0.092);
  hairFringe.rotation.x = 0.24;
  head.add(hairTop, hairFringe);

  if (!isPlayer) {
    const scleraMat = new THREE.MeshBasicMaterial({ color: 0xf8fafc });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    const browGeo = new THREE.BoxGeometry(0.042, 0.012, 0.015);
    const browL = new THREE.Mesh(browGeo, hairMat);
    browL.position.set(-0.044, 0.038, 0.12);
    const browR = browL.clone();
    browR.position.x = 0.044;

    const eyeGeo = new THREE.SphereGeometry(0.018, 6, 6);
    const eyeL = new THREE.Mesh(eyeGeo, scleraMat);
    eyeL.position.set(-0.044, 0.014, 0.118);
    const eyeR = eyeL.clone();
    eyeR.position.x = 0.044;

    const pGeo = new THREE.SphereGeometry(0.01, 5, 5);
    const pL = new THREE.Mesh(pGeo, pupilMat);
    pL.position.set(-0.044, 0.014, 0.13);
    const pR = pL.clone();
    pR.position.x = 0.044;
    head.add(browL, browR, eyeL, eyeR, pL, pR);
  }
  group.add(head);

  const armGeo = new THREE.CylinderGeometry(0.056, 0.044, 0.54, 8);
  armGeo.translate(0, -0.24, 0);
  const handGeo = new THREE.SphereGeometry(0.042, 7, 7);

  const leftArm = new THREE.Mesh(armGeo, jacketMat);
  leftArm.position.set(-0.27, 1.32, 0);
  leftArm.castShadow = true;
  const handL = new THREE.Mesh(handGeo, skinMat);
  handL.position.y = -0.52;
  leftArm.add(handL);

  const rightArm = new THREE.Mesh(armGeo, jacketMat);
  rightArm.position.set(0.27, 1.32, 0);
  rightArm.castShadow = true;
  const handR = new THREE.Mesh(handGeo, skinMat);
  handR.position.y = -0.52;
  rightArm.add(handR);

  if (isPlayer) {
    const torch = new THREE.Mesh(
      new THREE.CylinderGeometry(0.034, 0.026, 0.24, 8),
      new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.88, roughness: 0.22 })
    );
    torch.rotation.x = Math.PI / 2;
    torch.position.set(0, -0.52, 0.1);
    const torchLens = new THREE.Mesh(
      new THREE.CircleGeometry(0.03, 8),
      new THREE.MeshBasicMaterial({ color: 0xfef3c7 })
    );
    torchLens.position.set(0, -0.52, 0.222);
    rightArm.add(torch, torchLens);
    rightArm.rotation.x = -Math.PI / 2.5;
  }
  group.add(leftArm, rightArm);

  group.add(createContactShadowPlane(0.48));
  return { group, leftLeg, rightLeg, leftArm, rightArm, head };
}

/**
 * Individually styled Mysterious Door (1 of 9)
 */
export function buildMysteriousDoorModel(
  door: DoorDef,
  isUnlocked: boolean,
  anisotropy = 2,
  useDetailMaps = true
): {
  group: THREE.Group;
  doorLeaf: THREE.Group;
  statusOrbMat: THREE.MeshBasicMaterial;
} {
  const group = new THREE.Group();
  const woodPbr = getWoodPBRTextures(anisotropy, door.style === 'sanctum' || door.style === 'chapel');

  const frameMat = new THREE.MeshStandardMaterial({
    color: door.style === 'mirror' ? 0x475569 : door.style === 'sanctum' ? 0x1c1014 : 0x261a14,
    roughness: 0.68,
    metalness: door.style === 'clockwork' ? 0.55 : 0.18,
  });

  const leafMat = new THREE.MeshStandardMaterial({
    map: woodPbr.map,
    bumpMap: useDetailMaps ? woodPbr.bumpMap : null,
    bumpScale: 0.04,
    roughnessMap: useDetailMaps ? woodPbr.roughnessMap : null,
    color: door.style === 'mirror' ? 0x94a3b8 : door.style === 'flooded' ? 0x2a454d : 0x725542,
    roughness: door.style === 'mirror' ? 0.16 : 0.72,
    metalness: door.style === 'mirror' ? 0.85 : 0.12,
  });

  const postGeo = new THREE.BoxGeometry(0.24, 2.75, 0.34);
  const postL = new THREE.Mesh(postGeo, frameMat);
  postL.position.set(-0.78, 1.37, 0);
  postL.castShadow = true;
  const postR = new THREE.Mesh(postGeo, frameMat);
  postR.position.set(0.78, 1.37, 0);
  postR.castShadow = true;
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(1.94, 0.32, 0.38), frameMat);
  lintel.position.set(0, 2.78, 0);
  group.add(postL, postR, lintel);

  const plaqueTex = getDoorPlaqueTexture(ROMAN[door.doorNumber - 1], door.accentColor);
  const plaque = new THREE.Mesh(
    new THREE.BoxGeometry(0.44, 0.44, 0.08),
    new THREE.MeshStandardMaterial({ map: plaqueTex, roughness: 0.35, metalness: 0.38 })
  );
  plaque.position.set(0, 2.78, 0.18);
  group.add(plaque);

  const doorLeaf = new THREE.Group();
  doorLeaf.position.set(-0.65, 0, 0);

  const panel = new THREE.Mesh(new THREE.BoxGeometry(1.3, 2.58, 0.11), leafMat);
  panel.position.set(0.65, 1.29, 0);
  panel.castShadow = true;
  panel.receiveShadow = true;
  doorLeaf.add(panel);

  const ironMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.85, roughness: 0.32 });
  [0.5, 2.1].forEach((hy) => {
    const hinge = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.08, 0.13), ironMat);
    hinge.position.set(0.18, hy, 0);
    doorLeaf.add(hinge);
  });

  const accentMat = new THREE.MeshStandardMaterial({
    color: door.accentColor,
    emissive: door.accentColor,
    emissiveIntensity: isUnlocked ? 0.78 : 0.28,
    metalness: 0.65,
    roughness: 0.28,
  });
  const emblem = new THREE.Mesh(
    door.style === 'clockwork'
      ? new THREE.TorusGeometry(0.24, 0.04, 6, 12)
      : door.style === 'sanctum'
      ? new THREE.OctahedronGeometry(0.22, 0)
      : new THREE.RingGeometry(0.14, 0.22, 14),
    accentMat
  );
  emblem.position.set(0.65, 1.62, 0.075);
  doorLeaf.add(emblem);

  const knob = new THREE.Mesh(
    new THREE.SphereGeometry(0.062, 8, 8),
    new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.88, roughness: 0.22 })
  );
  knob.position.set(1.16, 1.15, 0.095);
  doorLeaf.add(knob);

  group.add(doorLeaf);

  const statusOrbMat = new THREE.MeshBasicMaterial({
    color: isUnlocked ? 0x34d399 : new THREE.Color(door.accentColor).getHex(),
  });
  const statusOrb = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), statusOrbMat);
  statusOrb.position.set(0, 2.4, 0.23);
  group.add(statusOrb);

  return { group, doorLeaf, statusOrbMat };
}

/**
 * Collectible Drink Bottle with physical clearcoat/reflective glass & vibrant elixir
 */
export function buildDrinkBottleModel(liquidColorHex: string): THREE.Group {
  const group = new THREE.Group();
  if (!sharedBottleGlassGeo) {
    const pts = [
      new THREE.Vector2(0.0, 0.0),
      new THREE.Vector2(0.09, 0.0),
      new THREE.Vector2(0.095, 0.22),
      new THREE.Vector2(0.04, 0.32),
      new THREE.Vector2(0.04, 0.42),
      new THREE.Vector2(0.052, 0.44),
    ];
    sharedBottleGlassGeo = new THREE.LatheGeometry(pts, 12);
  }
  if (!sharedBottleGlassMat) {
    sharedBottleGlassMat = new THREE.MeshPhysicalMaterial({
      color: 0xe2e8f0,
      roughness: 0.08,
      metalness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.08,
      reflectivity: 0.9,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
  }
  if (!sharedBottleLiquidGeo) {
    sharedBottleLiquidGeo = new THREE.CylinderGeometry(0.072, 0.072, 0.18, 10);
  }
  if (!sharedBottleCorkGeo) {
    sharedBottleCorkGeo = new THREE.CylinderGeometry(0.036, 0.032, 0.06, 8);
  }
  if (!sharedBottleCorkMat) {
    sharedBottleCorkMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
  }
  if (!sharedBottleLabelGeo) {
    sharedBottleLabelGeo = new THREE.CylinderGeometry(0.097, 0.097, 0.09, 10, 1, true, 0, Math.PI);
  }
  if (!sharedBottleLabelMat) {
    sharedBottleLabelMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.85 });
  }

  const glass = new THREE.Mesh(sharedBottleGlassGeo, sharedBottleGlassMat);
  glass.renderOrder = 2;
  glass.userData.sharedAsset = true;

  const liquid = new THREE.Mesh(
    sharedBottleLiquidGeo,
    new THREE.MeshBasicMaterial({ color: liquidColorHex })
  );
  liquid.position.y = 0.1;
  liquid.userData.sharedGeo = true;

  const cork = new THREE.Mesh(sharedBottleCorkGeo, sharedBottleCorkMat);
  cork.position.y = 0.44;
  cork.userData.sharedAsset = true;

  const label = new THREE.Mesh(sharedBottleLabelGeo, sharedBottleLabelMat);
  label.position.y = 0.13;
  label.userData.sharedAsset = true;

  group.add(liquid, glass, cork, label);
  return group;
}

/**
 * Wardrobe / Crypt Locker Hiding Spot
 */
export function buildHidingWardrobeModel(isCrypt = false, anisotropy = 2): THREE.Group {
  const group = new THREE.Group();
  const tex = isCrypt ? getStoneSoilPBRTextures(anisotropy, false) : getWoodPBRTextures(anisotropy, true);
  const mat = new THREE.MeshStandardMaterial({
    map: tex.map,
    color: isCrypt ? 0x52525b : 0x4b3529,
    roughness: isCrypt ? 0.82 : 0.68,
    metalness: 0.15,
  });

  const body = new THREE.Mesh(new THREE.BoxGeometry(1.25, 2.35, 0.85), mat);
  body.position.y = 1.18;
  body.castShadow = true;
  body.receiveShadow = true;
  group.add(body);

  const trim = new THREE.Mesh(
    new THREE.BoxGeometry(1.1, 2.1, 0.06),
    new THREE.MeshStandardMaterial({ color: isCrypt ? 0x3f3f46 : 0x1a100b, roughness: 0.8 })
  );
  trim.position.set(0, 1.15, 0.43);
  group.add(trim);

  const eyeSlit = new THREE.Mesh(
    new THREE.BoxGeometry(0.65, 0.06, 0.07),
    new THREE.MeshBasicMaterial({ color: 0x050507 })
  );
  eyeSlit.position.set(0, 1.55, 0.44);
  group.add(eyeSlit);

  return group;
}

/**
 * Safe Lantern Save Shrine
 */
export function buildSaveShrineModel(): THREE.Group {
  const group = new THREE.Group();
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x301f14, roughness: 0.72 });
  const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.88, roughness: 0.22 });

  const table = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.85, 0.65), woodMat);
  table.position.y = 0.425;
  table.castShadow = true;
  table.receiveShadow = true;
  group.add(table);

  const lanternBase = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.08, 8), brassMat);
  lanternBase.position.y = 0.89;
  const lanternBulb = new THREE.Mesh(
    new THREE.SphereGeometry(0.085, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xfef08a })
  );
  lanternBulb.position.y = 1.02;
  const halo = new THREE.Mesh(
    new THREE.SphereGeometry(0.32, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.24, depthWrite: false })
  );
  halo.position.y = 1.02;
  const lanternCap = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.1, 8), brassMat);
  lanternCap.position.y = 1.15;
  group.add(lanternBase, lanternBulb, halo, lanternCap);

  return group;
}

/**
 * Twisted Dead Tree for Haunted Graveyard
 */
export function buildDeadTreeModel(scale = 1, sharedMat?: THREE.Material): THREE.Group {
  const group = new THREE.Group();
  const barkMat = sharedMat || new THREE.MeshStandardMaterial({ color: 0x1e1815, roughness: 0.95 });

  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.36, 3.8, 7), barkMat);
  trunk.position.y = 1.9;
  trunk.rotation.z = 0.06;
  trunk.castShadow = true;
  group.add(trunk);

  const branch1 = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.14, 2.2, 6), barkMat);
  branch1.position.set(0.68, 3.0, 0.22);
  branch1.rotation.z = -0.85;
  branch1.rotation.y = 0.4;
  group.add(branch1);

  const branch2 = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.12, 1.95, 6), barkMat);
  branch2.position.set(-0.62, 2.65, -0.2);
  branch2.rotation.z = 0.92;
  group.add(branch2);

  group.scale.setScalar(scale);
  return group;
}

/**
 * Distinct atmospheric furniture/props behind each of the 9 doors
 */
export function buildDoorInteriorProps(style: DoorDef['style']): THREE.Group {
  const group = new THREE.Group();
  const darkWood = new THREE.MeshStandardMaterial({ color: 0x2c1e15, roughness: 0.76 });
  const brass = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.88, roughness: 0.24 });
  const mirrorGlass = new THREE.MeshPhysicalMaterial({
    color: 0xcbd5e1,
    metalness: 0.92,
    roughness: 0.06,
    clearcoat: 1.0,
  });

  if (style === 'rusted') {
    const bed = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.2, 0.7), darkWood);
    bed.position.set(0.9, 0.35, 0);
    const railGeo = new THREE.BoxGeometry(1.1, 0.45, 0.06);
    const railL = new THREE.Mesh(railGeo, darkWood);
    railL.position.set(0.9, 0.65, 0.32);
    const railR = new THREE.Mesh(railGeo, darkWood);
    railR.position.set(0.9, 0.65, -0.32);
    group.add(bed, railL, railR);
  } else if (style === 'clockwork') {
    const gear = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.08, 6, 12), brass);
    gear.position.set(1.1, 1.5, 0.4);
    const clockBox = new THREE.Mesh(new THREE.BoxGeometry(0.55, 2.1, 0.42), darkWood);
    clockBox.position.set(-1.1, 1.05, 0.2);
    group.add(gear, clockBox);
  } else if (style === 'mirror') {
    const frame = new THREE.Mesh(new THREE.BoxGeometry(1.1, 2.1, 0.12), darkWood);
    frame.position.set(0, 1.25, 1.1);
    const glass = new THREE.Mesh(new THREE.PlaneGeometry(0.86, 1.85), mirrorGlass);
    glass.position.set(0, 1.25, 1.03);
    glass.rotation.y = Math.PI;
    group.add(frame, glass);
  } else if (style === 'flooded') {
    const water = new THREE.Mesh(
      new THREE.CircleGeometry(1.7, 16),
      new THREE.MeshPhysicalMaterial({
        color: 0x0c4a6e,
        roughness: 0.06,
        metalness: 0.6,
        clearcoat: 1.0,
      })
    );
    water.rotation.x = -Math.PI / 2;
    water.position.set(0, 0.03, 0.2);
    group.add(water);
  } else if (style === 'alchemist') {
    const rack = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.7, 1.3), darkWood);
    rack.position.set(-1.2, 0.85, 0);
    const flask = new THREE.Mesh(
      new THREE.SphereGeometry(0.14, 9, 9),
      new THREE.MeshBasicMaterial({ color: 0xef4444 })
    );
    flask.position.set(-1.2, 1.78, 0.2);
    group.add(rack, flask);
  } else if (style === 'library') {
    const shelf = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.4, 0.42), darkWood);
    shelf.position.set(1.1, 1.2, -0.5);
    group.add(shelf);
  } else if (style === 'portrait') {
    const pFrame = new THREE.Mesh(new THREE.BoxGeometry(1.0, 1.3, 0.08), brass);
    pFrame.position.set(0, 1.65, -1.2);
    const canvas = new THREE.Mesh(
      new THREE.PlaneGeometry(0.8, 1.1),
      new THREE.MeshStandardMaterial({ color: 0x4c0519, roughness: 0.72 })
    );
    canvas.position.set(0, 1.65, -1.15);
    group.add(pFrame, canvas);
  } else if (style === 'chapel') {
    const pewGeo = new THREE.BoxGeometry(1.4, 0.65, 0.45);
    const pewL = new THREE.Mesh(pewGeo, darkWood);
    pewL.position.set(-1.1, 0.32, -0.6);
    const pewR = new THREE.Mesh(pewGeo, darkWood);
    pewR.position.set(1.1, 0.32, -0.6);
    group.add(pewL, pewR);
  } else {
    const iron = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.85, roughness: 0.32 });
    const barGeo = new THREE.CylinderGeometry(0.04, 0.04, 3.0, 6);
    for (let i = -2; i <= 2; i++) {
      if (i === 0) continue;
      const bar = new THREE.Mesh(barGeo, iron);
      bar.position.set(i * 0.65, 1.5, -1.8);
      group.add(bar);
    }
  }
  return group;
}
