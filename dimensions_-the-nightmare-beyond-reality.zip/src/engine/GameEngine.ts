import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { BOTTLES, DOORS, ITEMS_CATALOG, LETTERS, MAP_ROOMS } from '../data/gameData';
import { detectRecommendedQualityTier } from '../state/saveSystem';
import {
  CameraPerspective,
  ChapterId,
  EndingId,
  GameProgressState,
  GameSettings,
  InventoryItem,
  PlayerHudState,
} from '../types/game';
import { audioEngine } from './audio';
import {
  buildChapterLevel,
  computeGroundHeight,
  DoorRuntime,
  InteractableObj,
  LevelBuildResult,
} from './levels';
import {
  buildFemaleGhostModel,
  buildHumanCharacterModel,
  FemaleGhostRig,
} from './models';
import { disposeCachedTextures } from './textures';

// Pre-allocated math helpers (zero GC inside animation loop)
const _vec3A = new THREE.Vector3();
const _vec3B = new THREE.Vector3();
const _forward = new THREE.Vector3();
const _right = new THREE.Vector3();
const _camTarget = new THREE.Vector3();
const _rayDir = new THREE.Vector3();

export type ZoyaAIState =
  | 'dormant'
  | 'distant_omen'
  | 'distant_silhouette'
  | 'stalk'
  | 'chase'
  | 'attack'
  | 'vanishing';

type ResolvedTier = 'low' | 'medium' | 'high' | 'ultra';

export interface EngineCallbacks {
  onHudUpdate: (hud: PlayerHudState) => void;
  onShowSubtitle: (speakerEn: string, speakerUr: string, textEn: string, textUr: string, duration?: number) => void;
  onOpenPuzzle: (puzzleId: string) => void;
  onOpenLetter: (letterId: string) => void;
  onOpenSaveShrine: () => void;
  onTriggerCinematic: (cinematicId: string) => void;
  onTriggerEnding: (endingId: EndingId) => void;
  onGameOver: () => void;
  onProgressMutated: () => void;
}

interface EnemyAgent {
  id: string;
  kind: 'zoya';
  rig: FemaleGhostRig;
  mesh: THREE.Group;
  pos: THREE.Vector3;
  yaw: number;
  state: ZoyaAIState;
  stateTimer: number;
  speedPatrol: number;
  speedChase: number;
  stunTimer: number;
  attackCooldown: number;
  crawlMode: boolean;
  crawlBlend: number;
  fadeAlpha: number;
  stepAudioAccum: number;
  omenPos: THREE.Vector3;
  // Chapter tether tracking (mapped cleanly to progress.defeatedBossIds)
  chapterTetherHp: number;
  chapterTetherMax: number;
  secretTetherHp: number;
  secretTetherMax: number;
  tetherEngaged: boolean;
}

function disposeObjectTree(group: THREE.Object3D) {
  group.traverse((obj) => {
    const m = obj as THREE.Mesh;
    if (m.geometry && !m.userData?.sharedAsset && !m.userData?.sharedGeo) {
      m.geometry.dispose();
    }
    if (m.material && !m.userData?.sharedAsset) {
      if (Array.isArray(m.material)) {
        m.material.forEach((mat) => mat.dispose());
      } else {
        m.material.dispose();
      }
    }
  });
}

export class GameEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;
  private pmremEnv: THREE.Texture | null = null;

  private frameId = 0;
  private lastTime = performance.now();
  private lastRenderTime = performance.now();
  private elapsed = 0;
  private running = false;
  private activeMode: 'title' | 'playing' | 'paused' = 'title';

  // Auto-quality & FPS stabilizer
  private baseHardwareTier: ResolvedTier;
  private resolvedTier: ResolvedTier;
  private perfFrameAccum = 0;
  private perfFrameCount = 0;

  private settings: GameSettings;
  private progress: GameProgressState;
  private callbacks: EngineCallbacks;

  private level: LevelBuildResult | null = null;
  private titleGroup: THREE.Group | null = null;

  // Lighting, Volumetric Beam & GPU Shader Particles
  private hemiLight: THREE.HemisphereLight;
  private keyLight: THREE.DirectionalLight;
  private nearFillLight: THREE.PointLight;
  private flashlight: THREE.SpotLight;
  private flashlightTarget: THREE.Object3D;
  private volumetricCone: THREE.Mesh;
  private volumetricUniforms: { uTime: { value: number }; uOpacity: { value: number } };
  private shockwaveRing: THREE.Mesh;
  private shockwaveProgress = -1;
  private dustPoints: THREE.Points | null = null;
  private dustUniforms: { uTime: { value: number }; uFallSpeed: { value: number } } | null = null;

  // Player & Camera
  private playerPos = new THREE.Vector3(0, 0.24, 10.5);
  private playerYaw = 0;
  private playerPitch = 0;
  private playerVelY = 0;
  private onGround = true;
  private headBobPhase = 0;
  private cameraShake = 0;
  private flashlightOn = true;
  private isCrouching = false;
  private isHiding = false;
  private activeHideSpot: InteractableObj | null = null;
  private noiseLevel = 0;
  private playerRig: ReturnType<typeof buildHumanCharacterModel>;
  private walkAnimPhase = 0;

  // Input state
  private keys: Record<string, boolean> = {};
  private touchMove = { x: 0, y: 0 };
  private touchSprint = false;
  private touchSprintLocked = false;
  private isPointerDown = false;
  private lastPointer = { x: 0, y: 0 };

  // Sole Ghost (Zoya) & Companion (Ali)
  private enemies: EnemyAgent[] = [];
  private zoyaOmenFlicker = 0;
  private ambientCueCooldown = 6;
  private lodCheckAccum = 0;
  private aliRig: ReturnType<typeof buildHumanCharacterModel> | null = null;
  private aliPos = new THREE.Vector3();
  private aliYaw = 0;
  private aliDialogueTimer = 8;

  // HUD throttled diff state
  private hudEmitAccum = 0;
  private lastHudSignature = '';
  private resizeObserver: ResizeObserver;
  private maxAnisotropy = 2;

  constructor(
    container: HTMLElement,
    initialSettings: GameSettings,
    initialProgress: GameProgressState,
    callbacks: EngineCallbacks
  ) {
    this.container = container;
    this.settings = initialSettings;
    this.progress = initialProgress;
    this.callbacks = callbacks;

    this.baseHardwareTier = detectRecommendedQualityTier();
    this.resolvedTier =
      initialSettings.graphicsQuality === 'auto'
        ? this.baseHardwareTier
        : (initialSettings.graphicsQuality as ResolvedTier);

    this.isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    if (this.isSoftwareGl) {
      this.resolvedTier = 'low';
    }

    try {
      this.renderer = new THREE.WebGLRenderer({
        antialias: (this.resolvedTier === 'high' || this.resolvedTier === 'ultra') && !this.isSoftwareGl,
        powerPreference: 'high-performance',
      });
    } catch {
      this.renderer = new THREE.WebGLRenderer({
        antialias: false,
        powerPreference: 'default',
      });
    }
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = initialSettings.brightness;
    this.renderer.shadowMap.enabled = false;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.maxAnisotropy = Math.min(4, this.renderer.capabilities.getMaxAnisotropy() || 1);

    const w = Math.max(1, container.clientWidth || window.innerWidth || 640);
    const h = Math.max(1, container.clientHeight || window.innerHeight || 360);
    this.renderer.setSize(w, h);
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x050609);
    this.scene.fog = new THREE.FogExp2(0x050609, 0.042);

    if ((this.resolvedTier === 'high' || this.resolvedTier === 'ultra') && !this.isSoftwareGl) {
      try {
        const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
        this.pmremEnv = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
        this.scene.environment = this.pmremEnv;
        pmremGenerator.dispose();
      } catch {
        this.pmremEnv = null;
      }
    }

    this.camera = new THREE.PerspectiveCamera(72, w / h, 0.08, 120);

    // Warm/Cool Horror Lighting Rig
    this.hemiLight = new THREE.HemisphereLight(0x475e80, 0x161218, 0.8);
    this.scene.add(this.hemiLight);

    this.keyLight = new THREE.DirectionalLight(0xdbeafe, 0.85);
    this.keyLight.position.set(12, 24, 10);
    this.keyLight.castShadow = false;
    this.keyLight.shadow.mapSize.set(1024, 1024);
    this.keyLight.shadow.camera.near = 2;
    this.keyLight.shadow.camera.far = 65;
    this.keyLight.shadow.camera.left = -22;
    this.keyLight.shadow.camera.right = 22;
    this.keyLight.shadow.camera.top = 22;
    this.keyLight.shadow.camera.bottom = -22;
    this.keyLight.shadow.bias = -0.0005;
    this.scene.add(this.keyLight);
    this.scene.add(this.keyLight.target);

    this.nearFillLight = new THREE.PointLight(0x94a3b8, 0.78, 10.5, 1.5);
    this.scene.add(this.nearFillLight);

    // Player Flashlight (casts crisp real-time shadows on Ultra tier)
    this.flashlight = new THREE.SpotLight(0xfff1d6, 6.4, 28, Math.PI / 5.0, 0.45, 1.3);
    this.flashlight.castShadow = false;
    this.flashlight.shadow.mapSize.set(512, 512);
    this.flashlight.shadow.camera.near = 0.35;
    this.flashlight.shadow.camera.far = 26;
    this.flashlight.shadow.bias = -0.0008;
    this.flashlightTarget = new THREE.Object3D();
    this.scene.add(this.flashlight);
    this.scene.add(this.flashlightTarget);
    this.flashlight.target = this.flashlightTarget;

    // Volumetric Flashlight Cone
    this.volumetricUniforms = {
      uTime: { value: 0 },
      uOpacity: { value: 0.14 },
    };
    const coneGeo = new THREE.ConeGeometry(1.75, 8.2, 16, 1, true);
    coneGeo.translate(0, -4.1, 0);
    coneGeo.rotateX(Math.PI / 2);
    this.volumetricCone = new THREE.Mesh(
      coneGeo,
      new THREE.ShaderMaterial({
        uniforms: this.volumetricUniforms,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          uniform float uTime;
          uniform float uOpacity;
          varying vec2 vUv;
          void main() {
            float fadeAlong = pow(1.0 - vUv.y, 1.8);
            float shimmer = 0.85 + 0.15 * sin(uTime * 2.4 + vUv.y * 8.0);
            gl_FragColor = vec4(1.0, 0.94, 0.8, fadeAlong * shimmer * uOpacity);
          }
        `,
      })
    );
    this.volumetricCone.visible = false;
    this.scene.add(this.volumetricCone);

    // Ritual / Seal Shockwave Ring VFX
    this.shockwaveRing = new THREE.Mesh(
      new THREE.RingGeometry(0.4, 0.72, 24),
      new THREE.MeshBasicMaterial({
        color: 0xe11d48,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        depthWrite: false,
      })
    );
    this.shockwaveRing.rotation.x = -Math.PI / 2;
    this.shockwaveRing.visible = false;
    this.scene.add(this.shockwaveRing);

    this.playerRig = buildHumanCharacterModel(0x334155, true);
    this.playerRig.group.visible = false;
    this.scene.add(this.playerRig.group);

    this.createAtmosphericParticles();
    this.buildTitleBackdrop();

    this.bindEvents();
    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    this.applySettings(initialSettings);

    if (!this.isSoftwareGl) {
      try {
        this.renderer.compile(this.scene, this.camera);
      } catch {
        // ignore shader precompile edge cases
      }
    }

    this.running = true;
    this.lastTime = performance.now();
    this.lastRenderTime = this.lastTime;
    this.tick();
  }

  private createAtmosphericParticles() {
    const count = 120;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 40;
      positions[i * 3 + 1] = Math.random() * 5.4;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 40;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    this.dustUniforms = {
      uTime: { value: 0 },
      uFallSpeed: { value: 0.18 },
    };

    const mat = new THREE.ShaderMaterial({
      uniforms: this.dustUniforms,
      vertexShader: `
        uniform float uTime;
        uniform float uFallSpeed;
        varying float vAlpha;
        void main() {
          vec3 pos = position;
          pos.y = mod(pos.y - uTime * uFallSpeed, 5.4);
          pos.x += sin(uTime * 0.45 + pos.z) * 0.18;
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_PointSize = clamp(24.0 / -mvPosition.z, 1.5, 4.5);
          vAlpha = smoothstep(26.0, 2.0, -mvPosition.z) * 0.44;
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        varying float vAlpha;
        void main() {
          float d = length(gl_PointCoord - vec2(0.5));
          if (d > 0.5) discard;
          gl_FragColor = vec4(0.82, 0.86, 0.92, vAlpha * (1.0 - d * 2.0));
        }
      `,
      transparent: true,
      depthWrite: false,
    });

    this.dustPoints = new THREE.Points(geo, mat);
    this.scene.add(this.dustPoints);
  }

  private buildTitleBackdrop() {
    if (this.titleGroup) {
      this.scene.remove(this.titleGroup);
      disposeObjectTree(this.titleGroup);
    }
    const g = new THREE.Group();
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(90, 90),
      new THREE.MeshStandardMaterial({ color: 0x0d1012, roughness: 0.92 })
    );
    ground.rotation.x = -Math.PI / 2;
    g.add(ground);

    const houseMat = new THREE.MeshStandardMaterial({ color: 0x16141a, roughness: 0.85 });
    const mainBody = new THREE.Mesh(new THREE.BoxGeometry(11, 7, 8), houseMat);
    mainBody.position.set(0, 3.5, -14);
    g.add(mainBody);

    const roof = new THREE.Mesh(new THREE.ConeGeometry(8.5, 4.2, 4), houseMat);
    roof.position.set(0, 9.1, -14);
    roof.rotation.y = Math.PI / 4;
    g.add(roof);

    const winMat = new THREE.MeshBasicMaterial({ color: 0x34d399 });
    const winL = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.8), winMat);
    winL.position.set(-2.8, 4.8, -9.95);
    const winR = winL.clone();
    winR.position.x = 2.8;
    const frontDoor = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 2.9, 0.2),
      new THREE.MeshStandardMaterial({ color: 0x3b1218, emissive: 0x7f1d1d, emissiveIntensity: 0.55 })
    );
    frontDoor.position.set(0, 1.45, -9.95);
    g.add(winL, winR, frontDoor);

    const zoya = buildFemaleGhostModel();
    zoya.group.position.set(2.4, 0, -6.2);
    zoya.group.rotation.y = -0.35;
    g.add(zoya.group);

    const titleLight = new THREE.PointLight(0xe11d48, 2.8, 22);
    titleLight.position.set(0, 2.8, -8.5);
    g.add(titleLight);

    this.titleGroup = g;
    this.scene.add(g);
  }

  public setMode(mode: 'title' | 'playing' | 'paused') {
    const prev = this.activeMode;
    this.activeMode = mode;
    if (this.titleGroup) {
      this.titleGroup.visible = mode === 'title';
    }
    if (this.level) {
      this.level.root.visible = mode !== 'title';
    }
    if (mode !== 'playing') {
      this.clearHeldInputs();
    } else if (prev === 'paused') {
      // Protect player right after closing a puzzle, letter, or pause screen
      const zoya = this.enemies[0];
      if (zoya && (zoya.state === 'chase' || zoya.state === 'stalk')) {
        if (zoya.pos.distanceTo(this.playerPos) < 9.5) {
          zoya.stunTimer = Math.max(zoya.stunTimer, 3.5);
        }
      }
    }
  }

  public getGroundHeight(x: number, z: number): number {
    if (!this.level) return 0;
    return computeGroundHeight(x, z, this.progress.chapter, this.level.floorZones);
  }

  public loadChapter(progress: GameProgressState, useSavedPosition = false) {
    this.progress = progress;
    if (this.level) {
      this.scene.remove(this.level.root);
      this.level.dispose();
      this.level = null;
    }
    this.enemies.forEach((e) => {
      this.scene.remove(e.mesh);
      disposeObjectTree(e.mesh);
    });
    this.enemies = [];
    if (this.aliRig) {
      this.scene.remove(this.aliRig.group);
      disposeObjectTree(this.aliRig.group);
      this.aliRig = null;
    }

    const levelAniso = this.resolvedTier === 'low' ? 1 : this.resolvedTier === 'medium' ? 2 : this.maxAnisotropy;
    const built = buildChapterLevel(progress.chapter, progress, levelAniso, this.resolvedTier);
    this.level = built;
    this.scene.add(built.root);

    if (progress.chapter === 1) {
      this.scene.background = new THREE.Color(0x050708);
      this.scene.fog = new THREE.FogExp2(0x050708, 0.042);
      this.hemiLight.intensity = 0.82;
      this.keyLight.color.setHex(0xcbd5e1);
      this.keyLight.intensity = 0.68;
    } else if (progress.chapter === 2) {
      this.scene.background = new THREE.Color(0x080f18);
      this.scene.fog = new THREE.FogExp2(0x0b1420, 0.036);
      this.hemiLight.intensity = 0.9;
      this.keyLight.color.setHex(0xdbeafe);
      this.keyLight.intensity = 1.0;
    } else {
      this.scene.background = new THREE.Color(0x11071e);
      this.scene.fog = new THREE.FogExp2(0x140822, 0.032);
      this.hemiLight.intensity = 0.95;
      this.keyLight.color.setHex(0xe9d5ff);
      this.keyLight.intensity = 0.86;
    }

    if (this.dustUniforms) {
      this.dustUniforms.uFallSpeed.value = progress.chapter === 2 ? 1.55 : 0.18;
    }

    if (useSavedPosition && progress.playerPosition) {
      const clampedX = THREE.MathUtils.clamp(progress.playerPosition.x, built.bounds.minX, built.bounds.maxX);
      const clampedZ = THREE.MathUtils.clamp(progress.playerPosition.z, built.bounds.minZ, built.bounds.maxZ);
      const gy = computeGroundHeight(clampedX, clampedZ, progress.chapter, built.floorZones);
      this.playerPos.set(clampedX, Math.max(gy, progress.playerPosition.y ?? gy), clampedZ);
      this.playerYaw = progress.playerPosition.yaw || 0;
    } else {
      this.playerPos.copy(built.playerSpawn);
      this.playerYaw = 0;
    }
    this.playerVelY = 0;
    this.onGround = true;
    this.playerPitch = 0;
    this.isHiding = false;
    this.activeHideSpot = null;
    this.isCrouching = false;
    this.touchSprintLocked = false;
    this.lastHudSignature = '';
    this.zoyaOmenFlicker = 0;

    // Spawn ONLY ONE Female Ghost: Zoya
    this.spawnZoyaDirector(progress.chapter, built);

    this.aliRig = buildHumanCharacterModel(0x7c2d12, false);
    this.scene.add(this.aliRig.group);
    if (progress.chapter === 1 && !progress.aliRescued) {
      this.aliPos.copy(built.aliSpawn);
    } else {
      const ax = this.playerPos.x - 1.8;
      const az = this.playerPos.z + 1.5;
      this.aliPos.set(ax, this.getGroundHeight(ax, az), az);
    }
    this.aliRig.group.position.copy(this.aliPos);

    audioEngine.setChapterAmbience(progress.chapter);

    if (!this.isSoftwareGl) {
      try {
        this.renderer.compile(this.scene, this.camera);
      } catch {
        // ignore shader precompile issues
      }
    }

    this.setMode('playing');
    this.emitHudState({ nearestThreatDist: 999, isChased: false });
  }

  private getDormantDuration(): number {
    if (this.settings.difficulty === 'nightmare') return 26 + Math.random() * 12;
    if (this.settings.difficulty === 'hard') return 32 + Math.random() * 14;
    return 38 + Math.random() * 16;
  }

  private spawnZoyaDirector(chapter: ChapterId, built: LevelBuildResult) {
    const diffSpeed =
      this.settings.difficulty === 'nightmare' ? 1.18 : this.settings.difficulty === 'hard' ? 1.08 : 1.0;

    const zoyaRig = buildFemaleGhostModel();
    const startPos = built.patrolWaypoints[0]?.clone() || new THREE.Vector3(0, 0, -14);
    startPos.y = computeGroundHeight(startPos.x, startPos.z, chapter, built.floorZones);
    zoyaRig.group.position.copy(startPos);
    zoyaRig.group.visible = false; // Starts dormant so player can explore freely first
    this.scene.add(zoyaRig.group);

    this.enemies.push({
      id: 'zoya_main',
      kind: 'zoya',
      rig: zoyaRig,
      mesh: zoyaRig.group,
      pos: startPos,
      yaw: 0,
      state: 'dormant',
      stateTimer: this.settings.difficulty === 'nightmare' ? 18 : 24,
      speedPatrol: 1.9 * diffSpeed,
      speedChase: 3.95 * diffSpeed,
      stunTimer: 0,
      attackCooldown: 0,
      crawlMode: false,
      crawlBlend: 0,
      fadeAlpha: 0,
      stepAudioAccum: 0,
      omenPos: startPos.clone(),
      chapterTetherHp: 3,
      chapterTetherMax: 3,
      secretTetherHp: 4,
      secretTetherMax: 4,
      tetherEngaged: false,
    });
  }

  public applySettings(s: GameSettings) {
    this.settings = s;
    const desiredTier: ResolvedTier =
      this.isSoftwareGl
        ? 'low'
        : s.graphicsQuality === 'auto'
        ? this.baseHardwareTier
        : (s.graphicsQuality as ResolvedTier);
    this.applyResolvedTier(desiredTier);
    audioEngine.applySettings(s);
  }

  private applyResolvedTier(tier: ResolvedTier) {
    this.resolvedTier = tier;
    const scaleMap: Record<ResolvedTier, number> = { low: 0.72, medium: 0.86, high: 1.0, ultra: 1.0 };
    const maxDprMap: Record<ResolvedTier, number> = { low: 1.0, medium: 1.25, high: 1.5, ultra: 2.0 };
    const baseRatio = this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, maxDprMap[tier]);
    const effectiveRatio = this.isSoftwareGl
      ? 1
      : Math.max(0.55, Math.min(maxDprMap[tier], baseRatio * this.settings.resolutionScale * scaleMap[tier]));

    this.renderer.setPixelRatio(effectiveRatio);
    const enableShadows = !this.isSoftwareGl && this.settings.shadowsEnabled && (tier === 'high' || tier === 'ultra');
    this.renderer.shadowMap.enabled = enableShadows;
    this.keyLight.castShadow = enableShadows;
    this.flashlight.castShadow = enableShadows && tier === 'ultra';

    const desiredShadowSize = tier === 'ultra' ? 1024 : 512;
    if (this.keyLight.shadow.mapSize.x !== desiredShadowSize) {
      this.keyLight.shadow.mapSize.set(desiredShadowSize, desiredShadowSize);
      this.keyLight.shadow.map?.dispose();
      this.keyLight.shadow.map = null;
    }

    if ((tier === 'high' || tier === 'ultra') && !this.pmremEnv && !this.isSoftwareGl) {
      try {
        const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
        this.pmremEnv = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
        pmremGenerator.dispose();
      } catch {
        this.pmremEnv = null;
      }
    }
    this.scene.environment = (tier === 'high' || tier === 'ultra') && this.pmremEnv ? this.pmremEnv : null;
    this.renderer.toneMappingExposure = this.settings.brightness;

    if (this.dustPoints) {
      this.dustPoints.visible = tier !== 'low' || this.progress.chapter !== 1;
    }
    if (this.level) {
      this.level.root.traverse((obj) => {
        if (obj.userData?.isVolumetricMist) {
          obj.visible = this.settings.volumetricFog && tier !== 'low';
        }
      });
    }
  }

  public setTouchMove(x: number, y: number, sprint: boolean) {
    this.touchMove.x = x;
    this.touchMove.y = y;
    this.touchSprint = sprint;
  }

  public setTouchSprintLocked(active: boolean) {
    this.touchSprintLocked = active;
    if (active) this.isCrouching = false;
  }

  public addLookDelta(dx: number, dy: number) {
    const sens = 0.0044 * this.settings.lookSensitivity;
    this.playerYaw -= dx * sens;
    this.playerPitch = THREE.MathUtils.clamp(this.playerPitch - dy * sens, -1.15, 1.15);
  }

  public toggleFlashlight() {
    if (this.progress.battery <= 0) {
      this.flashlightOn = false;
      return;
    }
    this.flashlightOn = !this.flashlightOn;
    audioEngine.playSfx('click');
    this.emitHudState({ nearestThreatDist: 999, isChased: false }, true);
  }

  public toggleCrouch() {
    if (this.isHiding) return;
    this.isCrouching = !this.isCrouching;
    if (this.isCrouching) this.touchSprintLocked = false;
    this.emitHudState({ nearestThreatDist: 999, isChased: false }, true);
  }

  public triggerJump() {
    if (!this.onGround || this.isHiding) return;
    if (this.isCrouching) {
      this.isCrouching = false;
    }
    this.playerVelY = 5.1;
    this.onGround = false;
    audioEngine.playSfx('click');
  }

  public toggleCameraPerspective(): CameraPerspective {
    const next: CameraPerspective = this.settings.cameraPerspective === 'first' ? 'third' : 'first';
    this.settings.cameraPerspective = next;
    return next;
  }

  public syncPlayerPositionToProgress() {
    this.progress.playerPosition = {
      x: this.playerPos.x,
      y: this.playerPos.y,
      z: this.playerPos.z,
      yaw: this.playerYaw,
    };
  }

  public getPlayerDebugSnapshot() {
    const zoya = this.enemies[0];
    return {
      x: this.playerPos.x,
      y: this.playerPos.y,
      z: this.playerPos.z,
      velY: this.playerVelY,
      onGround: this.onGround,
      yaw: this.playerYaw,
      resolvedTier: this.resolvedTier,
      pointLightCount: this.level?.flickerLights.length || 0,
      enemyCount: this.enemies.length,
      enemyKinds: this.enemies.map((e) => e.kind),
      zoyaState: zoya?.state ?? null,
      zoyaVisible: zoya?.mesh.visible ?? false,
      zoyaStateTimer: zoya?.stateTimer ?? 0,
    };
  }

  /**
   * Helper for deterministic AI verification tests to step Zoya's AI encounter timeline safely.
   */
  public stepGhostDirectorForTest(dt: number, forceState?: ZoyaAIState) {
    const zoya = this.enemies[0];
    if (!zoya) return;
    if (forceState) {
      zoya.state = forceState;
      if (forceState === 'chase') {
        zoya.stateTimer = 10;
        zoya.mesh.visible = true;
        zoya.fadeAlpha = 1;
        zoya.pos.set(this.playerPos.x, this.playerPos.y, this.playerPos.z - 4.0);
        zoya.mesh.position.copy(zoya.pos);
      } else if (forceState === 'distant_omen') {
        zoya.stateTimer = 6.5;
      } else if (forceState === 'distant_silhouette') {
        zoya.stateTimer = 5.0;
        zoya.mesh.visible = true;
        zoya.fadeAlpha = 1;
      }
    }
    this.updateEnemies(dt);
  }

  public handlePrimaryInteract() {
    if (this.isHiding) {
      this.isHiding = false;
      this.activeHideSpot = null;
      audioEngine.playSfx('door_creak');
      return;
    }

    const nearest = this.findNearestInteractable();
    if (!nearest) return;

    if (nearest.type === 'hide') {
      this.isHiding = true;
      this.activeHideSpot = nearest;
      this.isCrouching = false;
      this.touchSprintLocked = false;
      audioEngine.playSfx('door_creak');
      return;
    }

    if (nearest.type === 'save') {
      audioEngine.playSfx('pickup');
      this.syncPlayerPositionToProgress();
      this.callbacks.onOpenSaveShrine();
      return;
    }

    if (nearest.type === 'puzzle' && nearest.puzzleId) {
      this.callbacks.onOpenPuzzle(nearest.puzzleId);
      return;
    }

    if (nearest.type === 'brazier') {
      if (nearest.isLit) return;
      nearest.isLit = true;
      audioEngine.playSfx('unlock');
      nearest.mesh.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const m = (child as THREE.Mesh).material as THREE.MeshStandardMaterial;
          if (m && m.emissiveIntensity > 0) {
            m.color.setHex(0x10b981);
            m.emissive.setHex(0x10b981);
          }
        }
      });

      const isSecretShard = nearest.id.startsWith('secret_shard_');
      const zoya = this.enemies[0];
      const legacyBossId = isSecretShard
        ? 'boss_secret_sovereign'
        : this.progress.chapter === 1
        ? 'boss_matriarch'
        : this.progress.chapter === 2
        ? 'boss_caretaker'
        : 'boss_dimension';

      if (zoya) {
        zoya.tetherEngaged = true;
        if (isSecretShard) {
          zoya.secretTetherHp = Math.max(0, zoya.secretTetherHp - 1);
        } else {
          zoya.chapterTetherHp = Math.max(0, zoya.chapterTetherHp - 1);
        }

        const remaining = isSecretShard ? zoya.secretTetherHp : zoya.chapterTetherHp;
        const maxHp = isSecretShard ? zoya.secretTetherMax : zoya.chapterTetherMax;

        // Visual & audio feedback: shockwave erupts around seal or Zoya
        this.cameraShake = 0.55;
        this.shockwaveProgress = 0;
        const ringOrigin = zoya.mesh.visible ? zoya.pos : nearest.position;
        this.shockwaveRing.position.set(ringOrigin.x, ringOrigin.y + 0.15, ringOrigin.z);
        (this.shockwaveRing.material as THREE.MeshBasicMaterial).color.setHex(
          isSecretShard ? 0xec4899 : 0xe11d48
        );
        this.shockwaveRing.visible = true;
        audioEngine.play3DSound('scream', nearest.position, 0.85);

        // Banish Zoya temporarily when seal ignites so ritual never frustrates
        if (zoya.state !== 'dormant') {
          zoya.state = 'vanishing';
          zoya.stateTimer = 1.1;
        } else {
          zoya.stateTimer = Math.max(zoya.stateTimer, 22);
        }

        if (remaining <= 0) {
          if (!this.progress.defeatedBossIds.includes(legacyBossId)) {
            this.progress.defeatedBossIds.push(legacyBossId);
          }
          this.callbacks.onProgressMutated();
          const msgEn =
            this.progress.chapter === 1
              ? 'All 3 Ward Seals purified! Zoya’s grip on Door IX shatters—escape through Door IX!'
              : this.progress.chapter === 2
              ? 'All 3 Graveyard Braziers blaze! Zoya shrieks back into the mist—the Mausoleum Portal is open!'
              : isSecretShard
              ? 'All 4 Rift Shards shattered! Step into the Secret Altar!'
              : 'All 3 Reality Anchors stabilized! The Final Threshold awaits!';
          const msgUr =
            this.progress.chapter === 1
              ? 'تینوں مقدس مہریں روشن ہو گئیں! نویں دروازے کا راستہ کھل گیا ہے۔'
              : this.progress.chapter === 2
              ? 'تینوں مشعلیں روشن ہو گئیں! مقبرے کا پورٹل کھل چکا ہے۔'
              : isSecretShard
              ? 'چاروں خفیہ شیشے ٹوٹ گئے! خفیہ دروازے میں قدم رکھیں!'
              : 'حقیقت کے تین ستون بحال ہو گئے! آخری دروازہ کھل چکا ہے۔';
          this.callbacks.onShowSubtitle('Seal Broken', 'مہر ٹوٹ گئی', msgEn, msgUr, 4.5);
        } else {
          this.callbacks.onShowSubtitle(
            'Ward Lit',
            'مہر روشن',
            `Seal activated! (${maxHp - remaining}/${maxHp})`,
            `مقدس مہر فعال ہو گئی! (${maxHp - remaining}/${maxHp})`,
            2.6
          );
        }
      }
      return;
    }

    if (nearest.type === 'door' && nearest.doorNumber) {
      this.interactWithDoor(nearest.doorNumber);
      return;
    }

    if (nearest.type === 'pickup') {
      this.collectPickup(nearest);
      return;
    }

    if (nearest.type === 'portal') {
      this.interactWithPortal(nearest.id);
    }
  }

  private interactWithDoor(doorNumber: number) {
    if (!this.level) return;
    const def = DOORS.find((d) => d.doorNumber === doorNumber);
    const runtime = this.level.doors.find((d) => d.doorNumber === doorNumber);
    if (!def || !runtime) return;

    if (!runtime.isUnlocked) {
      const hasKey = !def.requiredKeyId || this.progress.inventory.some((i) => i.id === def.requiredKeyId);
      const hasPuzzle = !def.requiredPuzzleId || this.progress.solvedPuzzleIds.includes(def.requiredPuzzleId);
      if (hasKey && hasPuzzle) {
        runtime.isUnlocked = true;
        runtime.statusOrbMat.color.setHex(0x34d399);
        if (!this.progress.unlockedDoorIds.includes(def.id)) {
          this.progress.unlockedDoorIds.push(def.id);
        }
        audioEngine.playSfx('unlock');
      } else {
        audioEngine.play3DSound('knock', runtime.group.position);
        const keyName = def.requiredKeyId ? ITEMS_CATALOG[def.requiredKeyId] : null;
        this.callbacks.onShowSubtitle(
          def.nameEn,
          def.nameUr,
          !hasKey && keyName
            ? `Locked. Requires ${keyName.nameEn}.`
            : 'Sealed by Zoya’s Portrait Cipher (Door VII).',
          !hasKey && keyName
            ? `مقفل ہے۔ اس کے لیے ${keyName.nameUr} درکار ہے۔`
            : 'یہ دروازہ ساتویں دروازے کی تصویر کے کوڈ سے بند ہے۔',
          3.4
        );
        return;
      }
    }

    runtime.isOpen = !runtime.isOpen;
    runtime.collider.active = !runtime.isOpen;
    audioEngine.playSfx('door_creak');

    if (doorNumber === 9 && runtime.isOpen && !this.progress.aliRescued) {
      this.progress.aliRescued = true;
      this.progress.aliFollowing = true;
      this.progress.unlockedChapters = Array.from(new Set([...this.progress.unlockedChapters, 2])) as ChapterId[];
      this.callbacks.onProgressMutated();
      this.callbacks.onTriggerCinematic('ali_reunion');
    }
  }

  private collectPickup(item: InteractableObj) {
    item.isCollected = true;
    item.mesh.visible = false;
    if (this.level) {
      const idx = this.level.interactables.indexOf(item);
      if (idx >= 0) this.level.interactables.splice(idx, 1);
    }

    if (item.bottleId) {
      audioEngine.playSfx('bottle');
      if (!this.progress.collectedBottleIds.includes(item.bottleId)) {
        this.progress.collectedBottleIds.push(item.bottleId);
      }
      const b = BOTTLES.find((x) => x.id === item.bottleId);
      if (b) {
        this.addInventoryItem({
          id: b.id,
          category: 'bottle',
          nameEn: b.nameEn,
          nameUr: b.nameUr,
          descEn: b.labelEn,
          descUr: b.labelUr,
          clueEn: b.secretHintEn,
          clueUr: b.secretHintUr,
          liquidColor: b.liquidColor,
          symbol: b.symbol,
          quantity: 1,
        });
        this.callbacks.onShowSubtitle(b.nameEn, b.nameUr, b.secretHintEn, b.secretHintUr, 4.0);
      }
    } else if (item.letterId) {
      audioEngine.playSfx('paper');
      if (!this.progress.collectedLetterIds.includes(item.letterId)) {
        this.progress.collectedLetterIds.push(item.letterId);
        const ltr = LETTERS.find((l) => l.id === item.letterId);
        if (ltr?.clueTag) {
          this.progress.truthCluesFound += 1;
        }
      }
      this.callbacks.onOpenLetter(item.letterId);
    } else if (item.itemId) {
      audioEngine.playSfx('pickup');
      if (item.itemId === 'battery') {
        this.progress.battery = Math.min(100, this.progress.battery + 45);
        this.callbacks.onShowSubtitle('Supplies', 'سامان', 'Battery collected (+45% Charge).', 'بیٹری مل گئی (+45% چارج)۔', 2.4);
      } else if (item.itemId === 'map_fragment') {
        this.progress.discoveredMapFragments += 1;
        MAP_ROOMS.filter((r) => r.chapter === this.progress.chapter).forEach((r) => {
          if (!this.progress.discoveredRoomIds.includes(r.id)) {
            this.progress.discoveredRoomIds.push(r.id);
          }
        });
        this.callbacks.onShowSubtitle('Map', 'نقشہ', 'Blueprint Fragment reveals nearby rooms on your Map!', 'نقشے کا ٹکڑا مل گیا—آس پاس کے کمرے ظاہر ہو گئے!', 3.2);
      } else {
        const cat = ITEMS_CATALOG[item.itemId];
        if (cat) {
          this.addInventoryItem({ ...cat, quantity: 1 });
          this.callbacks.onShowSubtitle(cat.nameEn, cat.nameUr, cat.descEn, cat.descUr, 3.0);
        }
      }
    }

    this.callbacks.onProgressMutated();
  }

  private interactWithPortal(portalId: string) {
    if (portalId === 'portal_to_ch2') {
      if (!this.progress.aliRescued) {
        this.callbacks.onShowSubtitle('Locked', 'بند', 'Rescue Ali Ahmed behind Door IX first.', 'پہلے نویں دروازے سے علی احمد کو بچائیں۔', 3);
        return;
      }
      if (!this.progress.defeatedBossIds.includes('boss_matriarch')) {
        this.callbacks.onShowSubtitle('Sealed', 'مقفل', 'Purify the 3 Ward Seals in the North Gallery & Sanctum first!', 'پہلے تین مقدس مہریں روشن کریں!', 3.6);
        return;
      }
      this.progress.chapter = 2;
      this.progress.unlockedChapters = [1, 2];
      this.loadChapter(this.progress, false);
      this.callbacks.onProgressMutated();
      this.callbacks.onTriggerCinematic('chapter2_intro');
    } else if (portalId === 'portal_to_ch3') {
      if (!this.progress.defeatedBossIds.includes('boss_caretaker')) {
        this.callbacks.onShowSubtitle('Sealed', 'مقفل', 'Ignite the 3 Graveyard Ward Braziers first!', 'پہلے قبرستان کی تین مشعلیں روشن کریں!', 3.5);
        return;
      }
      this.progress.chapter = 3;
      this.progress.unlockedChapters = [1, 2, 3];
      this.loadChapter(this.progress, false);
      this.callbacks.onProgressMutated();
      this.callbacks.onTriggerCinematic('chapter3_intro');
    } else if (portalId === 'portal_final_truth') {
      if (!this.progress.defeatedBossIds.includes('boss_dimension')) {
        this.callbacks.onShowSubtitle('Blocked', 'رکاوٹ', 'Stabilize the 3 Reality Anchors first!', 'پہلے تین حقیقت کے ستون بحال کریں!', 3.5);
        return;
      }
      const ending = this.evaluateEnding(false);
      this.callbacks.onTriggerEnding(ending);
    } else if (portalId === 'portal_secret_ending') {
      const hasEclipse = this.progress.inventory.some((i) => i.id === 'seal_eclipse');
      const allBottles = this.progress.collectedBottleIds.length >= 9;
      const cipherSolved = this.progress.solvedPuzzleIds.includes('puzzle_quantum_cipher');
      const secretBossDefeated = this.progress.defeatedBossIds.includes('boss_secret_sovereign');
      if (!hasEclipse || !allBottles || !cipherSolved || !secretBossDefeated) {
        this.callbacks.onShowSubtitle(
          'Hidden Rift Sanctum',
          'خفیہ خلائی مقام',
          `Requires Eclipse Seal, 9 Bottles (${this.progress.collectedBottleIds.length}/9), Quantum Cipher, and shattering the 4 Sanctum Shards.`,
          `اس کے لیے گرہن کی مہر، 9 بوتلیں (${this.progress.collectedBottleIds.length}/9)، جہتی کوڈ اور 4 شیشوں کو توڑنا ضروری ہے۔`,
          4.4
        );
        return;
      }
      this.callbacks.onTriggerEnding('secret');
    }
  }

  private evaluateEnding(failedOrBad: boolean): EndingId {
    if (failedOrBad || (!this.progress.aliRescued && this.progress.truthCluesFound < 2)) {
      return 'bad';
    }
    if (
      this.progress.truthCluesFound >= 5 &&
      this.progress.collectedBottleIds.length >= 7 &&
      this.progress.collectedLetterIds.length >= 8
    ) {
      return 'true';
    }
    if (this.progress.truthCluesFound >= 3 || this.progress.collectedBottleIds.length >= 5) {
      return 'good';
    }
    return 'normal';
  }

  public addInventoryItem(item: InventoryItem) {
    const existing = this.progress.inventory.find((i) => i.id === item.id);
    if (existing) {
      existing.quantity += item.quantity;
    } else {
      this.progress.inventory.push(item);
    }
  }

  public onPuzzleSolved(puzzleId: string, rewardItemId?: string) {
    if (!this.progress.solvedPuzzleIds.includes(puzzleId)) {
      this.progress.solvedPuzzleIds.push(puzzleId);
    }
    if (rewardItemId) {
      const cat = ITEMS_CATALOG[rewardItemId];
      if (cat) {
        this.addInventoryItem({ ...cat, quantity: 1 });
        this.callbacks.onShowSubtitle('Acquired', 'حاصل ہوا', `Obtained ${cat.nameEn}!`, `${cat.nameUr} حاصل کر لی گئی!`, 3.5);
      }
    }
    if (puzzleId === 'puzzle_quantum_cipher') {
      this.progress.secretRiftUnlocked = true;
    }
    // Grant breathing grace right after solving any puzzle
    const zoya = this.enemies[0];
    if (zoya && zoya.state === 'dormant') {
      zoya.stateTimer = Math.max(zoya.stateTimer, 14);
    }
    audioEngine.playSfx('unlock');
    this.callbacks.onProgressMutated();
  }

  private findNearestInteractable(): InteractableObj | null {
    if (!this.level) return null;
    let best: InteractableObj | null = null;
    let bestDist = Infinity;
    for (let i = 0; i < this.level.interactables.length; i++) {
      const obj = this.level.interactables[i];
      if (obj.isCollected) continue;
      if (obj.type === 'brazier' && obj.isLit) continue;
      const dx = obj.position.x - this.playerPos.x;
      const dz = obj.position.z - this.playerPos.z;
      const d = Math.hypot(dx, dz);
      const dy = Math.abs(obj.position.y - (this.playerPos.y + 1.0));
      if (d <= obj.radius && dy < 2.2 && d < bestDist) {
        best = obj;
        bestDist = d;
      }
    }
    return best;
  }

  private resolveCollisions(pos: THREE.Vector3, radius: number) {
    if (!this.level) return;
    const cols = this.level.colliders;
    for (let i = 0; i < cols.length; i++) {
      const c = cols[i];
      if (!c.active) continue;
      const closestX = THREE.MathUtils.clamp(pos.x, c.minX, c.maxX);
      const closestZ = THREE.MathUtils.clamp(pos.z, c.minZ, c.maxZ);
      const dx = pos.x - closestX;
      const dz = pos.z - closestZ;
      const distSq = dx * dx + dz * dz;
      if (distSq < radius * radius) {
        const dist = Math.sqrt(distSq) || 0.0001;
        const push = radius - dist;
        pos.x += (dx / dist) * push;
        pos.z += (dz / dist) * push;
      }
    }
    const b = this.level.bounds;
    pos.x = THREE.MathUtils.clamp(pos.x, b.minX, b.maxX);
    pos.z = THREE.MathUtils.clamp(pos.z, b.minZ, b.maxZ);
  }

  private tick = () => {
    if (!this.running) return;
    const now = performance.now();

    if (!this.isSoftwareGl && this.settings.targetFps === 30) {
      if (now - this.lastRenderTime < 28) {
        this.frameId = requestAnimationFrame(this.tick);
        return;
      }
    }

    const rawDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    this.lastRenderTime = now;
    const dt = Math.min(rawDt, 0.05);
    this.elapsed += dt;

    if (this.activeMode === 'playing' && this.settings.graphicsQuality === 'auto' && !this.isSoftwareGl) {
      this.perfFrameAccum += rawDt;
      this.perfFrameCount += 1;
      if (this.perfFrameCount >= 90) {
        const avgMs = (this.perfFrameAccum / this.perfFrameCount) * 1000;
        this.perfFrameAccum = 0;
        this.perfFrameCount = 0;
        if (avgMs > 46 && this.resolvedTier !== 'low') {
          const nextDown: ResolvedTier =
            this.resolvedTier === 'ultra' ? 'high' : this.resolvedTier === 'high' ? 'medium' : 'low';
          this.applyResolvedTier(nextDown);
        }
      }
    }

    if (this.activeMode === 'title') {
      this.updateTitleScene(dt);
    } else if (this.activeMode === 'playing') {
      this.updateGameplay(dt);
    }

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private updateTitleScene(dt: number) {
    const t = this.elapsed;
    this.camera.position.set(
      Math.sin(t * 0.14) * 3.2,
      2.2 + Math.sin(t * 0.3) * 0.15,
      4.2 + Math.cos(t * 0.12) * 1.4
    );
    this.camera.lookAt(0, 2.3, -10);
    this.flashlight.intensity = 0;
    this.volumetricCone.visible = false;
    this.animateDust(dt);
  }

  private animateDust(_dt: number) {
    if (!this.dustPoints || !this.dustUniforms) return;
    this.dustUniforms.uTime.value = this.elapsed;
    this.dustPoints.position.set(this.playerPos.x, 0, this.playerPos.z);
  }

  public stepPhysics(dt: number) {
    const moveFwd =
      (this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0) -
      (this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0) +
      this.touchMove.y;
    const moveSide =
      (this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0) -
      (this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0) +
      this.touchMove.x;

    const wantsSprint =
      (this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchSprint || this.touchSprintLocked) &&
      !this.isCrouching &&
      !this.isHiding &&
      this.progress.stamina > 2;
    const isMoving = Math.abs(moveFwd) > 0.04 || Math.abs(moveSide) > 0.04;

    if (wantsSprint && isMoving) {
      this.progress.stamina = Math.max(0, this.progress.stamina - dt * 18);
      if (this.progress.stamina <= 0.5) {
        this.touchSprintLocked = false;
      }
    } else {
      this.progress.stamina = Math.min(100, this.progress.stamina + dt * 16);
    }

    if (!this.isHiding && isMoving) {
      const speed = this.isCrouching ? 2.2 : wantsSprint ? 5.65 : 3.65;
      _forward.set(-Math.sin(this.playerYaw), 0, -Math.cos(this.playerYaw));
      _right.set(Math.cos(this.playerYaw), 0, -Math.sin(this.playerYaw));

      _vec3A.set(0, 0, 0).addScaledVector(_forward, moveFwd).addScaledVector(_right, moveSide);
      if (_vec3A.lengthSq() > 1) _vec3A.normalize();

      const oldX = this.playerPos.x;
      const oldZ = this.playerPos.z;
      const dx = _vec3A.x * speed * dt;
      const dz = _vec3A.z * speed * dt;

      this.playerPos.x += dx;
      this.resolveCollisions(this.playerPos, 0.42);
      if (this.getGroundHeight(this.playerPos.x, this.playerPos.z) - this.playerPos.y > 0.65) {
        this.playerPos.x = oldX;
      }

      this.playerPos.z += dz;
      this.resolveCollisions(this.playerPos, 0.42);
      if (this.getGroundHeight(this.playerPos.x, this.playerPos.z) - this.playerPos.y > 0.65) {
        this.playerPos.z = oldZ;
      }

      this.headBobPhase += dt * (wantsSprint ? 13 : 8);
      this.walkAnimPhase += dt * (wantsSprint ? 14 : 9);
      audioEngine.playFootstep(wantsSprint, this.isCrouching);
      this.noiseLevel = THREE.MathUtils.damp(
        this.noiseLevel,
        this.isCrouching ? 0.15 : wantsSprint ? 1.0 : 0.48,
        10,
        dt
      );
    } else {
      this.noiseLevel = THREE.MathUtils.damp(this.noiseLevel, 0, 8, dt);
    }

    const groundY = this.getGroundHeight(this.playerPos.x, this.playerPos.z);
    if (!this.onGround || this.playerPos.y > groundY + 0.08) {
      this.playerVelY -= 15.0 * dt;
      this.playerPos.y += this.playerVelY * dt;
      if (this.playerPos.y <= groundY) {
        this.playerPos.y = groundY;
        this.playerVelY = 0;
        this.onGround = true;
      }
    } else {
      this.playerPos.y = groundY;
      this.playerVelY = 0;
      this.onGround = true;
    }

    return isMoving;
  }

  private updateGameplay(dt: number) {
    this.progress.playTimeSeconds += dt;
    this.animateDust(dt);

    if (this.level) {
      if (this.level.mistUniforms) {
        this.level.mistUniforms.uTime.value = this.elapsed;
      }
      for (let i = 0; i < this.level.doors.length; i++) {
        const d = this.level.doors[i];
        const target = d.isOpen ? -Math.PI * 0.56 : 0;
        if (Math.abs(d.openProgress - target) > 0.002) {
          d.openProgress = THREE.MathUtils.damp(d.openProgress, target, 6.5, dt);
          d.doorLeaf.rotation.y = d.openProgress;
        }
      }

      // Dynamic flickering lights + Zoya omen electrical interference
      const omenBoost = this.zoyaOmenFlicker;
      for (let i = 0; i < this.level.flickerLights.length; i++) {
        const fl = this.level.flickerLights[i];
        if (fl.kind === 'emergency') {
          const pulse = 0.4 + Math.max(0, Math.sin(this.elapsed * 4.5 + fl.phase)) * 0.85;
          fl.light.intensity = fl.baseIntensity * pulse;
        } else if (fl.kind === 'fluorescent') {
          const stutter = Math.sin(this.elapsed * 29 + fl.phase) * Math.sin(this.elapsed * 7.1 + fl.phase);
          const dip = stutter > 0.72 || omenBoost > 0.3 ? 0.25 : 1.0;
          fl.light.intensity = fl.baseIntensity * dip;
        } else {
          const wave = Math.sin(this.elapsed * 7.5 + fl.phase) * Math.sin(this.elapsed * 19.3 + fl.phase);
          fl.light.intensity = fl.baseIntensity * (0.88 + wave * (0.18 + omenBoost * 0.45));
        }
      }

      // Flickering ceiling fluorescent tubes
      for (let i = 0; i < this.level.flickerTubes.length; i++) {
        const ft = this.level.flickerTubes[i];
        if (ft.broken) continue;
        const n = Math.sin(this.elapsed * 24 + ft.phase) * Math.sin(this.elapsed * 6.3 + ft.phase);
        const on = n < 0.76 && !(omenBoost > 0.4 && Math.sin(this.elapsed * 37) > 0.2);
        ft.mat.color.setHex(on ? ft.baseColor : 0x182222);
      }

      // Ceiling water drips (Basement & Underground Morgue)
      for (let i = 0; i < this.level.dripEmitters.length; i++) {
        const em = this.level.dripEmitters[i];
        const span = em.origin.y - em.floorY;
        const cycle = (this.elapsed * em.speed + em.phase) % 2.4;
        if (cycle < 0.85) {
          const frac = (cycle / 0.85) * (cycle / 0.85);
          em.mesh.visible = true;
          em.mesh.position.y = em.origin.y - frac * span;
        } else {
          em.mesh.visible = false;
        }
      }

      // Ambient hospital / basement audio cues
      this.ambientCueCooldown -= dt;
      if (this.ambientCueCooldown <= 0) {
        this.ambientCueCooldown = 7.5 + Math.random() * 7;
        if (this.progress.chapter === 1) {
          if (this.playerPos.y < -0.5) {
            audioEngine.play3DSound(
              Math.random() > 0.45 ? 'water_drip' : 'electrical_spark',
              { x: this.playerPos.x + (Math.random() - 0.5) * 6, y: this.playerPos.y + 1.5, z: this.playerPos.z - 3 }
            );
          } else {
            audioEngine.play3DSound(
              Math.random() > 0.5 ? 'fluorescent_buzz' : 'pipe_creak',
              { x: this.playerPos.x + (Math.random() - 0.5) * 10, y: 3.4, z: this.playerPos.z - 4 }
            );
          }
        } else if (this.progress.chapter === 2 && this.playerPos.y < -0.5) {
          audioEngine.play3DSound('water_drip', { x: 24, y: 0.5, z: -13 });
        }
      }

      // Distance LOD toggle pass (~5Hz) for Android performance
      this.lodCheckAccum += dt;
      if (this.lodCheckAccum >= 0.2) {
        this.lodCheckAccum = 0;
        const tierMult =
          this.resolvedTier === 'low' ? 0.62 : this.resolvedTier === 'medium' ? 0.85 : 1.15;
        for (let i = 0; i < this.level.lodProps.length; i++) {
          const item = this.level.lodProps[i];
          const dx = item.obj.position.x - this.playerPos.x;
          const dz = item.obj.position.z - this.playerPos.z;
          item.obj.visible = dx * dx + dz * dz <= item.maxDistSq * tierMult;
        }
      }

      if (this.level.quantumShiftObjects.length > 0) {
        this.camera.getWorldDirection(_vec3B);
        for (let i = 0; i < this.level.quantumShiftObjects.length; i++) {
          const qObj = this.level.quantumShiftObjects[i];
          _vec3A.subVectors(qObj.position, this.camera.position).normalize();
          if (_vec3A.dot(_vec3B) < 0.15) {
            qObj.rotation.y += dt * 0.9;
            qObj.position.y = 4.5 + Math.sin(this.elapsed * 1.4 + qObj.position.x) * 1.6;
          }
        }
      }
    }

    if (this.shockwaveProgress >= 0) {
      this.shockwaveProgress += dt * 1.8;
      if (this.shockwaveProgress >= 1) {
        this.shockwaveProgress = -1;
        this.shockwaveRing.visible = false;
      } else {
        this.shockwaveRing.scale.setScalar(1 + this.shockwaveProgress * 9.5);
        (this.shockwaveRing.material as THREE.MeshBasicMaterial).opacity = (1 - this.shockwaveProgress) * 0.72;
      }
    }

    const isMoving = this.stepPhysics(dt);

    if (this.flashlightOn && this.progress.battery > 0) {
      const drainRate = this.settings.difficulty === 'nightmare' ? 0.95 : 0.6;
      this.progress.battery = Math.max(0, this.progress.battery - dt * drainRate);
      if (this.progress.battery <= 0) this.flashlightOn = false;
    }

    this.cameraShake = THREE.MathUtils.damp(this.cameraShake, 0, 8, dt);
    const shakeX = this.cameraShake > 0.01 ? (Math.random() - 0.5) * this.cameraShake * 0.25 : 0;
    const shakeY = this.cameraShake > 0.01 ? (Math.random() - 0.5) * this.cameraShake * 0.25 : 0;

    if (this.isHiding && this.activeHideSpot) {
      this.playerRig.group.visible = false;
      this.camera.position.set(
        this.activeHideSpot.position.x,
        this.activeHideSpot.position.y + 0.45,
        this.activeHideSpot.position.z
      );
      if (this.activeHideSpot.hideLookAt) {
        this.camera.lookAt(this.activeHideSpot.hideLookAt);
      }
    } else if (this.settings.cameraPerspective === 'first') {
      this.playerRig.group.visible = false;
      const eyeH = this.isCrouching ? 1.02 : 1.64;
      const bob = isMoving ? Math.sin(this.headBobPhase) * 0.042 : Math.sin(this.elapsed * 1.6) * 0.01;
      this.camera.position.set(this.playerPos.x + shakeX, this.playerPos.y + eyeH + bob + shakeY, this.playerPos.z);
      _camTarget.set(
        this.camera.position.x - Math.sin(this.playerYaw) * Math.cos(this.playerPitch),
        this.camera.position.y + Math.sin(this.playerPitch),
        this.camera.position.z - Math.cos(this.playerYaw) * Math.cos(this.playerPitch)
      );
      this.camera.lookAt(_camTarget);
    } else {
      this.playerRig.group.visible = true;
      this.playerRig.group.position.copy(this.playerPos);
      this.playerRig.group.rotation.y = this.playerYaw + Math.PI;
      this.playerRig.group.scale.y = this.isCrouching ? 0.72 : 1.0;

      const swing = isMoving ? Math.sin(this.walkAnimPhase) * 0.55 : 0;
      this.playerRig.leftLeg.rotation.x = swing;
      this.playerRig.rightLeg.rotation.x = -swing;
      this.playerRig.leftArm.rotation.x = -swing * 0.6;

      const camBack = 3.2;
      const desiredX = this.playerPos.x + Math.sin(this.playerYaw) * camBack;
      const desiredZ = this.playerPos.z + Math.cos(this.playerYaw) * camBack;
      const desiredY = this.playerPos.y + (this.isCrouching ? 1.75 : 2.15) - Math.sin(this.playerPitch) * 1.1;

      _vec3A.set(desiredX, desiredY, desiredZ);
      this.resolveCollisions(_vec3A, 0.35);
      this.camera.position.lerp(_vec3A, 1 - Math.exp(-12 * dt));
      this.camera.lookAt(
        this.playerPos.x - Math.sin(this.playerYaw) * 2.0,
        this.playerPos.y + 1.35 + Math.sin(this.playerPitch) * 1.5,
        this.playerPos.z - Math.cos(this.playerYaw) * 2.0
      );
    }

    // Flashlight + volumetric cone + bounce light
    this.flashlight.position.copy(this.camera.position);
    this.camera.getWorldDirection(_rayDir);
    this.flashlightTarget.position.copy(this.camera.position).addScaledVector(_rayDir, 6);
    const lowBatFlicker = this.progress.battery < 18 && Math.sin(this.elapsed * 31) > 0.75 ? 0.25 : 1;
    const omenDim = this.zoyaOmenFlicker > 0.45 && Math.sin(this.elapsed * 27) > 0.5 ? 0.45 : 1;
    this.flashlight.intensity = this.flashlightOn ? 6.4 * lowBatFlicker * omenDim : 0;

    this.nearFillLight.position.set(this.playerPos.x, this.playerPos.y + 1.85, this.playerPos.z);
    if (this.keyLight.castShadow) {
      this.keyLight.position.set(this.playerPos.x + 12, 24, this.playerPos.z + 10);
      this.keyLight.target.position.copy(this.playerPos);
      this.keyLight.target.updateMatrixWorld();
    }

    const showVolBeam =
      this.flashlightOn &&
      this.settings.volumetricFog &&
      this.resolvedTier !== 'low' &&
      !this.isHiding;
    this.volumetricCone.visible = showVolBeam;
    if (showVolBeam) {
      this.volumetricUniforms.uTime.value = this.elapsed;
      this.volumetricUniforms.uOpacity.value = (this.resolvedTier === 'ultra' ? 0.16 : 0.12) * lowBatFlicker;
      this.volumetricCone.position.copy(this.camera.position).addScaledVector(_rayDir, 0.28);
      this.volumetricCone.lookAt(this.flashlightTarget.position);
    }

    audioEngine.updateListener(this.playerPos, this.playerYaw);

    const threatStatus = this.updateEnemies(dt);

    const isSprinting =
      (this.keys['ShiftLeft'] || this.keys['ShiftRight'] || this.touchSprint || this.touchSprintLocked) &&
      isMoving;
    const targetFov = threatStatus.isChased ? 76 : isSprinting ? 74 : this.isCrouching ? 66 : 71;
    if (Math.abs(this.camera.fov - targetFov) > 0.08) {
      this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 7, dt);
      this.camera.updateProjectionMatrix();
    }

    this.updateAliCompanion(dt, threatStatus.isChased);
    this.updateRoomDiscovery();

    this.hudEmitAccum += dt;
    if (this.hudEmitAccum >= 0.095) {
      this.hudEmitAccum = 0;
      this.emitHudState(threatStatus);
    }
  }

  private pickSpawnSpotAroundPlayer(minDist: number, maxDist: number): THREE.Vector3 {
    const out = new THREE.Vector3();
    const angle = Math.random() * Math.PI * 2;
    const r = minDist + Math.random() * (maxDist - minDist);
    out.set(this.playerPos.x + Math.cos(angle) * r, this.playerPos.y, this.playerPos.z + Math.sin(angle) * r);
    if (this.level) {
      out.x = THREE.MathUtils.clamp(out.x, this.level.bounds.minX + 1.5, this.level.bounds.maxX - 1.5);
      out.z = THREE.MathUtils.clamp(out.z, this.level.bounds.minZ + 1.5, this.level.bounds.maxZ - 1.5);
      this.resolveCollisions(out, 0.55);
      out.y = this.getGroundHeight(out.x, out.z);
    }
    return out;
  }

  /**
   * Intelligent Single-Ghost (Zoya) AI Director:
   * Gives generous exploration & puzzle time, builds dread via distant omens & silhouettes,
   * alternates uncanny walking & 4-limb crawling, and ALWAYS disappears for a long dormant
   * cooldown after attacking or losing a chase.
   */
  private updateEnemies(dt: number) {
    const zoya = this.enemies[0];
    if (!zoya) {
      return { nearestThreatDist: 999, isChased: false };
    }

    if (zoya.stunTimer > 0) {
      zoya.stunTimer -= dt;
    }
    if (zoya.attackCooldown > 0) {
      zoya.attackCooldown -= dt;
    }

    let nearestDist = 999;
    let isChased = false;
    this.zoyaOmenFlicker = THREE.MathUtils.damp(this.zoyaOmenFlicker, 0, 3, dt);

    // 1. DORMANT: Hidden far away so player explores corridors & solves puzzles uninterrupted
    if (zoya.state === 'dormant') {
      zoya.mesh.visible = false;
      const decayMult = this.isHiding ? 0.45 : this.isCrouching ? 0.72 : this.noiseLevel > 0.72 ? 1.35 : 1.0;
      zoya.stateTimer -= dt * decayMult;
      if (zoya.stateTimer <= 0) {
        zoya.state = 'distant_omen';
        zoya.stateTimer = 6.2;
        zoya.omenPos.copy(this.pickSpawnSpotAroundPlayer(14, 21));
        audioEngine.play3DSound(Math.random() > 0.45 ? 'breathing' : 'whisper', zoya.omenPos);
      }
    }
    // 2. DISTANT OMEN: Sound/flicker dread without physical charge yet
    else if (zoya.state === 'distant_omen') {
      zoya.mesh.visible = false;
      this.zoyaOmenFlicker = 0.85;
      zoya.stateTimer -= dt;
      if (Math.random() < 0.03) {
        audioEngine.play3DSound(Math.random() > 0.5 ? 'zoya_footstep' : 'breathing', zoya.omenPos);
      }
      if (zoya.stateTimer <= 0) {
        // 50% psychological false-alarm scare vs 50% distant silhouette sighting
        if (Math.random() < 0.46) {
          zoya.state = 'dormant';
          zoya.stateTimer = this.getDormantDuration() * 0.75;
        } else {
          zoya.state = 'distant_silhouette';
          zoya.stateTimer = 5.0;
          zoya.crawlMode = Math.random() < 0.25;
          // Appear ahead of player's approximate forward hallway view
          _forward.set(-Math.sin(this.playerYaw), 0, -Math.cos(this.playerYaw));
          const aheadDist = 14 + Math.random() * 4.5;
          zoya.pos.set(
            this.playerPos.x + _forward.x * aheadDist + (Math.random() - 0.5) * 4,
            this.playerPos.y,
            this.playerPos.z + _forward.z * aheadDist + (Math.random() - 0.5) * 4
          );
          if (this.level) {
            zoya.pos.x = THREE.MathUtils.clamp(zoya.pos.x, this.level.bounds.minX + 1.5, this.level.bounds.maxX - 1.5);
            zoya.pos.z = THREE.MathUtils.clamp(zoya.pos.z, this.level.bounds.minZ + 1.5, this.level.bounds.maxZ - 1.5);
            this.resolveCollisions(zoya.pos, 0.5);
            zoya.pos.y = this.getGroundHeight(zoya.pos.x, zoya.pos.z);
          }
          zoya.mesh.position.copy(zoya.pos);
          zoya.mesh.visible = true;
          zoya.fadeAlpha = 0.88;
        }
      }
    }
    // 3. DISTANT SILHOUETTE: Eerie distant sighting; stares/twitches then vanishes OR stalks if noisy
    else if (zoya.state === 'distant_silhouette') {
      const dist = zoya.pos.distanceTo(this.playerPos);
      nearestDist = dist;
      this.zoyaOmenFlicker = 0.65;
      zoya.stateTimer -= dt;

      // Face player eerily
      zoya.yaw = Math.atan2(this.playerPos.x - zoya.pos.x, this.playerPos.z - zoya.pos.z);
      zoya.mesh.rotation.y = zoya.yaw;

      const playerLookingDirect = (() => {
        if (!this.flashlightOn) return false;
        _vec3A.subVectors(zoya.pos, this.camera.position).normalize();
        this.camera.getWorldDirection(_vec3B);
        return _vec3A.dot(_vec3B) > 0.92;
      })();

      if (dist < 8.5 || (playerLookingDirect && zoya.stateTimer < 3.4) || zoya.stateTimer <= 0) {
        if (this.noiseLevel > 0.65 && !this.isHiding && Math.random() < 0.48) {
          zoya.state = 'stalk';
          zoya.stateTimer = 9.5;
          zoya.crawlMode = Math.random() < 0.5;
          audioEngine.play3DSound('whisper', zoya.pos);
        } else {
          // Vanish back into mist (classic horror dread scare)
          zoya.state = 'vanishing';
          zoya.stateTimer = 1.1;
          audioEngine.play3DSound('breathing', zoya.pos);
        }
      }
    }
    // 4. STALK: Slow creepy approach / 4-limb crawl through shadows; respects hiding & stealth
    else if (zoya.state === 'stalk') {
      const dist = zoya.pos.distanceTo(this.playerPos);
      nearestDist = dist;
      this.zoyaOmenFlicker = dist < 11 ? 0.55 : 0.25;
      zoya.stateTimer -= dt * (this.isHiding ? 2.2 : 1.0);

      if (zoya.stunTimer <= 0) {
        const stalkSpd = zoya.crawlMode ? zoya.speedPatrol * 0.95 : zoya.speedPatrol * 0.78;
        this.steerAgentToward(zoya, this.playerPos, stalkSpd, dt);
      }

      const detectDist = this.flashlightOn ? 8.0 : 5.2;
      if (this.isHiding || (this.isCrouching && this.noiseLevel < 0.2 && dist > 6.5)) {
        if (zoya.stateTimer <= 0) {
          zoya.state = 'vanishing';
          zoya.stateTimer = 1.2;
        }
      } else if (dist < detectDist || (this.noiseLevel > 0.75 && dist < 12.5)) {
        zoya.state = 'chase';
        zoya.stateTimer = 10.5;
        zoya.crawlMode = Math.random() < 0.55;
        audioEngine.triggerSuddenSilence(0.35);
        audioEngine.play3DSound('whisper', zoya.pos, 1.15);
      } else if (zoya.stateTimer <= 0) {
        zoya.state = 'vanishing';
        zoya.stateTimer = 1.2;
      }
    }
    // 5. CHASE: Frightening timed pursuit (max ~10.5s), switches to rapid floor crawl when close
    else if (zoya.state === 'chase') {
      isChased = true;
      const dist = zoya.pos.distanceTo(this.playerPos);
      nearestDist = dist;
      this.zoyaOmenFlicker = 0.9;
      zoya.stateTimer -= dt * (this.isHiding ? 3.0 : 1.0);

      // Dynamic lunge: drops into fast unnatural 4-limb crawl within close range
      if (dist < 5.5) zoya.crawlMode = true;

      if (zoya.stunTimer <= 0 && !this.isHiding) {
        const spd = zoya.crawlMode ? zoya.speedChase * 1.08 : zoya.speedChase;
        this.steerAgentToward(zoya, this.playerPos, spd, dt);
      }

      if (!this.isHiding && dist < 1.55 && zoya.attackCooldown <= 0) {
        zoya.state = 'attack';
        this.damagePlayer(zoya);
        // Immediately vanish after landing an attack so player is never trapped in repeated hits!
        zoya.state = 'vanishing';
        zoya.stateTimer = 1.4;
      } else if (zoya.stateTimer <= 0 || this.isHiding && zoya.stateTimer <= 2.5) {
        zoya.state = 'vanishing';
        zoya.stateTimer = 1.25;
      }
    }
    // 6. VANISHING: Fades away into darkness & locks into long DORMANT cooldown
    else if (zoya.state === 'vanishing') {
      zoya.stateTimer -= dt;
      zoya.fadeAlpha = Math.max(0, zoya.stateTimer / 1.25);
      if (zoya.stateTimer <= 0) {
        zoya.mesh.visible = false;
        zoya.fadeAlpha = 0;
        zoya.crawlMode = false;
        zoya.crawlBlend = 0;
        zoya.state = 'dormant';
        zoya.stateTimer = this.getDormantDuration();
      }
    }

    // Animate Zoya kinematics & spatial footsteps/scrapes when visible
    if (zoya.mesh.visible) {
      this.animateZoya(zoya, dt);
    }

    const prox = nearestDist < 16 ? 1 - nearestDist / 16 : 0;
    audioEngine.playHeartbeat(prox);

    // Report chapter seal/anchor tether progress ONLY after player starts purifying seals
    const bossId =
      this.progress.chapter === 1
        ? 'boss_matriarch'
        : this.progress.chapter === 2
        ? 'boss_caretaker'
        : this.progress.defeatedBossIds.includes('boss_dimension')
        ? 'boss_secret_sovereign'
        : 'boss_dimension';
    const showTetherBar =
      zoya.tetherEngaged && !this.progress.defeatedBossIds.includes(bossId);

    const isSecret = bossId === 'boss_secret_sovereign';
    return {
      nearestThreatDist: nearestDist,
      isChased,
      bossNameEn: showTetherBar
        ? isSecret
          ? 'Zoya — Secret Rift Tether'
          : 'Zoya — Chapter Manifestation'
        : undefined,
      bossNameUr: showTetherBar
        ? isSecret
          ? 'زویا — خفیہ خلائی بندھن'
          : 'زویا — باب کا سایہ'
        : undefined,
      bossHealth: showTetherBar ? (isSecret ? zoya.secretTetherHp : zoya.chapterTetherHp) : undefined,
      bossMaxHealth: showTetherBar ? (isSecret ? zoya.secretTetherMax : zoya.chapterTetherMax) : undefined,
    };
  }

  private animateZoya(zoya: EnemyAgent, dt: number) {
    const t = this.elapsed;
    const isMoving = zoya.state === 'stalk' || zoya.state === 'chase';
    const targetCrawl = zoya.crawlMode ? 1 : 0;
    zoya.crawlBlend = THREE.MathUtils.damp(zoya.crawlBlend, targetCrawl, 6.5, dt);

    const rig = zoya.rig;
    const c = zoya.crawlBlend;

    // Smooth blend between unsettling stiff upright walk and terrifying horizontal 4-limb floor crawl
    rig.bodyPivot.position.y = THREE.MathUtils.lerp(0.88 + Math.sin(t * 2.8) * 0.04, 0.25, c);
    rig.bodyPivot.rotation.x = THREE.MathUtils.lerp(isMoving ? 0.14 : 0.04, 1.32, c);

    // Unnatural neck snaps & distorted head tilt staring straight at the player
    const twitchPulse = Math.sin(t * 1.3) > 0.91 ? Math.sin(t * 42) * 0.34 : 0;
    rig.head.rotation.z = Math.sin(t * 2.1) * 0.22 + twitchPulse;
    rig.head.rotation.x = THREE.MathUtils.lerp(0.05, -1.16, c);

    // Gait cycles
    const speedRate = zoya.state === 'chase' ? 12.5 : 6.0;
    const swing = isMoving ? Math.sin(t * speedRate) : 0;
    if (c > 0.45) {
      // Crawling forward claw-reaches
      rig.leftArm.rotation.x = -1.35 + swing * 0.65;
      rig.rightArm.rotation.x = -1.35 - swing * 0.65;
      rig.leftForearm.rotation.x = 0.65 + Math.max(0, swing) * 0.4;
      rig.rightForearm.rotation.x = 0.65 + Math.max(0, -swing) * 0.4;
      rig.leftLeg.rotation.x = 0.45 - swing * 0.4;
      rig.rightLeg.rotation.x = 0.45 + swing * 0.4;
    } else {
      // Unnatural crooked walk/lurch
      rig.leftArm.rotation.x = -0.52 + swing * 0.38;
      rig.rightArm.rotation.x = -0.52 - swing * 0.38;
      rig.leftForearm.rotation.x = -0.35;
      rig.rightForearm.rotation.x = -0.35;
      rig.leftLeg.rotation.x = -swing * 0.45;
      rig.rightLeg.rotation.x = swing * 0.45;
    }

    rig.veil.rotation.x = 0.16 + Math.sin(t * 4.4) * 0.09;
    const baseOpacity = zoya.state === 'vanishing' ? zoya.fadeAlpha * 0.72 : 0.72;
    rig.shroudMat.opacity = baseOpacity;
    rig.shroudMat.emissiveIntensity = zoya.state === 'chase' ? 0.72 : 0.32;

    if (isMoving) {
      zoya.stepAudioAccum += dt;
      const stepPeriod = zoya.state === 'chase' ? (c > 0.5 ? 0.22 : 0.32) : 0.52;
      if (zoya.stepAudioAccum >= stepPeriod) {
        zoya.stepAudioAccum = 0;
        audioEngine.play3DSound(c > 0.5 ? 'crawl_scrape' : 'zoya_footstep', zoya.pos);
      }
    }
  }

  private steerAgentToward(agent: EnemyAgent, target: THREE.Vector3, speed: number, dt: number) {
    _vec3A.subVectors(target, agent.pos);
    _vec3A.y = 0;
    const len = _vec3A.length();
    if (len > 0.05) {
      _vec3A.divideScalar(len);
      agent.pos.x += _vec3A.x * speed * dt;
      agent.pos.z += _vec3A.z * speed * dt;
      this.resolveCollisions(agent.pos, 0.4);
      agent.yaw = Math.atan2(_vec3A.x, _vec3A.z);
    }
    agent.pos.y = this.getGroundHeight(agent.pos.x, agent.pos.z);
    agent.mesh.position.set(agent.pos.x, agent.pos.y, agent.pos.z);
    agent.mesh.rotation.y = agent.yaw;
  }

  private damagePlayer(attacker: EnemyAgent) {
    attacker.attackCooldown = 3.0;
    const dmg =
      this.settings.difficulty === 'nightmare' ? 40 : this.settings.difficulty === 'hard' ? 30 : 22;
    this.progress.health = Math.max(0, this.progress.health - dmg);
    this.cameraShake = 0.95;
    audioEngine.playSfx('hit');
    audioEngine.play3DSound('scream', attacker.pos);
    this.emitHudState({ nearestThreatDist: 1, isChased: true }, true);

    if (this.progress.health <= 0) {
      this.setMode('paused');
      this.callbacks.onGameOver();
    }
  }

  private updateAliCompanion(dt: number, isDanger: boolean) {
    if (!this.aliRig || !this.progress.aliRescued) return;
    const dist = this.aliPos.distanceTo(this.playerPos);

    if (isDanger) {
      this.aliRig.group.scale.y = 0.72;
      this.progress.aliFollowing = false;
    } else {
      this.aliRig.group.scale.y = 1.0;
      this.progress.aliFollowing = true;
      if (dist > 2.4) {
        _vec3A.subVectors(this.playerPos, this.aliPos);
        _vec3A.y = 0;
        _vec3A.normalize();
        const spd = dist > 8 ? 5.2 : 3.2;
        this.aliPos.x += _vec3A.x * spd * dt;
        this.aliPos.z += _vec3A.z * spd * dt;
        this.resolveCollisions(this.aliPos, 0.35);
        this.aliYaw = Math.atan2(_vec3A.x, _vec3A.z);
        const swing = Math.sin(this.elapsed * 8) * 0.45;
        this.aliRig.leftLeg.rotation.x = swing;
        this.aliRig.rightLeg.rotation.x = -swing;
      } else {
        this.aliRig.leftLeg.rotation.x = 0;
        this.aliRig.rightLeg.rotation.x = 0;
      }
    }

    this.aliPos.y = this.getGroundHeight(this.aliPos.x, this.aliPos.z);
    this.aliRig.group.position.copy(this.aliPos);
    this.aliRig.group.rotation.y = this.aliYaw;

    this.aliDialogueTimer -= dt;
    if (this.aliDialogueTimer <= 0) {
      this.aliDialogueTimer = 26;
      if (this.progress.chapter === 2) {
        this.callbacks.onShowSubtitle(
          'Ali Ahmed',
          'علی احمد',
          'Wait... why do I recognize the inscriptions on these tombstones? Look toward the eastern steps—there is an underground morgue.',
          'رکو... مجھے ان قبروں کے کتبے جانے پہچانے کیوں لگ رہے ہیں؟ مشرقی سیڑھیوں کے نیچے سردخانہ بھی ہے۔',
          4.4
        );
      } else if (this.progress.chapter === 3) {
        this.callbacks.onShowSubtitle(
          'Ali Ahmed',
          'علی احمد',
          'Look at the hospital remnants shifting behind us. My memory built this dimension—forgive me.',
          'ہمارے پیچھے ہسپتال کے بدلتے ٹکڑوں کو دیکھو۔ میری یادوں نے ہی یہ جہان بنایا ہے—مجھے معاف کر دینا۔',
          4.4
        );
      }
    }
  }

  private updateRoomDiscovery() {
    for (let i = 0; i < MAP_ROOMS.length; i++) {
      const room = MAP_ROOMS[i];
      if (room.chapter !== this.progress.chapter) continue;
      const inX = Math.abs(this.playerPos.x - room.x) <= room.w / 2;
      const inZ = Math.abs(this.playerPos.z - room.z) <= room.d / 2;
      if (inX && inZ && !this.progress.discoveredRoomIds.includes(room.id)) {
        this.progress.discoveredRoomIds.push(room.id);
        this.callbacks.onProgressMutated();
      }
    }
  }

  private emitHudState(
    threat: {
      nearestThreatDist: number;
      isChased: boolean;
      bossNameEn?: string;
      bossNameUr?: string;
      bossHealth?: number;
      bossMaxHealth?: number;
    },
    force = false
  ) {
    const nearest = this.findNearestInteractable();
    let objEn = '';
    let objUr = '';
    if (this.progress.chapter === 1) {
      if (!this.progress.aliRescued) {
        objEn = `Investigate the Hospital Wings & Nine Doors to rescue Ali Ahmed (Bottles: ${this.progress.collectedBottleIds.length}/9)`;
        objUr = `ہسپتال کے حصوں اور نو دروازوں کی تحقیق کریں اور علی احمد کو بچائیں (بوتلیں: ${this.progress.collectedBottleIds.length}/9)`;
      } else {
        objEn = 'Purify the 3 Ward Seals & enter the Portal inside Door IX';
        objUr = 'تین مقدس مہریں روشن کریں اور نویں دروازے کے پورٹل میں داخل ہوں';
      }
    } else if (this.progress.chapter === 2) {
      if (!this.progress.defeatedBossIds.includes('boss_caretaker')) {
        objEn = 'Search the Underground Morgue, align the Statues & ignite 3 Ward Braziers';
        objUr = 'سردخانے کی تلاشی لیں، مجسمے درست کریں اور 3 مشعلیں روشن کریں';
      } else {
        objEn = 'Step into the Mausoleum Portal to enter The Secret Dimension';
        objUr = 'خفیہ جہان میں داخل ہونے کے لیے مقبرے کے پورٹل میں جائیں';
      }
    } else {
      if (!this.progress.defeatedBossIds.includes('boss_dimension')) {
        objEn = 'Stabilize the 3 Reality Anchors & reach the Final Threshold';
        objUr = 'تین حقیقت کے ستون بحال کریں اور آخری دروازے تک پہنچیں';
      } else {
        objEn = 'Reach the Final Threshold (or unlock the Hidden Rift Sanctum for the Secret Ending)';
        objUr = 'آخری حقیقت کے دروازے تک پہنچیں (یا خفیہ انجام کے لیے خفیہ مقام کھولیں)';
      }
    }

    const currentRoom =
      MAP_ROOMS.find(
        (r) =>
          r.chapter === this.progress.chapter &&
          Math.abs(this.playerPos.x - r.x) <= r.w / 2 &&
          Math.abs(this.playerPos.z - r.z) <= r.d / 2
      )?.id || '';

    const health = Math.round(this.progress.health);
    const stamina = Math.round(this.progress.stamina);
    const battery = Math.round(this.progress.battery);
    const dangerBucket = Math.min(14, Math.round(threat.nearestThreatDist));
    const sig = `${health}|${stamina}|${battery}|${this.flashlightOn}|${this.isCrouching}|${this.isHiding}|${
      nearest?.id || ''
    }|${currentRoom}|${threat.isChased}|${dangerBucket}|${threat.bossHealth ?? ''}|${this.progress.aliRescued}|${
      this.progress.aliFollowing
    }|${objEn}`;

    if (!force && sig === this.lastHudSignature) return;
    this.lastHudSignature = sig;

    this.callbacks.onHudUpdate({
      health,
      maxHealth: 100,
      stamina,
      battery,
      flashlightOn: this.flashlightOn,
      isCrouching: this.isCrouching,
      isHiding: this.isHiding,
      noiseLevel: this.noiseLevel,
      chapter: this.progress.chapter,
      objectiveEn: objEn,
      objectiveUr: objUr,
      interactPromptEn: this.isHiding ? 'Leave Cover' : nearest ? nearest.labelEn : null,
      interactPromptUr: this.isHiding ? 'باہر نکلیں' : nearest ? nearest.labelUr : null,
      interactTargetId: nearest?.id || null,
      interactActionType: this.isHiding ? 'hide' : nearest?.type || null,
      aliRescued: this.progress.aliRescued,
      aliFollowing: this.progress.aliFollowing,
      aliSuspicion: this.progress.truthCluesFound,
      playerPos: { x: this.playerPos.x, y: this.playerPos.y, z: this.playerPos.z, yaw: this.playerYaw },
      currentRoomId: currentRoom,
      enemyStatus: threat,
    });
  }

  private unlockAudioOnce = () => {
    audioEngine.init();
  };

  private bindEvents() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.clearHeldInputs);
    window.addEventListener('pointerdown', this.unlockAudioOnce, { passive: true });

    const el = this.renderer.domElement;
    el.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
  }

  private clearHeldInputs = () => {
    this.keys = {};
    this.touchMove = { x: 0, y: 0 };
    this.touchSprint = false;
    this.isPointerDown = false;
  };

  private onKeyDown = (e: KeyboardEvent) => {
    this.keys[e.code] = true;
    if (this.activeMode !== 'playing') return;
    if (e.code === 'KeyF') this.toggleFlashlight();
    if (e.code === 'KeyC') this.toggleCrouch();
    if (e.code === 'KeyE') this.handlePrimaryInteract();
    if (e.code === 'Space') this.triggerJump();
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  private onPointerDown = (e: PointerEvent) => {
    if (this.activeMode !== 'playing') return;
    audioEngine.init();
    this.isPointerDown = true;
    this.lastPointer = { x: e.clientX, y: e.clientY };
  };

  private onPointerMove = (e: PointerEvent) => {
    if (!this.isPointerDown || this.activeMode !== 'playing') return;
    const dx = e.clientX - this.lastPointer.x;
    const dy = e.clientY - this.lastPointer.y;
    this.lastPointer = { x: e.clientX, y: e.clientY };
    this.addLookDelta(dx, dy);
  };

  private onPointerUp = () => {
    this.isPointerDown = false;
  };

  private handleResize() {
    const w = Math.max(1, this.container.clientWidth || window.innerWidth || 640);
    const h = Math.max(1, this.container.clientHeight || window.innerHeight || 360);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  public dispose() {
    this.running = false;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.resizeObserver.disconnect();
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.clearHeldInputs);
    window.removeEventListener('pointerdown', this.unlockAudioOnce);
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    if (this.level) {
      this.level.dispose();
      this.level = null;
    }
    if (this.titleGroup) {
      disposeObjectTree(this.titleGroup);
      this.titleGroup = null;
    }
    this.enemies.forEach((e) => disposeObjectTree(e.mesh));
    if (this.aliRig) disposeObjectTree(this.aliRig.group);
    disposeObjectTree(this.playerRig.group);
    if (this.dustPoints) {
      this.dustPoints.geometry.dispose();
      (this.dustPoints.material as THREE.Material).dispose();
    }
    this.volumetricCone.geometry.dispose();
    (this.volumetricCone.material as THREE.Material).dispose();
    this.shockwaveRing.geometry.dispose();
    (this.shockwaveRing.material as THREE.Material).dispose();
    disposeCachedTextures();
    this.pmremEnv?.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
