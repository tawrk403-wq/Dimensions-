import * as THREE from 'three';

const textureCache = new Map<string, THREE.CanvasTexture>();

export interface PBRTextureSet {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
  emissiveMap?: THREE.CanvasTexture;
}

function createRng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function createCanvas(size = 512): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

function finalizeTexture(
  key: string,
  canvas: HTMLCanvasElement,
  repeatX = 2,
  repeatY = 2,
  anisotropy = 2,
  isColor = true
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.colorSpace = isColor ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  tex.anisotropy = Math.max(1, Math.min(4, anisotropy));
  tex.generateMipmaps = true;
  tex.needsUpdate = true;
  textureCache.set(key, tex);
  return tex;
}

function resolveTexSize(anisotropy: number, baseSize = 512): number {
  return anisotropy <= 1 ? Math.min(256, baseSize) : baseSize;
}

export function getWoodPBRTextures(anisotropy = 2, darkTone = false): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `wood_pbr_${darkTone ? 'dark' : 'aged'}_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  if (cachedMap && cachedBump && cachedRough) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough };
  }

  const size = resolveTexSize(anisoBucket, 512);
  const scale = size / 256;
  const rng = createRng(darkTone ? 101 : 202);
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);

  ctxMap.fillStyle = darkTone ? '#1a130e' : '#2e2118';
  ctxMap.fillRect(0, 0, size, size);
  ctxBump.fillStyle = '#8a8a8a';
  ctxBump.fillRect(0, 0, size, size);
  ctxRough.fillStyle = '#b8b8b8';
  ctxRough.fillRect(0, 0, size, size);

  const plankH = Math.round(32 * scale);
  for (let y = 0; y < size; y += plankH) {
    const shade = (rng() - 0.5) * 16;
    const baseR = (darkTone ? 34 : 56) + shade;
    const baseG = (darkTone ? 24 : 40) + shade * 0.7;
    const baseB = (darkTone ? 17 : 28) + shade * 0.5;
    ctxMap.fillStyle = `rgb(${baseR | 0},${baseG | 0},${baseB | 0})`;
    ctxMap.fillRect(0, y + 1, size, plankH - 2);

    const plankElev = Math.round(135 + (rng() - 0.5) * 35);
    ctxBump.fillStyle = `rgb(${plankElev},${plankElev},${plankElev})`;
    ctxBump.fillRect(0, y + 2, size, plankH - 4);

    const plankRough = Math.round(150 + (rng() - 0.5) * 45);
    ctxRough.fillStyle = `rgb(${plankRough},${plankRough},${plankRough})`;
    ctxRough.fillRect(0, y + 1, size, plankH - 2);

    ctxMap.fillStyle = 'rgba(0,0,0,0.2)';
    ctxBump.fillStyle = 'rgba(70,70,70,0.35)';
    ctxRough.fillStyle = 'rgba(210,210,210,0.28)';
    for (let g = 0; g < 18; g++) {
      const gy = y + 3 + rng() * (plankH - 6);
      ctxMap.fillRect(0, gy, size, 1);
      ctxBump.fillRect(0, gy, size, 1);
      ctxRough.fillRect(0, gy, size, 1);
    }

    ctxMap.fillStyle = '#090705';
    ctxMap.fillRect(0, y, size, Math.max(2, Math.round(2 * scale)));
    ctxBump.fillStyle = '#181818';
    ctxBump.fillRect(0, y, size, Math.max(2, Math.round(2 * scale)));
    ctxRough.fillStyle = '#ececec';
    ctxRough.fillRect(0, y, size, Math.max(2, Math.round(2 * scale)));

    const seamX = ((y * 3) % (size - 48)) + 24;
    ctxMap.fillRect(seamX, y, 2, plankH);
    ctxBump.fillRect(seamX, y, 2, plankH);

    ctxMap.fillStyle = '#202228';
    ctxMap.fillRect(seamX - 8, y + 8, 4, 4);
    ctxMap.fillRect(seamX + 8, y + plankH - 12, 4, 4);
    ctxBump.fillStyle = '#f2f2f2';
    ctxBump.fillRect(seamX - 8, y + 8, 4, 4);
    ctxBump.fillRect(seamX + 8, y + plankH - 12, 4, 4);
  }

  for (let s = 0; s < 14; s++) {
    const rx = rng() * size;
    const ry = rng() * size;
    const rad = (14 + rng() * 24) * scale;
    const grad = ctxMap.createRadialGradient(rx, ry, 2, rx, ry, rad);
    grad.addColorStop(0, 'rgba(8,12,10,0.42)');
    grad.addColorStop(1, 'rgba(8,12,10,0)');
    ctxMap.fillStyle = grad;
    ctxMap.fillRect(rx - rad, ry - rad, rad * 2, rad * 2);

    const rGrad = ctxRough.createRadialGradient(rx, ry, 2, rx, ry, rad);
    rGrad.addColorStop(0, 'rgba(55,55,55,0.48)');
    rGrad.addColorStop(1, 'rgba(55,55,55,0)');
    ctxRough.fillStyle = rGrad;
    ctxRough.fillRect(rx - rad, ry - rad, rad * 2, rad * 2);
  }

  return {
    map: finalizeTexture(`${key}_map`, cMap, 3, 3, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 3, 3, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 3, 3, anisoBucket, false),
  };
}

export function getWallPBRTextures(anisotropy = 2, tint = '#27242a'): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `wall_pbr_${tint}_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  if (cachedMap && cachedBump && cachedRough) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough };
  }

  const size = resolveTexSize(anisoBucket, 512);
  const scale = size / 256;
  const rng = createRng(303);
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);

  ctxMap.fillStyle = tint;
  ctxMap.fillRect(0, 0, size, size);
  ctxBump.fillStyle = '#909090';
  ctxBump.fillRect(0, 0, size, size);
  ctxRough.fillStyle = '#cfcfcf';
  ctxRough.fillRect(0, 0, size, size);

  for (let x = 0; x < size; x += Math.round(24 * scale)) {
    ctxMap.fillStyle = 'rgba(0,0,0,0.18)';
    ctxMap.fillRect(x, 0, Math.round(8 * scale), size);
    ctxMap.fillStyle = 'rgba(255,255,255,0.035)';
    ctxMap.fillRect(x + Math.round(10 * scale), 0, Math.round(2 * scale), size);
    ctxBump.fillStyle = '#a8a8a8';
    ctxBump.fillRect(x + Math.round(9 * scale), 0, Math.round(4 * scale), size);
  }

  ctxMap.strokeStyle = 'rgba(10,8,12,0.62)';
  ctxMap.lineWidth = 1.6 * scale;
  ctxBump.strokeStyle = '#202020';
  ctxBump.lineWidth = 2.0 * scale;
  for (let c = 0; c < 12; c++) {
    let cx = rng() * size;
    let cy = rng() * size;
    ctxMap.beginPath();
    ctxMap.moveTo(cx, cy);
    ctxBump.beginPath();
    ctxBump.moveTo(cx, cy);
    for (let seg = 0; seg < 6; seg++) {
      cx += (rng() - 0.5) * 34 * scale;
      cy += rng() * 28 * scale;
      ctxMap.lineTo(cx, cy);
      ctxBump.lineTo(cx, cy);
    }
    ctxMap.stroke();
    ctxBump.stroke();
  }

  const wainscotH = Math.round(48 * scale);
  ctxMap.fillStyle = '#191310';
  ctxMap.fillRect(0, size - wainscotH, size, wainscotH);
  ctxMap.fillStyle = '#33241d';
  ctxMap.fillRect(0, size - wainscotH - 2, size, Math.round(4 * scale));
  ctxBump.fillStyle = '#d4d4d4';
  ctxBump.fillRect(0, size - wainscotH - 2, size, Math.round(5 * scale));

  return {
    map: finalizeTexture(`${key}_map`, cMap, 2, 1, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 2, 1, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 2, 1, anisoBucket, false),
  };
}

/**
 * Abandoned Hospital Wall:
 * Cracked dirty off-white plaster upper half + institutional clinical dark-green tiled lower wainscot,
 * grime streaks, peeling paint patches, & subtle blood stains.
 */
export function getHospitalWallPBRTextures(anisotropy = 2): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `hospital_wall_pbr_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  if (cachedMap && cachedBump && cachedRough) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough };
  }

  const size = resolveTexSize(anisoBucket, 512);
  const scale = size / 512;
  const rng = createRng(709);
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);

  const splitY = Math.round(size * 0.56);

  // Dirty chalky white upper plaster
  ctxMap.fillStyle = '#7b7c74';
  ctxMap.fillRect(0, 0, size, splitY);
  ctxBump.fillStyle = '#929292';
  ctxBump.fillRect(0, 0, size, splitY);
  ctxRough.fillStyle = '#dedede';
  ctxRough.fillRect(0, 0, size, splitY);

  // Grime clouds & mold drips on plaster
  for (let i = 0; i < 42; i++) {
    const x = rng() * size;
    const y = rng() * splitY;
    const r = (18 + rng() * 44) * scale;
    const g = ctxMap.createRadialGradient(x, y, 2, x, y, r);
    g.addColorStop(0, rng() > 0.35 ? 'rgba(28,31,26,0.34)' : 'rgba(62,48,36,0.28)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctxMap.fillStyle = g;
    ctxMap.fillRect(x - r, y - r, r * 2, r * 2);

    const bVal = Math.round(90 + rng() * 75);
    ctxBump.fillStyle = `rgba(${bVal},${bVal},${bVal},0.22)`;
    ctxBump.fillRect(x - r * 0.5, y - r * 0.5, r, r);
  }

  // Institutional dark sea-green lower hospital tiles
  ctxMap.fillStyle = '#1f362e';
  ctxMap.fillRect(0, splitY, size, size - splitY);
  ctxBump.fillStyle = '#aaaaaa';
  ctxBump.fillRect(0, splitY, size, size - splitY);
  ctxRough.fillStyle = '#6e6e6e';
  ctxRough.fillRect(0, splitY, size, size - splitY);

  const tileSize = Math.round(32 * scale);
  for (let ty = splitY; ty < size; ty += tileSize) {
    for (let tx = 0; tx < size; tx += tileSize) {
      const tintShift = Math.round((rng() - 0.5) * 16);
      ctxMap.fillStyle = `rgb(${29 + tintShift},${53 + tintShift},${44 + tintShift})`;
      ctxMap.fillRect(tx + 1, ty + 1, tileSize - 2, tileSize - 2);

      // Occasional cracked or missing dark tile
      if (rng() > 0.91) {
        ctxMap.fillStyle = '#161b18';
        ctxMap.fillRect(tx + 2, ty + 2, tileSize - 4, tileSize - 4);
        ctxBump.fillStyle = '#383838';
        ctxBump.fillRect(tx + 2, ty + 2, tileSize - 4, tileSize - 4);
        ctxRough.fillStyle = '#eaeaea';
        ctxRough.fillRect(tx + 2, ty + 2, tileSize - 4, tileSize - 4);
      }

      // Tile grout seams
      ctxMap.fillStyle = '#0c120f';
      ctxMap.fillRect(tx, ty, tileSize, 2);
      ctxMap.fillRect(tx, ty, 2, tileSize);
      ctxBump.fillStyle = '#242424';
      ctxBump.fillRect(tx, ty, tileSize, 2);
      ctxBump.fillRect(tx, ty, 2, tileSize);
      ctxRough.fillStyle = '#dcdcdc';
      ctxRough.fillRect(tx, ty, tileSize, 2);
      ctxRough.fillRect(tx, ty, 2, tileSize);
    }
  }

  // Trim rail separating plaster and green tiles
  ctxMap.fillStyle = '#131d19';
  ctxMap.fillRect(0, splitY - 5, size, 10);
  ctxBump.fillStyle = '#e5e5e5';
  ctxBump.fillRect(0, splitY - 4, size, 8);

  // Vertical water/rust & dried blood drips down tile seam
  for (let d = 0; d < 14; d++) {
    const dx = rng() * size;
    const isBlood = d % 5 === 0;
    const h = (40 + rng() * 110) * scale;
    const dy = splitY - 12 + rng() * 35;
    ctxMap.fillStyle = isBlood ? 'rgba(88,10,12,0.52)' : 'rgba(18,22,18,0.45)';
    ctxMap.fillRect(dx, dy, (3 + rng() * 5) * scale, h);
  }

  // Jagged plaster fractures
  ctxMap.strokeStyle = 'rgba(15,17,15,0.68)';
  ctxMap.lineWidth = 1.8 * scale;
  ctxBump.strokeStyle = '#181818';
  ctxBump.lineWidth = 2.4 * scale;
  for (let c = 0; c < 10; c++) {
    let cx = rng() * size;
    let cy = rng() * splitY;
    ctxMap.beginPath();
    ctxMap.moveTo(cx, cy);
    ctxBump.beginPath();
    ctxBump.moveTo(cx, cy);
    for (let s = 0; s < 5; s++) {
      cx += (rng() - 0.5) * 40 * scale;
      cy += rng() * 32 * scale;
      ctxMap.lineTo(cx, cy);
      ctxBump.lineTo(cx, cy);
    }
    ctxMap.stroke();
    ctxBump.stroke();
  }

  return {
    map: finalizeTexture(`${key}_map`, cMap, 2, 1, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 2, 1, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 2, 1, anisoBucket, false),
  };
}

/**
 * Cracked Wet Ceramic Floor Tiles (Hospital Corridor / Operation Theatre / Underground Morgue)
 */
export function getHospitalTilePBRTextures(anisotropy = 2, morgueTint = false): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `hospital_tile_pbr_${morgueTint ? 'morgue' : 'hall'}_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  if (cachedMap && cachedBump && cachedRough) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough };
  }

  const size = resolveTexSize(anisoBucket, 512);
  const scale = size / 512;
  const rng = createRng(morgueTint ? 812 : 811);
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);

  const step = Math.round(64 * scale);
  for (let ty = 0; ty < size; ty += step) {
    for (let tx = 0; tx < size; tx += step) {
      const alt = ((tx / step + ty / step) | 0) % 2 === 0;
      const jitter = Math.round((rng() - 0.5) * 14);
      if (morgueTint) {
        const base = (alt ? 64 : 52) + jitter;
        ctxMap.fillStyle = `rgb(${base - 4},${base + 4},${base + 10})`;
      } else {
        const base = (alt ? 86 : 68) + jitter;
        ctxMap.fillStyle = `rgb(${base},${base + 2},${base - 6})`;
      }
      ctxMap.fillRect(tx, ty, step, step);

      const bTile = Math.round(145 + (rng() - 0.5) * 20);
      ctxBump.fillStyle = `rgb(${bTile},${bTile},${bTile})`;
      ctxBump.fillRect(tx + 2, ty + 2, step - 4, step - 4);

      // Wet vs matte ceramic roughness variation
      const rTile = Math.round(morgueTint ? 88 + rng() * 65 : 108 + rng() * 75);
      ctxRough.fillStyle = `rgb(${rTile},${rTile},${rTile})`;
      ctxRough.fillRect(tx + 2, ty + 2, step - 4, step - 4);

      // Diagonal tile hairline crack
      if (rng() > 0.58) {
        ctxMap.strokeStyle = 'rgba(10,12,12,0.72)';
        ctxMap.lineWidth = 1.6 * scale;
        ctxBump.strokeStyle = '#202020';
        ctxBump.lineWidth = 2.0 * scale;
        const sx = tx + rng() * step;
        const sy = ty + rng() * step;
        const ex = tx + rng() * step;
        const ey = ty + rng() * step;
        ctxMap.beginPath();
        ctxMap.moveTo(sx, sy);
        ctxMap.lineTo((sx + ex) * 0.5 + (rng() - 0.5) * 12, (sy + ey) * 0.5);
        ctxMap.lineTo(ex, ey);
        ctxMap.stroke();

        ctxBump.beginPath();
        ctxBump.moveTo(sx, sy);
        ctxBump.lineTo((sx + ex) * 0.5, (sy + ey) * 0.5);
        ctxBump.lineTo(ex, ey);
        ctxBump.stroke();
      }

      // Dark grime grout joints
      ctxMap.fillStyle = '#0d1010';
      ctxMap.fillRect(tx, ty, step, 3);
      ctxMap.fillRect(tx, ty, 3, step);
      ctxBump.fillStyle = '#1e1e1e';
      ctxBump.fillRect(tx, ty, step, 3);
      ctxBump.fillRect(tx, ty, 3, step);
      ctxRough.fillStyle = '#dedede';
      ctxRough.fillRect(tx, ty, step, 3);
      ctxRough.fillRect(tx, ty, 3, step);
    }
  }

  // Wet damp sheen puddles + stained grime patches
  for (let p = 0; p < 16; p++) {
    const px = rng() * size;
    const py = rng() * size;
    const rad = (24 + rng() * 48) * scale;
    const isBlood = p % 7 === 0;
    const mg = ctxMap.createRadialGradient(px, py, 3, px, py, rad);
    mg.addColorStop(0, isBlood ? 'rgba(72,8,10,0.48)' : 'rgba(10,14,15,0.42)');
    mg.addColorStop(1, 'rgba(0,0,0,0)');
    ctxMap.fillStyle = mg;
    ctxMap.fillRect(px - rad, py - rad, rad * 2, rad * 2);

    // Glossy puddle roughness
    const rg = ctxRough.createRadialGradient(px, py, 3, px, py, rad);
    rg.addColorStop(0, 'rgba(26,26,26,0.75)');
    rg.addColorStop(1, 'rgba(26,26,26,0)');
    ctxRough.fillStyle = rg;
    ctxRough.fillRect(px - rad, py - rad, rad * 2, rad * 2);
  }

  return {
    map: finalizeTexture(`${key}_map`, cMap, 8, 8, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 8, 8, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 8, 8, anisoBucket, false),
  };
}

/**
 * Damp Subterranean Basement Concrete + Rusted Streaks
 */
export function getBasementConcretePBRTextures(anisotropy = 2): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `basement_concrete_pbr_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  if (cachedMap && cachedBump && cachedRough) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough };
  }

  const size = resolveTexSize(anisoBucket, 512);
  const scale = size / 512;
  const rng = createRng(905);
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);

  ctxMap.fillStyle = '#24272a';
  ctxMap.fillRect(0, 0, size, size);
  ctxBump.fillStyle = '#848484';
  ctxBump.fillRect(0, 0, size, size);
  ctxRough.fillStyle = '#bdbdbd';
  ctxRough.fillRect(0, 0, size, size);

  for (let i = 0; i < 650; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const s = (2 + rng() * 8) * scale;
    const v = Math.round(28 + rng() * 24);
    ctxMap.fillStyle = `rgba(${v},${v + 2},${v + 3},0.35)`;
    ctxMap.fillRect(x, y, s, s);
    const bv = Math.round(70 + rng() * 115);
    ctxBump.fillStyle = `rgb(${bv},${bv},${bv})`;
    ctxBump.fillRect(x, y, s, s);
  }

  // Water leaks & rust drip streaks
  for (let s = 0; s < 18; s++) {
    const sx = rng() * size;
    const rust = s % 3 === 0;
    ctxMap.fillStyle = rust ? 'rgba(92,38,16,0.42)' : 'rgba(10,13,16,0.5)';
    ctxMap.fillRect(sx, 0, (4 + rng() * 10) * scale, (140 + rng() * 340) * scale);
    ctxRough.fillStyle = 'rgba(42,42,42,0.55)';
    ctxRough.fillRect(sx, 0, (4 + rng() * 10) * scale, (140 + rng() * 340) * scale);
  }

  return {
    map: finalizeTexture(`${key}_map`, cMap, 3, 2, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 3, 2, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 3, 2, anisoBucket, false),
  };
}

/**
 * Cold Brushed Morgue Stainless Steel
 */
export function getStainlessSteelPBRTextures(anisotropy = 2): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `morgue_steel_pbr_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  if (cachedMap && cachedBump && cachedRough) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough };
  }

  const size = resolveTexSize(anisoBucket, 256);
  const rng = createRng(991);
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);

  ctxMap.fillStyle = '#737b84';
  ctxMap.fillRect(0, 0, size, size);
  ctxBump.fillStyle = '#808080';
  ctxBump.fillRect(0, 0, size, size);
  ctxRough.fillStyle = '#555555';
  ctxRough.fillRect(0, 0, size, size);

  for (let y = 0; y < size; y += 2) {
    const lum = Math.round(98 + rng() * 34);
    ctxMap.fillStyle = `rgb(${lum},${lum + 4},${lum + 9})`;
    ctxMap.fillRect(0, y, size, 1);
    const rv = Math.round(62 + rng() * 48);
    ctxRough.fillStyle = `rgb(${rv},${rv},${rv})`;
    ctxRough.fillRect(0, y, size, 1);
  }

  // Smudge / frost spots
  for (let i = 0; i < 8; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const r = 16 + rng() * 28;
    const g = ctxRough.createRadialGradient(x, y, 2, x, y, r);
    g.addColorStop(0, 'rgba(180,180,180,0.45)');
    g.addColorStop(1, 'rgba(180,180,180,0)');
    ctxRough.fillStyle = g;
    ctxRough.fillRect(x - r, y - r, r * 2, r * 2);
  }

  return {
    map: finalizeTexture(`${key}_map`, cMap, 1, 1, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 1, 1, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 1, 1, anisoBucket, false),
  };
}

/**
 * Fractured CRT Vital Monitor Screen (Operation Theatre)
 */
export function getCRTMonitorTexture(): THREE.CanvasTexture {
  const key = 'crt_vital_screen';
  if (textureCache.has(key)) return textureCache.get(key)!;
  const [c, ctx] = createCanvas(256);
  const rng = createRng(411);

  ctx.fillStyle = '#03130f';
  ctx.fillRect(0, 0, 256, 256);

  // Subtle scanlines & noise
  for (let y = 0; y < 256; y += 4) {
    ctx.fillStyle = `rgba(16,185,129,${0.05 + rng() * 0.12})`;
    ctx.fillRect(0, y, 256, 2);
  }

  // Flatline & erratic spike ECG waveform
  ctx.strokeStyle = '#34d399';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, 148);
  ctx.lineTo(68, 148);
  ctx.lineTo(82, 84);
  ctx.lineTo(94, 198);
  ctx.lineTo(108, 148);
  ctx.lineTo(256, 148);
  ctx.stroke();

  // Glass crack
  ctx.strokeStyle = 'rgba(220,252,231,0.55)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(190, 24);
  ctx.lineTo(148, 108);
  ctx.lineTo(170, 175);
  ctx.lineTo(122, 232);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  textureCache.set(key, tex);
  return tex;
}

/**
 * Alpha-blended realistic blood smear & splatter decal
 */
export function getBloodDecalTexture(): THREE.CanvasTexture {
  const key = 'blood_decal_alpha';
  if (textureCache.has(key)) return textureCache.get(key)!;
  const [c, ctx] = createCanvas(256);
  const rng = createRng(666);

  ctx.clearRect(0, 0, 256, 256);
  for (let i = 0; i < 16; i++) {
    const x = 60 + rng() * 136;
    const y = 60 + rng() * 136;
    const r = 12 + rng() * 44;
    const g = ctx.createRadialGradient(x, y, 2, x, y, r);
    g.addColorStop(0, 'rgba(72,4,8,0.88)');
    g.addColorStop(0.55, 'rgba(110,10,14,0.55)');
    g.addColorStop(1, 'rgba(60,4,6,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  // Drag streaks
  ctx.strokeStyle = 'rgba(85,8,12,0.52)';
  for (let s = 0; s < 5; s++) {
    ctx.lineWidth = 3 + rng() * 5;
    ctx.beginPath();
    ctx.moveTo(40 + rng() * 60, 70 + s * 24);
    ctx.lineTo(180 + rng() * 55, 84 + s * 22);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  textureCache.set(key, tex);
  return tex;
}

/**
 * Pale Damaged Ghost Flesh & Dark Veins for Zoya
 */
export function getGhostSkinPBRTextures(): { map: THREE.CanvasTexture; bumpMap: THREE.CanvasTexture } {
  const key = 'zoya_skin_pbr';
  const cm = textureCache.get(`${key}_map`);
  const cb = textureCache.get(`${key}_bump`);
  if (cm && cb) return { map: cm, bumpMap: cb };

  const rng = createRng(1994);
  const [cMap, ctxMap] = createCanvas(256);
  const [cBump, ctxBump] = createCanvas(256);

  ctxMap.fillStyle = '#b9c0c8';
  ctxMap.fillRect(0, 0, 256, 256);
  ctxBump.fillStyle = '#888888';
  ctxBump.fillRect(0, 0, 256, 256);

  // Dark necrotic veins & bruises
  for (let v = 0; v < 26; v++) {
    let x = rng() * 256;
    let y = rng() * 256;
    ctxMap.strokeStyle = v % 3 === 0 ? 'rgba(65,12,18,0.45)' : 'rgba(38,44,58,0.42)';
    ctxMap.lineWidth = 1 + rng() * 1.4;
    ctxBump.strokeStyle = '#606060';
    ctxBump.lineWidth = 1.2;
    ctxMap.beginPath();
    ctxMap.moveTo(x, y);
    ctxBump.beginPath();
    ctxBump.moveTo(x, y);
    for (let s = 0; s < 5; s++) {
      x += (rng() - 0.5) * 26;
      y += (rng() - 0.5) * 26;
      ctxMap.lineTo(x, y);
      ctxBump.lineTo(x, y);
    }
    ctxMap.stroke();
    ctxBump.stroke();
  }

  const map = finalizeTexture(`${key}_map`, cMap, 1, 1, 2, true);
  const bumpMap = finalizeTexture(`${key}_bump`, cBump, 1, 1, 2, false);
  return { map, bumpMap };
}

/**
 * Weathered Blood-Stained Burial Gown Fabric for Zoya
 */
export function getGhostGownPBRTextures(): { map: THREE.CanvasTexture; bumpMap: THREE.CanvasTexture } {
  const key = 'zoya_gown_pbr';
  const cm = textureCache.get(`${key}_map`);
  const cb = textureCache.get(`${key}_bump`);
  if (cm && cb) return { map: cm, bumpMap: cb };

  const rng = createRng(1989);
  const [cMap, ctxMap] = createCanvas(256);
  const [cBump, ctxBump] = createCanvas(256);

  ctxMap.fillStyle = '#18181f';
  ctxMap.fillRect(0, 0, 256, 256);
  ctxBump.fillStyle = '#808080';
  ctxBump.fillRect(0, 0, 256, 256);

  for (let y = 0; y < 256; y += 3) {
    const v = Math.round(18 + rng() * 18);
    ctxMap.fillStyle = `rgb(${v},${v},${v + 5})`;
    ctxMap.fillRect(0, y, 256, 1);
  }
  // Soaked dirt & dried crimson hem stains
  const hemGrad = ctxMap.createLinearGradient(0, 140, 0, 256);
  hemGrad.addColorStop(0, 'rgba(60,8,12,0)');
  hemGrad.addColorStop(1, 'rgba(55,6,10,0.72)');
  ctxMap.fillStyle = hemGrad;
  ctxMap.fillRect(0, 140, 256, 116);

  const map = finalizeTexture(`${key}_map`, cMap, 2, 1, 2, true);
  const bumpMap = finalizeTexture(`${key}_bump`, cBump, 2, 1, 2, false);
  return { map, bumpMap };
}

export function getStoneSoilPBRTextures(anisotropy = 2, mossy = true): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `stone_pbr_${mossy ? 'moss' : 'crypt'}_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  if (cachedMap && cachedBump && cachedRough) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough };
  }

  const size = resolveTexSize(anisoBucket, 512);
  const scale = size / 256;
  const rng = createRng(mossy ? 404 : 505);
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);

  ctxMap.fillStyle = mossy ? '#182018' : '#1e2128';
  ctxMap.fillRect(0, 0, size, size);
  ctxBump.fillStyle = '#7c7c7c';
  ctxBump.fillRect(0, 0, size, size);
  ctxRough.fillStyle = mossy ? '#dedede' : '#b2b2b2';
  ctxRough.fillRect(0, 0, size, size);

  if (!mossy) {
    const course = Math.round(64 * scale);
    for (let y = 0; y < size; y += course) {
      ctxMap.fillStyle = '#0e1014';
      ctxMap.fillRect(0, y, size, 2);
      ctxBump.fillStyle = '#262626';
      ctxBump.fillRect(0, y, size, 3);
      for (let x = (y / course) % 2 === 0 ? 0 : course / 2; x < size; x += course) {
        ctxMap.fillRect(x, y, 2, course);
        ctxBump.fillRect(x, y, 3, course);
      }
    }
  }

  for (let i = 0; i < 650; i++) {
    const x = rng() * size;
    const y = rng() * size;
    const s = (2 + rng() * 6) * scale;
    ctxMap.fillStyle = mossy
      ? rng() > 0.45
        ? 'rgba(34, 54, 28, 0.38)'
        : 'rgba(12, 12, 12, 0.35)'
      : 'rgba(46, 52, 64, 0.35)';
    ctxMap.fillRect(x, y, s, s);

    const bVal = Math.round(70 + rng() * 110);
    ctxBump.fillStyle = `rgb(${bVal},${bVal},${bVal})`;
    ctxBump.fillRect(x, y, s, s);

    const rVal = mossy && rng() > 0.86 ? 65 : Math.round(170 + rng() * 65);
    ctxRough.fillStyle = `rgb(${rVal},${rVal},${rVal})`;
    ctxRough.fillRect(x, y, s, s);
  }

  return {
    map: finalizeTexture(`${key}_map`, cMap, 8, 8, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 8, 8, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 8, 8, anisoBucket, false),
  };
}

export function getDimensionRunePBRTextures(anisotropy = 2): PBRTextureSet {
  const anisoBucket = anisotropy >= 4 ? 4 : anisotropy >= 2 ? 2 : 1;
  const key = `dimension_pbr_${anisoBucket}`;
  const cachedMap = textureCache.get(`${key}_map`);
  const cachedBump = textureCache.get(`${key}_bump`);
  const cachedRough = textureCache.get(`${key}_rough`);
  const cachedEmis = textureCache.get(`${key}_emis`);
  if (cachedMap && cachedBump && cachedRough && cachedEmis) {
    return { map: cachedMap, bumpMap: cachedBump, roughnessMap: cachedRough, emissiveMap: cachedEmis };
  }

  const size = 256;
  const [cMap, ctxMap] = createCanvas(size);
  const [cBump, ctxBump] = createCanvas(size);
  const [cRough, ctxRough] = createCanvas(size);
  const [cEmis, ctxEmis] = createCanvas(size);

  ctxMap.fillStyle = '#0e0a18';
  ctxMap.fillRect(0, 0, size, size);
  ctxBump.fillStyle = '#909090';
  ctxBump.fillRect(0, 0, size, size);
  ctxRough.fillStyle = '#606060';
  ctxRough.fillRect(0, 0, size, size);
  ctxEmis.fillStyle = '#000000';
  ctxEmis.fillRect(0, 0, size, size);

  const drawSigil = (ctx: CanvasRenderingContext2D, strokePrimary: string, strokeSecondary: string) => {
    ctx.strokeStyle = strokePrimary;
    ctx.lineWidth = 2.5;
    ctx.strokeRect(8, 8, size - 16, size - 16);
    ctx.strokeStyle = strokeSecondary;
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, 74, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(size / 2, 20);
    ctx.lineTo(size - 28, size - 48);
    ctx.lineTo(28, size - 48);
    ctx.closePath();
    ctx.stroke();
  };

  drawSigil(ctxMap, 'rgba(225, 29, 72, 0.45)', 'rgba(139, 92, 246, 0.45)');
  drawSigil(ctxBump, '#222222', '#222222');
  drawSigil(ctxRough, '#323232', '#323232');
  drawSigil(ctxEmis, '#e11d48', '#8b5cf6');

  return {
    map: finalizeTexture(`${key}_map`, cMap, 2, 2, anisoBucket, true),
    bumpMap: finalizeTexture(`${key}_bump`, cBump, 2, 2, anisoBucket, false),
    roughnessMap: finalizeTexture(`${key}_rough`, cRough, 2, 2, anisoBucket, false),
    emissiveMap: finalizeTexture(`${key}_emis`, cEmis, 2, 2, anisoBucket, true),
  };
}

export function getWoodPlanksTexture(anisotropy = 2, darkTone = false): THREE.CanvasTexture {
  return getWoodPBRTextures(anisotropy, darkTone).map;
}

export function getPeelingWallTexture(anisotropy = 2, tint = '#27242a'): THREE.CanvasTexture {
  return getWallPBRTextures(anisotropy, tint).map;
}

export function getStoneSoilTexture(anisotropy = 2, mossy = true): THREE.CanvasTexture {
  return getStoneSoilPBRTextures(anisotropy, mossy).map;
}

export function getDimensionRuneTexture(anisotropy = 2): THREE.CanvasTexture {
  return getDimensionRunePBRTextures(anisotropy).map;
}

export function getDoorPlaqueTexture(numeral: string, accentHex: string): THREE.CanvasTexture {
  const key = `plaque_${numeral}_${accentHex}`;
  if (textureCache.has(key)) return textureCache.get(key)!;

  const [canvas, ctx] = createCanvas(128);
  ctx.fillStyle = '#111115';
  ctx.fillRect(0, 0, 128, 128);
  ctx.strokeStyle = accentHex;
  ctx.lineWidth = 6;
  ctx.strokeRect(8, 8, 112, 112);
  ctx.fillStyle = '#f4f4f5';
  ctx.font = 'bold 54px Georgia, serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(numeral, 64, 68);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  textureCache.set(key, tex);
  return tex;
}

export function getContactShadowTexture(): THREE.CanvasTexture {
  const key = 'shared_contact_shadow';
  if (textureCache.has(key)) return textureCache.get(key)!;

  const [canvas, ctx] = createCanvas(64);
  const grad = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
  grad.addColorStop(0, 'rgba(0,0,0,0.68)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);

  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  textureCache.set(key, tex);
  return tex;
}

export function disposeCachedTextures() {
  textureCache.forEach((t) => t.dispose());
  textureCache.clear();
}
