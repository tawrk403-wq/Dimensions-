import { ITEMS_CATALOG } from '../data/gameData';
import { Difficulty, GameProgressState, GameSettings, SaveSlot } from '../types/game';

const SETTINGS_KEY = 'dimensions_horror_settings_v1';
const SAVES_KEY = 'dimensions_horror_saves_v1';
const PENDING_SYNC_KEY = 'dimensions_pending_cloud_sync_v1';

export function detectRecommendedQualityTier(): 'low' | 'medium' | 'high' | 'ultra' {
  if (typeof navigator === 'undefined') return 'medium';
  const ua = navigator.userAgent || '';
  const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
  const cores = navigator.hardwareConcurrency || 4;
  const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory || 4;

  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (gl) {
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const gpu = String(gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      if (/SwiftShader|llvmpipe|softpipe|Software|Mali-4|Mali-T|Adreno\s*\(TM\)\s*[2345]|PowerVR/i.test(gpu)) {
        return 'low';
      }
      if (/Mali-G[56]|Adreno\s*\(TM\)\s*6[012]/i.test(gpu) && (cores <= 6 || mem <= 4)) {
        return 'low';
      }
      if (/RTX|Radeon\s*RX|Apple\s*M[1-9]|Adreno\s*\(TM\)\s*[78]/i.test(gpu) && mem >= 8) {
        return isMobile ? 'high' : 'ultra';
      }
    }
  } catch {
    // ignore WebGL probe errors
  }

  if (isMobile) {
    if (cores <= 4 || mem <= 3) return 'low';
    if (cores <= 8 && mem <= 6) return 'medium';
    return 'high';
  }
  if (cores <= 4 || mem <= 4) return 'medium';
  return 'high';
}

const initialTier = typeof window !== 'undefined' ? detectRecommendedQualityTier() : 'medium';

export const DEFAULT_SETTINGS: GameSettings = {
  language: 'en',
  difficulty: 'normal',
  cameraPerspective: 'first',
  graphicsQuality: 'auto',
  resolutionScale: initialTier === 'low' ? 0.75 : initialTier === 'medium' ? 0.85 : 1.0,
  shadowsEnabled: initialTier === 'high' || initialTier === 'ultra',
  volumetricFog: initialTier !== 'low',
  targetFps: initialTier === 'low' ? 30 : 60,
  brightness: 1.25,
  masterVolume: 0.85,
  musicVolume: 0.7,
  environmentVolume: 0.8,
  effectsVolume: 0.9,
  dialogueVolume: 0.95,
  joystickSensitivity: 1.0,
  lookSensitivity: 1.0,
  leftHandedLayout: false,
  subtitlesEnabled: true,
  muted: false,
};

export function createNewGameProgress(difficulty: Difficulty, startChapter: 1 | 2 | 3 = 1): GameProgressState {
  const spawnByChapter = {
    1: { x: 0, y: 0.24, z: 10.5, yaw: 0 },
    2: { x: 0, y: 0, z: 24, yaw: 0 },
    3: { x: 0, y: 0, z: 24, yaw: 0 },
  };
  return {
    chapter: startChapter,
    unlockedChapters: startChapter === 1 ? [1] : startChapter === 2 ? [1, 2] : [1, 2, 3],
    health: 100,
    stamina: 100,
    battery: difficulty === 'nightmare' ? 65 : difficulty === 'hard' ? 85 : 100,
    inventory: [
      { ...ITEMS_CATALOG.flashlight, quantity: 1 },
      { ...ITEMS_CATALOG.bandage, quantity: difficulty === 'nightmare' ? 1 : 2 },
    ],
    collectedBottleIds: [],
    collectedLetterIds: [],
    solvedPuzzleIds: [],
    unlockedDoorIds: ['door_1', 'door_2', 'door_3'],
    discoveredRoomIds: startChapter === 1 ? ['c1_foyer'] : startChapter === 2 ? ['c2_gate'] : ['c3_threshold'],
    discoveredMapFragments: 0,
    aliRescued: startChapter > 1,
    aliFollowing: startChapter > 1,
    aliSuspicionScore: 0,
    defeatedBossIds: [],
    truthCluesFound: 0,
    secretRiftUnlocked: false,
    viewedCinematics: [],
    playerPosition: spawnByChapter[startChapter],
    decisions: {
      trustedAli: true,
      freedZoya: false,
      challengedArchitect: false,
    },
    difficulty,
    playTimeSeconds: 0,
  };
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<GameSettings>;
    const merged: GameSettings = { ...DEFAULT_SETTINGS, ...parsed };
    if (!['auto', 'low', 'medium', 'high', 'ultra'].includes(merged.graphicsQuality)) {
      merged.graphicsQuality = 'auto';
    }
    return merged;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: GameSettings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore storage quota errors
  }
}

export function loadAllSaveSlots(): Record<string, SaveSlot> {
  try {
    const raw = localStorage.getItem(SAVES_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function writeAllSaveSlots(all: Record<string, SaveSlot>) {
  try {
    localStorage.setItem(SAVES_KEY, JSON.stringify(all));
  } catch {
    // ignore storage quota errors
  }
}

export function saveToSlot(slotId: string, progress: GameProgressState): SaveSlot {
  const all = loadAllSaveSlots();
  const clone: GameProgressState = JSON.parse(JSON.stringify(progress));
  const entry: SaveSlot = {
    slotId,
    savedAt: new Date().toLocaleString(),
    clientUpdatedAtMs: Date.now(),
    chapter: clone.chapter,
    difficulty: clone.difficulty,
    progress: clone,
  };
  all[slotId] = entry;
  writeAllSaveSlots(all);
  markSlotPendingCloudSync(slotId);
  return entry;
}

export function getPendingSyncSlots(): string[] {
  try {
    const raw = localStorage.getItem(PENDING_SYNC_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function markSlotPendingCloudSync(slotId: string) {
  const current = new Set(getPendingSyncSlots());
  current.add(slotId);
  try {
    localStorage.setItem(PENDING_SYNC_KEY, JSON.stringify(Array.from(current)));
  } catch {
    // ignore
  }
}

export function clearSlotPendingCloudSync(slotId: string) {
  const next = getPendingSyncSlots().filter((id) => id !== slotId);
  try {
    localStorage.setItem(PENDING_SYNC_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }
}

export function getLatestSaveSlot(): SaveSlot | null {
  const all = loadAllSaveSlots();
  const list = Object.values(all);
  if (list.length === 0) return null;
  if (all.auto) return all.auto;
  return list.sort((a, b) => (b.clientUpdatedAtMs || 0) - (a.clientUpdatedAtMs || 0))[0];
}
