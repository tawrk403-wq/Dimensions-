import React, { memo, useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowUp,
  Backpack,
  Eye,
  Flashlight,
  Footprints,
  Hand,
  Map as MapIcon,
  Pause,
  Shield,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { t } from '../i18n/translations';
import { GameSettings, PlayerHudState, SubtitleLine } from '../types/game';

interface GameHUDProps {
  hud: PlayerHudState;
  settings: GameSettings;
  activeSubtitle: SubtitleLine | null;
  onMoveInput: (x: number, y: number, sprint: boolean) => void;
  onSprintToggle: (active: boolean) => void;
  onLookDelta: (dx: number, dy: number) => void;
  onInteract: () => void;
  onToggleFlashlight: () => void;
  onToggleCrouch: () => void;
  onJump: () => void;
  onToggleCamera: () => void;
  onOpenInventory: () => void;
  onOpenMap: () => void;
  onPause: () => void;
  onToggleMute: () => void;
}

const GameHUDInner: React.FC<GameHUDProps> = ({
  hud,
  settings,
  activeSubtitle,
  onMoveInput,
  onSprintToggle,
  onLookDelta,
  onInteract,
  onToggleFlashlight,
  onToggleCrouch,
  onJump,
  onToggleCamera,
  onOpenInventory,
  onOpenMap,
  onPause,
  onToggleMute,
}) => {
  const lang = settings.language;
  const isUr = lang === 'ur';

  const joyRef = useRef<HTMLDivElement | null>(null);
  const joyThumbRef = useRef<HTMLDivElement | null>(null);
  const joyPointerId = useRef<number | null>(null);
  const lookPointerId = useRef<number | null>(null);
  const lastLook = useRef({ x: 0, y: 0 });
  const [sprintLocked, setSprintLocked] = useState(false);
  const sprintLockedRef = useRef(false);

  // Sync crouch -> clears sprint UI indicator cleanly
  useEffect(() => {
    if (hud.isCrouching || hud.isHiding) {
      sprintLockedRef.current = false;
      setSprintLocked(false);
    }
  }, [hud.isCrouching, hud.isHiding]);

  const updateJoystick = useCallback(
    (clientX: number, clientY: number) => {
      const el = joyRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const maxR = Math.max(24, rect.width * 0.38);
      let dx = clientX - cx;
      let dy = clientY - cy;
      const dist = Math.hypot(dx, dy);
      if (dist > maxR) {
        dx = (dx / dist) * maxR;
        dy = (dy / dist) * maxR;
      }
      if (joyThumbRef.current) {
        joyThumbRef.current.style.transform = `translate3d(${dx}px, ${dy}px, 0)`;
      }
      const sens = settings.joystickSensitivity;
      const nx = Math.max(-1, Math.min(1, (dx / maxR) * sens));
      const ny = Math.max(-1, Math.min(1, (-dy / maxR) * sens));
      onMoveInput(nx, ny, sprintLockedRef.current || dist >= maxR * 0.9);
    },
    [onMoveInput, settings.joystickSensitivity]
  );

  const resetJoystick = useCallback(() => {
    joyPointerId.current = null;
    if (joyThumbRef.current) {
      joyThumbRef.current.style.transform = 'translate3d(0px, 0px, 0)';
    }
    onMoveInput(0, 0, sprintLockedRef.current);
  }, [onMoveInput]);

  const handleJoyDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      // ignore synthetic events without active pointerId
    }
    joyPointerId.current = e.pointerId;
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyMove = (e: React.PointerEvent) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyUp = (e: React.PointerEvent) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    resetJoystick();
  };

  const handleLookDown = (e: React.PointerEvent) => {
    if (e.target !== e.currentTarget) return;
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      // ignore synthetic events
    }
    lookPointerId.current = e.pointerId;
    lastLook.current = { x: e.clientX, y: e.clientY };
  };

  const handleLookMove = (e: React.PointerEvent) => {
    if (lookPointerId.current !== e.pointerId) return;
    const dx = e.clientX - lastLook.current.x;
    const dy = e.clientY - lastLook.current.y;
    lastLook.current = { x: e.clientX, y: e.clientY };
    onLookDelta(dx, dy);
  };

  const handleLookUp = (e: React.PointerEvent) => {
    if (lookPointerId.current === e.pointerId) {
      lookPointerId.current = null;
    }
  };

  const toggleRun = (e: React.PointerEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const next = !sprintLockedRef.current;
    sprintLockedRef.current = next;
    setSprintLocked(next);
    onSprintToggle(next);
  };

  const dangerVignette = hud.enemyStatus.isChased
    ? 0.65
    : hud.enemyStatus.nearestThreatDist < 12
    ? Math.max(0, (12 - hud.enemyStatus.nearestThreatDist) / 20)
    : 0;

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      className={`fixed inset-0 z-10 pointer-events-none flex flex-col justify-between select-none ${
        isUr ? 'font-urdu' : ''
      }`}
    >
      {/* Subtle Blood/Fear Vignette when stalked or damaged */}
      {(dangerVignette > 0.05 || hud.health < 40) && (
        <div
          className="fixed inset-0 pointer-events-none transition-opacity duration-200"
          style={{
            background: `radial-gradient(circle, transparent 52%, rgba(153, 27, 27, ${Math.min(
              0.72,
              dangerVignette + (hud.health < 40 ? 0.3 : 0)
            )}) 100%)`,
          }}
        />
      )}

      {/* Touch Look Pad covering open screen space */}
      <div
        data-testid="look-pad"
        onPointerDown={handleLookDown}
        onPointerMove={handleLookMove}
        onPointerUp={handleLookUp}
        onPointerCancel={handleLookUp}
        onLostPointerCapture={handleLookUp}
        className="fixed inset-0 pointer-events-auto touch-none-area"
        style={{ zIndex: 1 }}
      />

      {/* TOP BAR: Compact Vitals Cluster + Boss Bar + Objective & Quick Utility Strip */}
      <div className="relative z-10 flex items-start justify-between gap-2 sm:gap-3 p-2.5 sm:p-4 pointer-events-none">
        {/* Vitals & Status */}
        <div
          onPointerDown={(e) => e.stopPropagation()}
          className="bg-[#090a0f]/85 border border-zinc-800/80 px-2.5 py-1.5 sm:px-3 sm:py-2 min-w-[155px] sm:min-w-[210px] space-y-1 pointer-events-auto"
        >
          <div className="flex items-center justify-between text-[11px] text-zinc-300">
            <span>{t(lang, 'health')}</span>
            <span className="tabular-nums text-rose-400 font-semibold">{hud.health}%</span>
          </div>
          <div className="h-1.5 bg-zinc-900 overflow-hidden">
            <div
              className="h-full bg-rose-600 transition-all duration-150"
              style={{ width: `${hud.health}%` }}
            />
          </div>

          <div className="grid grid-cols-2 gap-2 pt-0.5">
            <div>
              <div className="flex justify-between text-[10px] text-zinc-400">
                <span>{t(lang, 'stamina')}</span>
                <span className="tabular-nums">{hud.stamina}</span>
              </div>
              <div className="h-1 bg-zinc-900">
                <div className="h-full bg-sky-500" style={{ width: `${hud.stamina}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-[10px] text-zinc-400">
                <span>{t(lang, 'battery')}</span>
                <span className="tabular-nums">{hud.battery}%</span>
              </div>
              <div className="h-1 bg-zinc-900">
                <div
                  className={`h-full ${hud.battery < 20 ? 'bg-rose-500' : 'bg-amber-400'}`}
                  style={{ width: `${hud.battery}%` }}
                />
              </div>
            </div>
          </div>

          {hud.aliRescued && (
            <div className="flex items-center justify-between pt-1 border-t border-zinc-800/70 text-[10px] text-emerald-400">
              <span>{t(lang, 'aliStatus')}</span>
              <span>{hud.aliFollowing ? t(lang, 'aliFollowing') : t(lang, 'aliWaiting')}</span>
            </div>
          )}
        </div>

        {/* Center Boss Bar */}
        {hud.enemyStatus.bossNameEn && (
          <div className="flex flex-col items-center bg-[#090a0f]/90 border border-rose-800/70 px-3 py-1 min-w-[145px] sm:min-w-[230px]">
            <span className="text-[10px] sm:text-[11px] uppercase tracking-widest text-rose-400 font-semibold text-center">
              {isUr ? hud.enemyStatus.bossNameUr : hud.enemyStatus.bossNameEn}
            </span>
            <div className="w-full h-1.5 bg-zinc-900 mt-1">
              <div
                className="h-full bg-rose-500 transition-all"
                style={{
                  width: `${
                    ((hud.enemyStatus.bossHealth || 0) / (hud.enemyStatus.bossMaxHealth || 3)) * 100
                  }%`,
                }}
              />
            </div>
          </div>
        )}

        {/* Top-Right Compact Utility Strip */}
        <div
          onPointerDown={(e) => e.stopPropagation()}
          className="flex flex-col items-end gap-1.5 pointer-events-auto"
        >
          <div className="flex items-center gap-1 sm:gap-1.5">
            <button
              type="button"
              data-testid="btn-map"
              aria-label={t(lang, 'map')}
              onClick={onOpenMap}
              title={t(lang, 'map')}
              className="p-2 bg-[#090a0f]/90 hover:bg-zinc-900 active:bg-rose-900 border border-zinc-700 text-zinc-200 cursor-pointer"
            >
              <MapIcon className="w-4 h-4" />
            </button>
            <button
              type="button"
              data-testid="btn-inventory"
              aria-label={t(lang, 'inventory')}
              onClick={onOpenInventory}
              title={t(lang, 'inventory')}
              className="p-2 bg-[#090a0f]/90 hover:bg-zinc-900 active:bg-rose-900 border border-zinc-700 text-zinc-200 cursor-pointer"
            >
              <Backpack className="w-4 h-4" />
            </button>
            <button
              type="button"
              data-testid="btn-camera"
              aria-label={t(lang, 'camToggle')}
              onClick={onToggleCamera}
              title={t(lang, 'camToggle')}
              className="p-2 bg-[#090a0f]/90 hover:bg-zinc-900 active:bg-rose-900 border border-zinc-700 text-zinc-200 cursor-pointer"
            >
              <Eye className="w-4 h-4" />
            </button>
            <button
              type="button"
              data-testid="btn-mute"
              aria-label="Mute"
              onClick={onToggleMute}
              className="p-2 bg-[#090a0f]/90 hover:bg-zinc-900 active:bg-rose-900 border border-zinc-700 text-zinc-200 cursor-pointer"
            >
              {settings.muted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <button
              type="button"
              data-testid="btn-pause"
              aria-label="Pause"
              onClick={onPause}
              className="p-2 bg-[#090a0f]/90 hover:bg-zinc-900 active:bg-rose-900 border border-rose-700/70 text-zinc-100 cursor-pointer"
            >
              <Pause className="w-4 h-4" />
            </button>
          </div>
          <div className="max-w-[190px] sm:max-w-[280px] text-end px-2 py-0.5 sm:py-1 bg-[#090a0f]/80 border border-zinc-800/70 text-[10px] sm:text-[11px] text-zinc-300 pointer-events-none">
            {isUr ? hud.objectiveUr : hud.objectiveEn}
          </div>
        </div>
      </div>

      {/* CENTER RETICLE & INTERACT PROMPT */}
      <div className="relative z-10 flex flex-col items-center justify-center pointer-events-none">
        <div className="w-1.5 h-1.5 rounded-full bg-zinc-200/80" />
        {(hud.interactPromptEn || hud.isHiding) && (
          <button
            type="button"
            data-testid="btn-center-interact"
            onPointerDown={(e) => {
              e.stopPropagation();
              e.preventDefault();
              onInteract();
            }}
            className="mt-3 px-3.5 py-1.5 bg-[#090a0f]/95 border border-rose-500/80 text-xs sm:text-sm text-zinc-100 tracking-wide pointer-events-auto cursor-pointer"
          >
            [E] {isUr ? hud.interactPromptUr : hud.interactPromptEn}
          </button>
        )}
      </div>

      {/* BOTTOM TOUCH CONTROLS (dir="ltr" locks joystick to bottom-left cleanly in EN & UR) */}
      <div className="relative z-10 flex flex-col items-center gap-1.5 p-3 sm:p-4 pointer-events-none">
        {settings.subtitlesEnabled && activeSubtitle && (
          <div className="max-w-xl px-3.5 py-1.5 bg-[#07080c]/92 border border-zinc-800 text-center">
            <span className="text-[10px] sm:text-[11px] uppercase tracking-wider text-rose-400 font-semibold mr-2">
              {isUr ? activeSubtitle.speakerUr : activeSubtitle.speakerEn}:
            </span>
            <span className="text-xs sm:text-sm text-zinc-100">
              {isUr ? activeSubtitle.textUr : activeSubtitle.textEn}
            </span>
          </div>
        )}

        <div
          dir="ltr"
          className={`w-full flex items-end justify-between ${
            settings.leftHandedLayout ? 'flex-row-reverse' : 'flex-row'
          }`}
        >
          {/* Permanent Virtual Analog Joystick (Bottom-Left) */}
          <div
            ref={joyRef}
            data-testid="virtual-joystick"
            onPointerDown={handleJoyDown}
            onPointerMove={handleJoyMove}
            onPointerUp={handleJoyUp}
            onPointerCancel={handleJoyUp}
            onLostPointerCapture={resetJoystick}
            className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-[#0b0c12]/80 border-2 border-zinc-500/75 shadow-lg flex items-center justify-center pointer-events-auto touch-none-area"
          >
            {/* Directional crosshair indicators */}
            <div className="absolute inset-2 rounded-full border border-dashed border-zinc-700/60 pointer-events-none" />
            <span className="absolute top-1.5 text-[9px] text-zinc-400 font-bold pointer-events-none">▲</span>
            <span className="absolute bottom-1.5 text-[9px] text-zinc-400 font-bold pointer-events-none">▼</span>
            <span className="absolute left-2 text-[9px] text-zinc-400 font-bold pointer-events-none">◀</span>
            <span className="absolute right-2 text-[9px] text-zinc-400 font-bold pointer-events-none">▶</span>
            {/* Draggable Thumb */}
            <div
              ref={joyThumbRef}
              data-testid="joystick-thumb"
              className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-rose-600/45 border-2 border-rose-300/85 shadow-md pointer-events-none"
            />
          </div>

          {/* Right Thumb Action Cluster (Jump, Run, Crouch, Interact, Light) */}
          <div
            onPointerDown={(e) => e.stopPropagation()}
            className="flex items-end gap-2 sm:gap-2.5 pointer-events-auto touch-none-area"
          >
            {/* Secondary Controls Stack: Light, Crouch, Run */}
            <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
              <button
                type="button"
                data-testid="btn-flashlight"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  onToggleFlashlight();
                }}
                className={`w-12 h-12 sm:w-13 sm:h-13 rounded-full border-2 flex flex-col items-center justify-center text-[10px] font-medium cursor-pointer ${
                  hud.flashlightOn
                    ? 'bg-amber-600/85 border-amber-300 text-white'
                    : 'bg-[#0b0c12]/85 border-zinc-600 text-zinc-300'
                }`}
              >
                <Flashlight className="w-4 h-4" />
                <span>{t(lang, 'flashlight')}</span>
              </button>

              <button
                type="button"
                data-testid="btn-crouch"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  onToggleCrouch();
                }}
                className={`w-12 h-12 sm:w-13 sm:h-13 rounded-full border-2 flex flex-col items-center justify-center text-[10px] font-medium cursor-pointer ${
                  hud.isCrouching
                    ? 'bg-sky-700/90 border-sky-300 text-white'
                    : 'bg-[#0b0c12]/85 border-zinc-600 text-zinc-300'
                }`}
              >
                <Shield className="w-4 h-4" />
                <span>{t(lang, 'crouch')}</span>
              </button>

              <button
                type="button"
                data-testid="btn-run"
                aria-pressed={sprintLocked}
                onPointerDown={toggleRun}
                className={`w-12 h-12 sm:w-13 sm:h-13 rounded-full border-2 flex flex-col items-center justify-center text-[10px] font-medium cursor-pointer ${
                  sprintLocked
                    ? 'bg-emerald-700/90 border-emerald-300 text-white'
                    : 'bg-[#0b0c12]/85 border-zinc-600 text-zinc-200'
                }`}
              >
                <Footprints className="w-4 h-4" />
                <span>{t(lang, 'sprint')}</span>
              </button>

              {/* Interact Button */}
              <button
                type="button"
                data-testid="btn-interact"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  onInteract();
                }}
                className={`col-span-3 h-12 sm:h-13 rounded-full border-2 flex items-center justify-center gap-1.5 text-xs font-semibold cursor-pointer ${
                  hud.interactPromptEn || hud.isHiding
                    ? 'bg-rose-700/95 border-rose-300 text-white'
                    : 'bg-[#0b0c12]/85 border-zinc-600 text-zinc-200'
                }`}
              >
                <Hand className="w-4 h-4" />
                <span>{hud.isHiding ? t(lang, 'unhide') : t(lang, 'interact')}</span>
              </button>
            </div>

            {/* Dedicated Prominent Jump Button */}
            <button
              type="button"
              data-testid="btn-jump"
              onPointerDown={(e) => {
                e.stopPropagation();
                e.preventDefault();
                onJump();
              }}
              className="w-15 h-15 sm:w-16 sm:h-16 rounded-full bg-[#11131d]/90 hover:bg-rose-950/90 active:bg-rose-700 border-2 border-zinc-400/80 text-zinc-100 flex flex-col items-center justify-center text-[11px] font-bold tracking-wide shadow-lg cursor-pointer"
            >
              <ArrowUp className="w-5 h-5" />
              <span>{t(lang, 'jump')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const GameHUD = memo(GameHUDInner);
