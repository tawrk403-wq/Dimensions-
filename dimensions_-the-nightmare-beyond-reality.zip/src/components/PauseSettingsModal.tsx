import React, { useState } from 'react';
import { HardDrive, RotateCcw, Settings, X } from 'lucide-react';
import { t } from '../i18n/translations';
import {
  CameraPerspective,
  GameSettings,
  GraphicsQuality,
  Language,
  SaveSlot,
} from '../types/game';

interface PauseSettingsModalProps {
  mode: 'pause' | 'settings_only' | 'save_shrine';
  settings: GameSettings;
  saveSlots: Record<string, SaveSlot>;
  onUpdateSettings: (next: GameSettings) => void;
  onSaveToSlot: (slotId: string) => void;
  onResume: () => void;
  onRestart: () => void;
  onExitToTitle: () => void;
}

export const PauseSettingsModal: React.FC<PauseSettingsModalProps> = ({
  mode,
  settings,
  saveSlots,
  onUpdateSettings,
  onSaveToSlot,
  onResume,
  onRestart,
  onExitToTitle,
}) => {
  const lang = settings.language;
  const isUr = lang === 'ur';
  const [tab, setTab] = useState<'menu' | 'settings' | 'save'>(
    mode === 'settings_only' ? 'settings' : mode === 'save_shrine' ? 'save' : 'menu'
  );
  const [settingsTab, setSettingsTab] = useState<'graphics' | 'audio' | 'controls' | 'camera'>('graphics');
  const [saveNotice, setSaveNotice] = useState<string | null>(null);

  const patch = (partial: Partial<GameSettings>) => {
    onUpdateSettings({ ...settings, ...partial });
  };

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      onPointerDown={(e) => e.stopPropagation()}
      className={`fixed inset-0 z-40 flex items-center justify-center bg-[#040407]/88 p-4 ${isUr ? 'font-urdu' : ''}`}
    >
      <div className="w-full max-w-xl max-h-[88vh] flex flex-col bg-[#0c0d14] border border-zinc-700/80 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800 bg-[#08090e]">
          <span className="text-sm font-display font-bold tracking-widest text-rose-400 uppercase">
            {tab === 'save'
              ? t(lang, 'saveGame')
              : tab === 'settings'
              ? t(lang, 'settings')
              : t(lang, 'gameTitle')}
          </span>
          <button
            type="button"
            data-testid="modal-close"
            onClick={onResume}
            className="p-1 text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto horror-scroll p-4 space-y-4">
          {tab === 'menu' && (
            <div className="space-y-2.5">
              <div className="w-full aspect-video max-h-28 overflow-hidden border border-rose-900/40 bg-[#050609]">
                <img
                  src="/assets/aistudio/Haunted_Dimensions__Blood_Moon_Manor_889d9a7a.png"
                  alt="DIMENSIONS"
                  className="w-full h-full object-cover"
                />
              </div>
              <button
                type="button"
                data-testid="btn-resume"
                onClick={onResume}
                className="w-full py-2.5 bg-rose-900/85 hover:bg-rose-800 border border-rose-500/60 text-sm font-semibold text-white cursor-pointer"
              >
                {t(lang, 'resumeGame')}
              </button>
              <button
                type="button"
                data-testid="btn-restart"
                onClick={onRestart}
                className="w-full py-2.5 bg-[#16121b] hover:bg-rose-950/60 border border-zinc-700 text-sm text-amber-300 flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t(lang, 'restartChapter')}</span>
              </button>
              <button
                type="button"
                data-testid="btn-open-settings"
                onClick={() => setTab('settings')}
                className="w-full py-2.5 bg-[#12131c] hover:bg-zinc-900 border border-zinc-800 text-sm text-zinc-200 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Settings className="w-4 h-4" />
                <span>{t(lang, 'settings')}</span>
              </button>
              <div className="p-2.5 bg-[#08090d] border border-zinc-800/70 text-[11px] text-zinc-400 text-center">
                {t(lang, 'safeShrineOnly')}
              </div>
              <button
                type="button"
                data-testid="btn-exit-title"
                onClick={onExitToTitle}
                className="w-full py-2.5 bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 text-sm text-rose-300 cursor-pointer"
              >
                {t(lang, 'exitToTitle')}
              </button>
            </div>
          )}

          {tab === 'save' && (
            <div className="space-y-2.5">
              {saveNotice && (
                <div className="p-2.5 bg-emerald-950/60 border border-emerald-600/60 text-xs text-emerald-300 text-center">
                  {saveNotice}
                </div>
              )}
              {['slot1', 'slot2', 'slot3'].map((slotId) => {
                const existing = saveSlots[slotId];
                return (
                  <button
                    type="button"
                    key={slotId}
                    onClick={() => {
                      onSaveToSlot(slotId);
                      setSaveNotice(t(lang, 'saveSuccess'));
                    }}
                    className="w-full text-start p-3 bg-[#12131c] hover:bg-rose-950/50 border border-zinc-800 hover:border-rose-500 flex items-center justify-between cursor-pointer"
                  >
                    <div>
                      <div className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
                        <HardDrive className="w-4 h-4 text-amber-400" />
                        <span>{t(lang, 'slot')} {slotId.replace('slot', '')}</span>
                      </div>
                      <div className="text-xs text-zinc-400 mt-0.5">
                        {existing ? `${t(lang, 'savedAt')}: ${existing.savedAt}` : t(lang, 'emptySlot')}
                      </div>
                    </div>
                    <span className="text-xs text-rose-400">{t(lang, 'saveGame')}</span>
                  </button>
                );
              })}
              <button
                type="button"
                onClick={onResume}
                className="w-full py-2.5 bg-zinc-900 border border-zinc-700 text-xs uppercase tracking-widest text-zinc-200 cursor-pointer"
              >
                {t(lang, 'close')}
              </button>
            </div>
          )}

          {tab === 'settings' && (
            <div className="space-y-4">
              <div className="grid grid-cols-4 gap-1.5">
                {(['graphics', 'audio', 'controls', 'camera'] as const).map((st) => (
                  <button
                    type="button"
                    key={st}
                    onClick={() => setSettingsTab(st)}
                    className={`py-2 text-xs border cursor-pointer ${
                      settingsTab === st
                        ? 'bg-rose-900/70 border-rose-500 text-white'
                        : 'bg-[#12131c] border-zinc-800 text-zinc-400'
                    }`}
                  >
                    {t(lang, st)}
                  </button>
                ))}
              </div>

              {settingsTab === 'graphics' && (
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-zinc-300">{t(lang, 'quality')}</span>
                    <div className="flex flex-wrap gap-1">
                      {(['auto', 'low', 'medium', 'high', 'ultra'] as GraphicsQuality[]).map((q) => (
                        <button
                          type="button"
                          key={q}
                          data-testid={`quality-${q}`}
                          onClick={() =>
                            patch({
                              graphicsQuality: q,
                              shadowsEnabled: q === 'high' || q === 'ultra' || q === 'auto',
                              volumetricFog: q !== 'low',
                              targetFps: q === 'low' ? 30 : 60,
                            })
                          }
                          className={`px-2.5 py-1 border uppercase cursor-pointer ${
                            settings.graphicsQuality === q
                              ? 'bg-rose-800 border-rose-500 text-white'
                              : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                          }`}
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-300">{t(lang, 'fps')}</span>
                    <div className="flex gap-1">
                      {([30, 60] as const).map((fpsCap) => (
                        <button
                          type="button"
                          key={fpsCap}
                          data-testid={`fps-${fpsCap}`}
                          onClick={() => patch({ targetFps: fpsCap })}
                          className={`px-3 py-1 border cursor-pointer ${
                            settings.targetFps === fpsCap
                              ? 'bg-rose-800 border-rose-500 text-white'
                              : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                          }`}
                        >
                          {fpsCap} FPS
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-300">{t(lang, 'shadows')}</span>
                    <button
                      type="button"
                      onClick={() => patch({ shadowsEnabled: !settings.shadowsEnabled })}
                      className="px-3 py-1 bg-zinc-900 border border-zinc-700 text-zinc-200 cursor-pointer"
                    >
                      {settings.shadowsEnabled ? t(lang, 'on') : t(lang, 'off')}
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-300">{t(lang, 'volumetricFog')}</span>
                    <button
                      type="button"
                      data-testid="toggle-volumetric-fog"
                      onClick={() => patch({ volumetricFog: !settings.volumetricFog })}
                      className="px-3 py-1 bg-zinc-900 border border-zinc-700 text-zinc-200 cursor-pointer"
                    >
                      {settings.volumetricFog ? t(lang, 'on') : t(lang, 'off')}
                    </button>
                  </div>

                  <div>
                    <div className="flex justify-between text-zinc-300 mb-1">
                      <span>{t(lang, 'resolution')}</span>
                      <span>{Math.round(settings.resolutionScale * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min={0.6}
                      max={1.0}
                      step={0.05}
                      value={settings.resolutionScale}
                      onChange={(e) => patch({ resolutionScale: parseFloat(e.target.value) })}
                      className="w-full accent-rose-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-zinc-300 mb-1">
                      <span>{t(lang, 'brightness')}</span>
                      <span>{settings.brightness.toFixed(2)}</span>
                    </div>
                    <input
                      type="range"
                      min={0.85}
                      max={1.6}
                      step={0.05}
                      value={settings.brightness}
                      onChange={(e) => patch({ brightness: parseFloat(e.target.value) })}
                      className="w-full accent-rose-600"
                    />
                  </div>
                </div>
              )}

              {settingsTab === 'audio' && (
                <div className="space-y-3 text-xs">
                  {(
                    [
                      ['masterVolume', 'masterVol'],
                      ['musicVolume', 'musicVol'],
                      ['environmentVolume', 'envVol'],
                      ['effectsVolume', 'sfxVol'],
                      ['dialogueVolume', 'dialogueVol'],
                    ] as const
                  ).map(([field, labelKey]) => (
                    <div key={field}>
                      <div className="flex justify-between text-zinc-300 mb-1">
                        <span>{t(lang, labelKey)}</span>
                        <span>{Math.round(settings[field] * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={1}
                        step={0.05}
                        value={settings[field]}
                        onChange={(e) => patch({ [field]: parseFloat(e.target.value) })}
                        className="w-full accent-rose-600"
                      />
                    </div>
                  ))}
                </div>
              )}

              {settingsTab === 'controls' && (
                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between text-zinc-300 mb-1">
                      <span>{t(lang, 'joySens')}</span>
                      <span>{settings.joystickSensitivity.toFixed(1)}×</span>
                    </div>
                    <input
                      type="range"
                      min={0.5}
                      max={2.0}
                      step={0.1}
                      value={settings.joystickSensitivity}
                      onChange={(e) => patch({ joystickSensitivity: parseFloat(e.target.value) })}
                      className="w-full accent-rose-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-zinc-300 mb-1">
                      <span>{t(lang, 'lookSens')}</span>
                      <span>{settings.lookSensitivity.toFixed(1)}×</span>
                    </div>
                    <input
                      type="range"
                      min={0.4}
                      max={2.0}
                      step={0.1}
                      value={settings.lookSensitivity}
                      onChange={(e) => patch({ lookSensitivity: parseFloat(e.target.value) })}
                      className="w-full accent-rose-600"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-300">{t(lang, 'leftHanded')}</span>
                    <button
                      type="button"
                      onClick={() => patch({ leftHandedLayout: !settings.leftHandedLayout })}
                      className="px-3 py-1 bg-zinc-900 border border-zinc-700 text-zinc-200 cursor-pointer"
                    >
                      {settings.leftHandedLayout ? t(lang, 'on') : t(lang, 'off')}
                    </button>
                  </div>
                </div>
              )}

              {settingsTab === 'camera' && (
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-300">{t(lang, 'perspective')}</span>
                    <div className="flex gap-1">
                      {(['first', 'third'] as CameraPerspective[]).map((persp) => (
                        <button
                          type="button"
                          key={persp}
                          onClick={() => patch({ cameraPerspective: persp })}
                          className={`px-3 py-1 border cursor-pointer ${
                            settings.cameraPerspective === persp
                              ? 'bg-rose-800 border-rose-500 text-white'
                              : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                          }`}
                        >
                          {persp === 'first' ? t(lang, 'firstPerson') : t(lang, 'thirdPerson')}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-300">{t(lang, 'subtitles')}</span>
                    <button
                      type="button"
                      onClick={() => patch({ subtitlesEnabled: !settings.subtitlesEnabled })}
                      className="px-3 py-1 bg-zinc-900 border border-zinc-700 text-zinc-200 cursor-pointer"
                    >
                      {settings.subtitlesEnabled ? t(lang, 'on') : t(lang, 'off')}
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-zinc-300">{t(lang, 'language')}</span>
                    <div className="flex gap-1">
                      {(['en', 'ur'] as Language[]).map((l) => (
                        <button
                          type="button"
                          key={l}
                          onClick={() => patch({ language: l })}
                          className={`px-3 py-1 border cursor-pointer ${
                            settings.language === l
                              ? 'bg-rose-800 border-rose-500 text-white'
                              : 'bg-zinc-900 border-zinc-800 text-zinc-400'
                          }`}
                        >
                          {l === 'en' ? 'English' : 'اردو'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {mode === 'pause' && (
                <button
                  type="button"
                  onClick={() => setTab('menu')}
                  className="w-full py-2 bg-zinc-900 border border-zinc-700 text-xs uppercase tracking-widest text-zinc-300 cursor-pointer"
                >
                  {t(lang, 'back')}
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
