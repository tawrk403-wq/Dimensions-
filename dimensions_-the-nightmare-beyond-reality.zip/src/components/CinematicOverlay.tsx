import React, { useEffect, useState } from 'react';
import { FastForward } from 'lucide-react';
import { CINEMATICS, ENDINGS } from '../data/gameData';
import { t } from '../i18n/translations';
import { EndingId, GameProgressState, Language } from '../types/game';

interface CinematicOverlayProps {
  cinematicId: string | null;
  endingId: EndingId | null;
  progress: GameProgressState;
  lang: Language;
  onFinishCinematic: (cinematicId: string) => void;
  onReturnToTitle: () => void;
}

export const CinematicOverlay: React.FC<CinematicOverlayProps> = ({
  cinematicId,
  endingId,
  progress,
  lang,
  onFinishCinematic,
  onReturnToTitle,
}) => {
  const isUr = lang === 'ur';
  const [lineIdx, setLineIdx] = useState(0);

  const seq = cinematicId ? CINEMATICS[cinematicId] : null;
  const ending = endingId ? ENDINGS[endingId] : null;

  useEffect(() => {
    setLineIdx(0);
  }, [cinematicId]);

  useEffect(() => {
    if (!seq) return;
    const current = seq.lines[lineIdx];
    if (!current) {
      onFinishCinematic(seq.id);
      return;
    }
    const timer = window.setTimeout(() => {
      if (lineIdx + 1 < seq.lines.length) {
        setLineIdx((i) => i + 1);
      } else {
        onFinishCinematic(seq.id);
      }
    }, current.duration * 1000);
    return () => window.clearTimeout(timer);
  }, [seq, lineIdx, onFinishCinematic]);

  const artworkUrl =
    cinematicId === 'chapter2_intro'
      ? '/assets/chapter2.jpg'
      : cinematicId === 'chapter3_intro'
      ? '/assets/chapter3.jpg'
      : '/assets/chapter1.jpg';

  if (ending) {
    return (
      <div
        dir={isUr ? 'rtl' : 'ltr'}
        className={`fixed inset-0 z-50 flex items-center justify-center bg-[#040407]/96 p-4 sm:p-6 overflow-y-auto ${isUr ? 'font-urdu' : ''}`}
      >
        <div className="max-w-xl w-full bg-[#0b0c12] border border-zinc-700 p-4 sm:p-6 space-y-3 sm:space-y-4 text-center">
          <div
            className="text-xs uppercase tracking-[0.28em] font-semibold"
            style={{ color: ending.color }}
          >
            {t(lang, 'endingUnlocked')}
          </div>
          <h1 className="text-xl sm:text-3xl font-display font-bold text-zinc-100">
            {isUr ? ending.titleUr : ending.titleEn}
          </h1>
          <p className="text-xs sm:text-sm text-rose-300/90">{isUr ? ending.subtitleUr : ending.subtitleEn}</p>
          <p className="text-xs sm:text-sm leading-relaxed text-zinc-300 border-y border-zinc-800 py-3">
            {isUr ? ending.storyUr : ending.storyEn}
          </p>

          <div className="grid grid-cols-3 gap-2.5 text-xs">
            <div className="p-2 bg-[#12131c] border border-zinc-800">
              <div className="text-zinc-400">{t(lang, 'bottlesFound')}</div>
              <div className="text-sm sm:text-base font-bold text-amber-400 tabular-nums">
                {progress.collectedBottleIds.length} / 9
              </div>
            </div>
            <div className="p-2 bg-[#12131c] border border-zinc-800">
              <div className="text-zinc-400">{t(lang, 'lettersRead')}</div>
              <div className="text-sm sm:text-base font-bold text-sky-400 tabular-nums">
                {progress.collectedLetterIds.length} / 13
              </div>
            </div>
            <div className="p-2 bg-[#12131c] border border-zinc-800">
              <div className="text-zinc-400">{t(lang, 'truthLevel')}</div>
              <div className="text-sm sm:text-base font-bold text-rose-400 tabular-nums">
                {progress.truthCluesFound}
              </div>
            </div>
          </div>

          <button
            onClick={onReturnToTitle}
            className="w-full py-2.5 bg-rose-800 hover:bg-rose-700 border border-rose-500 text-xs sm:text-sm font-semibold text-white cursor-pointer"
          >
            {t(lang, 'playAgain')}
          </button>
        </div>
      </div>
    );
  }

  if (!seq) return null;
  const currentLine = seq.lines[lineIdx] || seq.lines[seq.lines.length - 1];

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      className={`fixed inset-0 z-50 flex flex-col justify-between bg-[#040407]/85 ${isUr ? 'font-urdu' : ''}`}
    >
      {/* Top Letterbox Bar */}
      <div className="relative z-10 bg-[#040407] border-b border-zinc-900 px-4 py-2.5 sm:py-3.5 flex items-center justify-between">
        <span className="text-xs sm:text-sm font-display tracking-[0.22em] text-rose-400">
          {isUr ? seq.titleUr : seq.titleEn}
        </span>
        <button
          onClick={() => onFinishCinematic(seq.id)}
          className="flex items-center gap-1.5 px-3 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 cursor-pointer"
        >
          <FastForward className="w-3.5 h-3.5" />
          <span>{t(lang, 'skip')}</span>
        </button>
      </div>

      {/* Center Atmospheric Chapter Key-Art Plate */}
      <div className="relative flex-1 flex items-center justify-center px-4 py-2 overflow-hidden">
        <img
          src={artworkUrl}
          alt={seq.titleEn}
          className="max-h-full max-w-2xl w-full object-cover border border-rose-900/40 opacity-85"
        />
      </div>

      {/* Bottom Letterbox Bar with Subtitles */}
      <div className="relative z-10 bg-[#040407] border-t border-zinc-900 px-4 py-3 sm:py-5 flex flex-col items-center text-center">
        <div className="text-[11px] uppercase tracking-widest text-amber-400 mb-1">
          {isUr ? currentLine.speakerUr : currentLine.speakerEn}
        </div>
        <p className="max-w-2xl text-xs sm:text-base text-zinc-100 leading-relaxed">
          {isUr ? currentLine.textUr : currentLine.textEn}
        </p>
      </div>
    </div>
  );
};
