import React, { useState } from 'react';
import { User } from 'firebase/auth';
import {
  BookOpen,
  Cloud,
  CloudOff,
  Download,
  Globe,
  HardDrive,
  Layers,
  Play,
  RotateCcw,
  Settings,
  ShieldAlert,
  Trophy,
  User as UserIcon,
} from 'lucide-react';
import { t } from '../i18n/translations';
import {
  ChapterId,
  Difficulty,
  GameSettings,
  Language,
  SaveSlot,
  SyncStatus,
  UserProfile,
} from '../types/game';
import { usePWAInstall } from '../hooks/usePWAInstall';

const LOGO_URL = '/assets/aistudio/Haunted_Dimensions__Blood_Moon_Manor_889d9a7a.png';

interface TitleScreenProps {
  settings: GameSettings;
  saveSlots: Record<string, SaveSlot>;
  hasContinue: boolean;
  isOnline: boolean;
  syncStatus: SyncStatus;
  authUser: User | null;
  profile: UserProfile | null;
  conflictCount: number;
  onStartNewGame: (difficulty: Difficulty, chapter?: ChapterId) => void;
  onContinue: () => void;
  onLoadSlot: (slot: SaveSlot) => void;
  onUpdateSettings: (next: GameSettings) => void;
  onOpenSettings: () => void;
  onOpenCloudAccount: () => void;
  onOpenLeaderboard: () => void;
}

type SubView = 'main' | 'difficulty' | 'chapters' | 'load' | 'language' | 'credits';

export const TitleScreen: React.FC<TitleScreenProps> = ({
  settings,
  saveSlots,
  hasContinue,
  isOnline,
  syncStatus,
  authUser,
  profile,
  conflictCount,
  onStartNewGame,
  onContinue,
  onLoadSlot,
  onUpdateSettings,
  onOpenSettings,
  onOpenCloudAccount,
  onOpenLeaderboard,
}) => {
  const [subView, setSubView] = useState<SubView>('main');
  const { isInstallable, isInstalled, isNativeApp, install } = usePWAInstall();
  const lang = settings.language;
  const isUr = lang === 'ur';

  const setLanguage = (nextLang: Language) => {
    onUpdateSettings({ ...settings, language: nextLang });
    setSubView('main');
  };

  const slotIds = ['auto', 'slot1', 'slot2', 'slot3'];

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      className={`fixed inset-0 z-20 flex flex-col justify-between p-3 sm:p-6 pointer-events-none overflow-y-auto ${isUr ? 'font-urdu' : ''}`}
      style={{
        background:
          'linear-gradient(90deg, rgba(5,6,9,0.95) 0%, rgba(5,6,9,0.75) 42%, rgba(5,6,9,0.32) 100%)',
      }}
    >
      {/* Top Bar: Online/Offline Cloud Sync Status, Cloud Profile, Leaderboard, APK Download & Language Switch */}
      <div className="relative z-10 flex items-center justify-between gap-2 pointer-events-auto shrink-0 flex-wrap">
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs tracking-widest uppercase text-zinc-400">
          <span
            data-testid="connection-badge"
            className={`flex items-center gap-1 px-2 py-1 border bg-[#0b0b10]/90 ${
              isOnline ? 'border-emerald-800/70 text-emerald-300' : 'border-amber-800/70 text-amber-300'
            }`}
          >
            {isOnline ? <Cloud className="w-3.5 h-3.5" /> : <CloudOff className="w-3.5 h-3.5" />}
            <span>
              {isOnline
                ? syncStatus === 'syncing'
                  ? t(lang, 'syncing')
                  : syncStatus === 'synced'
                  ? t(lang, 'synced')
                  : t(lang, 'onlineStatus')
                : t(lang, 'offlineReady')}
            </span>
          </span>

          <button
            type="button"
            data-testid="btn-cloud-account"
            onClick={onOpenCloudAccount}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-[#11131e]/95 hover:bg-rose-950/70 text-zinc-100 border border-zinc-700 hover:border-rose-500/70 transition cursor-pointer"
          >
            <UserIcon className="w-3.5 h-3.5 text-rose-400" />
            <span className="max-w-[110px] truncate">
              {authUser ? profile?.displayName || authUser.displayName || t(lang, 'cloudAccount') : t(lang, 'cloudAccount')}
            </span>
            {conflictCount > 0 && (
              <span className="px-1 bg-amber-600 text-black font-bold text-[9px]">{conflictCount}</span>
            )}
          </button>

          <button
            type="button"
            data-testid="btn-leaderboard"
            onClick={onOpenLeaderboard}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-[#11131e]/95 hover:bg-zinc-900 text-zinc-100 border border-zinc-700/80 transition cursor-pointer"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>{t(lang, 'leaderboard')}</span>
          </button>

          {!isNativeApp && (
            <a
              href="/DIMENSIONS-nightmare.apk"
              download="DIMENSIONS-nightmare.apk"
              className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-900/85 hover:bg-emerald-800 text-zinc-100 border border-emerald-500/50 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t(lang, 'downloadApk')}</span>
            </a>
          )}
          {!isNativeApp && isInstallable && !isInstalled && (
            <button
              type="button"
              onClick={install}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-rose-800/90 hover:bg-rose-700 text-zinc-100 border border-rose-500/40 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t(lang, 'installApp')}</span>
            </button>
          )}
        </div>

        <button
          type="button"
          onClick={() => setLanguage(lang === 'en' ? 'ur' : 'en')}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-[#0d0e14]/90 hover:bg-zinc-900 border border-zinc-700/70 text-[11px] sm:text-xs text-zinc-200 transition cursor-pointer shrink-0"
        >
          <Globe className="w-3.5 h-3.5 text-rose-400" />
          <span>{lang === 'en' ? 'اردو' : 'English'}</span>
        </button>
      </div>

      {/* Landscape Split Showcase: Menu Left + Landscape Key-Art Logo Right */}
      <div className="relative z-10 my-auto py-2 w-full flex flex-col-reverse min-[480px]:flex-row items-center justify-between gap-3 sm:gap-6">
        {/* Left Navigation Column */}
        <div className="w-full max-w-[270px] sm:max-w-[330px] shrink-0 pointer-events-auto">
          <div className="mb-2 sm:mb-3">
            <h1 className="text-lg sm:text-2xl font-display font-black tracking-[0.22em] text-zinc-100">
              {t(lang, 'gameTitle')}
            </h1>
            <p className="text-[10px] sm:text-xs tracking-[0.18em] uppercase text-rose-400/90 mt-0.5">
              {t(lang, 'gameSubtitle')}
            </p>
          </div>

          {subView === 'main' && (
            <nav className="flex flex-col gap-1 sm:gap-1.5">
              {hasContinue && (
                <button
                  type="button"
                  onClick={onContinue}
                  className="flex items-center justify-between px-3.5 py-1.5 sm:py-2.5 bg-rose-900/90 hover:bg-rose-800 border border-rose-500/60 text-zinc-50 font-semibold text-xs sm:text-sm tracking-wider transition cursor-pointer"
                >
                  <span className="flex items-center gap-2.5">
                    <RotateCcw className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    {t(lang, 'continueGame')}
                  </span>
                  <span className="text-xs text-rose-200/80">→</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setSubView('difficulty')}
                className="flex items-center justify-between px-3.5 py-1.5 sm:py-2.5 bg-[#101118]/92 hover:bg-rose-950/70 border border-zinc-800 hover:border-rose-700/70 text-zinc-100 font-medium text-xs sm:text-sm tracking-wider transition cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-rose-500" />
                  {t(lang, 'newGame')}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setSubView('load')}
                className="flex items-center justify-between px-3.5 py-1.5 sm:py-2 bg-[#0d0e14]/90 hover:bg-zinc-900 border border-zinc-800/80 text-zinc-200 text-xs sm:text-sm tracking-wide transition cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <HardDrive className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-zinc-400" />
                  {t(lang, 'loadGame')}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setSubView('chapters')}
                className="flex items-center justify-between px-3.5 py-1.5 sm:py-2 bg-[#0d0e14]/90 hover:bg-zinc-900 border border-zinc-800/80 text-zinc-200 text-xs sm:text-sm tracking-wide transition cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-zinc-400" />
                  {t(lang, 'chapters')}
                </span>
              </button>

              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={onOpenSettings}
                  className="flex items-center gap-2 px-3 py-1.5 sm:py-2 bg-[#0d0e14]/90 hover:bg-zinc-900 border border-zinc-800/80 text-zinc-200 text-xs sm:text-sm transition cursor-pointer"
                >
                  <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-zinc-400" />
                  {t(lang, 'settings')}
                </button>
                <button
                  type="button"
                  onClick={() => setSubView('language')}
                  className="flex items-center gap-2 px-3 py-1.5 sm:py-2 bg-[#0d0e14]/90 hover:bg-zinc-900 border border-zinc-800/80 text-zinc-200 text-xs sm:text-sm transition cursor-pointer"
                >
                  <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-zinc-400" />
                  {t(lang, 'language')}
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSubView('credits')}
                className="flex items-center gap-2.5 px-3.5 py-1.5 sm:py-2 bg-[#0d0e14]/90 hover:bg-zinc-900 border border-zinc-800/80 text-zinc-300 text-xs sm:text-sm transition cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-zinc-400" />
                {t(lang, 'credits')}
              </button>
            </nav>
          )}

          {subView === 'difficulty' && (
            <div className="bg-[#0b0c12]/95 border border-zinc-800 p-3 sm:p-4 space-y-2 max-h-[68vh] overflow-y-auto horror-scroll">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-rose-400">
                {t(lang, 'selectDifficulty')}
              </h2>
              {(['normal', 'hard', 'nightmare'] as Difficulty[]).map((diff) => (
                <button
                  type="button"
                  key={diff}
                  onClick={() => onStartNewGame(diff, 1)}
                  className="w-full text-start p-2 bg-[#12131c] hover:bg-rose-950/60 border border-zinc-800 hover:border-rose-600/70 transition cursor-pointer"
                >
                  <div className="flex items-center justify-between text-zinc-100 text-xs sm:text-sm font-semibold">
                    <span>{t(lang, diff)}</span>
                    {diff === 'nightmare' && <ShieldAlert className="w-4 h-4 text-rose-500" />}
                  </div>
                  <p className="text-[10px] sm:text-[11px] text-zinc-400 mt-0.5">
                    {t(lang, `${diff}Desc` as keyof typeof import('../i18n/translations').UI_TEXT.en)}
                  </p>
                </button>
              ))}
              <button
                type="button"
                onClick={() => setSubView('main')}
                className="w-full py-1 text-xs uppercase tracking-widest text-zinc-400 hover:text-zinc-200 cursor-pointer"
              >
                {t(lang, 'back')}
              </button>
            </div>
          )}

          {subView === 'chapters' && (
            <div className="bg-[#0b0c12]/95 border border-zinc-800 p-3 sm:p-4 space-y-2 max-h-[68vh] overflow-y-auto horror-scroll">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-rose-400">
                {t(lang, 'chapters')}
              </h2>
              {([1, 2, 3] as ChapterId[]).map((ch) => (
                <button
                  type="button"
                  key={ch}
                  onClick={() => onStartNewGame(settings.difficulty, ch)}
                  className="w-full text-start p-2 bg-[#12131c] hover:bg-rose-950/60 border border-zinc-800 hover:border-rose-600/70 transition cursor-pointer flex items-center gap-2.5"
                >
                  <img
                    src={`/assets/chapter${ch}.jpg`}
                    alt={`Chapter ${ch}`}
                    className="w-14 h-9 object-cover border border-zinc-700 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between text-zinc-100 font-semibold text-xs">
                      <span className="truncate">{t(lang, `chapter${ch}Title` as 'chapter1Title')}</span>
                      <span className="text-[10px] text-emerald-400 shrink-0 ml-1">{t(lang, 'unlocked')}</span>
                    </div>
                    <p className="text-[10px] text-zinc-400 mt-0.5 line-clamp-2">
                      {t(lang, `chapter${ch}Desc` as 'chapter1Desc')}
                    </p>
                  </div>
                </button>
              ))}
              <button
                type="button"
                onClick={() => setSubView('main')}
                className="w-full py-1 text-xs uppercase tracking-widest text-zinc-400 hover:text-zinc-200 cursor-pointer"
              >
                {t(lang, 'back')}
              </button>
            </div>
          )}

          {subView === 'load' && (
            <div className="bg-[#0b0c12]/95 border border-zinc-800 p-3 sm:p-4 space-y-2 max-h-[68vh] overflow-y-auto horror-scroll">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-rose-400">
                {t(lang, 'loadGame')}
              </h2>
              {slotIds.map((id) => {
                const slot = saveSlots[id];
                return (
                  <button
                    type="button"
                    key={id}
                    disabled={!slot}
                    onClick={() => slot && onLoadSlot(slot)}
                    className="w-full text-start p-2 bg-[#12131c] enabled:hover:bg-rose-950/60 border border-zinc-800 disabled:opacity-45 transition cursor-pointer disabled:cursor-not-allowed"
                  >
                    <div className="flex items-center justify-between text-xs text-zinc-100">
                      <span>{id === 'auto' ? t(lang, 'autoSave') : `${t(lang, 'slot')} ${id.replace('slot', '')}`}</span>
                      {slot && (
                        <span className="text-[10px] text-rose-400">
                          Ch. {slot.chapter} · {slot.difficulty.toUpperCase()}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-zinc-400 mt-0.5">
                      {slot ? `${t(lang, 'savedAt')}: ${slot.savedAt}` : t(lang, 'emptySlot')}
                    </p>
                  </button>
                );
              })}
              <button
                type="button"
                onClick={() => setSubView('main')}
                className="w-full py-1 text-xs uppercase tracking-widest text-zinc-400 hover:text-zinc-200 cursor-pointer"
              >
                {t(lang, 'back')}
              </button>
            </div>
          )}

          {subView === 'language' && (
            <div className="bg-[#0b0c12]/95 border border-zinc-800 p-3 sm:p-4 space-y-2">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-rose-400">
                {t(lang, 'language')}
              </h2>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`w-full p-2 border text-start text-xs sm:text-sm cursor-pointer ${
                  lang === 'en' ? 'border-rose-500 bg-rose-950/50 text-white' : 'border-zinc-800 bg-[#12131c] text-zinc-300'
                }`}
              >
                English (Left-to-Right)
              </button>
              <button
                type="button"
                onClick={() => setLanguage('ur')}
                className={`w-full p-2 border text-start text-xs sm:text-sm font-urdu cursor-pointer ${
                  lang === 'ur' ? 'border-rose-500 bg-rose-950/50 text-white' : 'border-zinc-800 bg-[#12131c] text-zinc-300'
                }`}
              >
                اردو (دائیں سے بائیں — مکمل ترجمہ)
              </button>
              <button
                type="button"
                onClick={() => setSubView('main')}
                className="w-full py-1 text-xs uppercase tracking-widest text-zinc-400 hover:text-zinc-200 cursor-pointer"
              >
                {t(lang, 'back')}
              </button>
            </div>
          )}

          {subView === 'credits' && (
            <div className="bg-[#0b0c12]/95 border border-zinc-800 p-3 sm:p-4 space-y-2">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-rose-400">
                {t(lang, 'credits')}
              </h2>
              <p className="text-[11px] sm:text-xs leading-relaxed text-zinc-300">{t(lang, 'creditsBody')}</p>
              <button
                type="button"
                onClick={() => setSubView('main')}
                className="w-full py-1 text-xs uppercase tracking-widest text-zinc-400 hover:text-zinc-200 cursor-pointer"
              >
                {t(lang, 'back')}
              </button>
            </div>
          )}
        </div>

        {/* Right Landscape Logo Showcase (Always visible across all screen widths) */}
        <div className="flex flex-1 w-full min-[480px]:w-auto items-center justify-center min-[480px]:justify-end pointer-events-none">
          <div className="relative w-full max-w-[320px] min-[480px]:max-w-[660px] aspect-video border border-rose-900/50 bg-[#050609] shadow-2xl overflow-hidden">
            <img
              src={LOGO_URL}
              alt="DIMENSIONS: The Nightmare Beyond Reality"
              className="w-full h-full object-cover"
            />
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background:
                  'radial-gradient(circle at center, transparent 58%, rgba(5,6,9,0.7) 100%)',
              }}
            />
          </div>
        </div>
      </div>

      {/* Bottom Flat Control Hint Line */}
      <div className="relative z-10 text-[10px] sm:text-[11px] tracking-wider text-zinc-500 pointer-events-none shrink-0">
        {t(lang, 'controlHint')}
      </div>
    </div>
  );
};
