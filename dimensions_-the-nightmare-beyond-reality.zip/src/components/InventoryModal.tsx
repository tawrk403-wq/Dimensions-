import React, { useState } from 'react';
import { BookOpen, FlaskConical, Key, RotateCw, X } from 'lucide-react';
import { BOTTLES, ITEMS_CATALOG, LETTERS } from '../data/gameData';
import { audioEngine } from '../engine/audio';
import { t } from '../i18n/translations';
import { GameProgressState, InventoryItem, Language } from '../types/game';

interface InventoryModalProps {
  progress: GameProgressState;
  lang: Language;
  initialTab?: 'items' | 'bottles' | 'letters';
  initialLetterId?: string | null;
  onUseSupply: (itemId: string) => void;
  onCombineItems: (itemA: string, itemB: string, resultId: string) => void;
  onClose: () => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({
  progress,
  lang,
  initialTab = 'items',
  initialLetterId = null,
  onUseSupply,
  onCombineItems,
  onClose,
}) => {
  const isUr = lang === 'ur';
  const [tab, setTab] = useState<'items' | 'bottles' | 'letters'>(initialTab);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(
    progress.inventory[0] || null
  );
  const [selectedLetterId, setSelectedLetterId] = useState<string | null>(
    initialLetterId || progress.collectedLetterIds[0] || null
  );
  const [inspectAngle, setInspectAngle] = useState(0);

  const collectedBottles = BOTTLES.filter((b) => progress.collectedBottleIds.includes(b.id));
  const collectedLetters = LETTERS.filter((l) => progress.collectedLetterIds.includes(l.id));
  const activeLetter = LETTERS.find((l) => l.id === selectedLetterId) || null;

  const canCombine =
    selectedItem?.combineWith &&
    selectedItem.combineResult &&
    progress.inventory.some((i) => i.id === selectedItem.combineWith);

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      onPointerDown={(e) => e.stopPropagation()}
      className={`fixed inset-0 z-40 flex items-center justify-center bg-[#040407]/88 p-3 sm:p-6 ${isUr ? 'font-urdu' : ''}`}
    >
      <div className="w-full max-w-3xl max-h-[88vh] flex flex-col bg-[#0c0d14] border border-zinc-700/80 overflow-hidden">
        {/* Header & Tabs */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800 bg-[#08090e]">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setTab('items')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm border cursor-pointer ${
                tab === 'items'
                  ? 'bg-rose-900/70 border-rose-500 text-white'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400'
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              <span>{t(lang, 'items')} ({progress.inventory.length})</span>
            </button>
            <button
              onClick={() => setTab('bottles')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm border cursor-pointer ${
                tab === 'bottles'
                  ? 'bg-rose-900/70 border-rose-500 text-white'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400'
              }`}
            >
              <FlaskConical className="w-3.5 h-3.5" />
              <span>{t(lang, 'bottles')} ({collectedBottles.length}/9)</span>
            </button>
            <button
              onClick={() => setTab('letters')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm border cursor-pointer ${
                tab === 'letters'
                  ? 'bg-rose-900/70 border-rose-500 text-white'
                  : 'bg-zinc-900 border-zinc-800 text-zinc-400'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>{t(lang, 'clues')} ({collectedLetters.length})</span>
            </button>
          </div>

          <button onClick={onClose} className="p-1.5 text-zinc-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto horror-scroll p-4">
          {tab === 'items' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                {progress.inventory.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setSelectedItem(item);
                      setInspectAngle(0);
                    }}
                    className={`w-full text-start p-3 border transition cursor-pointer flex items-center justify-between ${
                      selectedItem?.id === item.id
                        ? 'bg-rose-950/40 border-rose-500 text-white'
                        : 'bg-[#12131c] border-zinc-800 text-zinc-300'
                    }`}
                  >
                    <span className="text-sm font-medium">
                      {isUr ? item.nameUr : item.nameEn}
                    </span>
                    <span className="text-xs text-zinc-400 tabular-nums">×{item.quantity}</span>
                  </button>
                ))}
              </div>

              {selectedItem && (
                <div className="bg-[#08090e] border border-zinc-800 p-4 flex flex-col justify-between space-y-4">
                  <div className="flex flex-col items-center">
                    <div
                      className="w-24 h-24 rounded-full border border-zinc-700 bg-[#12131c] flex items-center justify-center mb-3 transition-transform duration-200"
                      style={{ transform: `rotateY(${inspectAngle}deg)` }}
                    >
                      <span
                        className="text-3xl font-display"
                        style={{ color: selectedItem.liquidColor || '#f59e0b' }}
                      >
                        {selectedItem.symbol || '❖'}
                      </span>
                    </div>
                    <button
                      onClick={() => setInspectAngle((a) => a + 45)}
                      className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-200 cursor-pointer"
                    >
                      <RotateCw className="w-3 h-3" />
                      <span>{t(lang, 'examine')}</span>
                    </button>
                  </div>

                  <div>
                    <h3 className="text-base font-semibold text-zinc-100">
                      {isUr ? selectedItem.nameUr : selectedItem.nameEn}
                    </h3>
                    <p className="text-xs text-zinc-400 mt-1.5">
                      {isUr ? selectedItem.descUr : selectedItem.descEn}
                    </p>
                    {selectedItem.clueEn && (
                      <p className="text-xs text-amber-300 mt-2 p-2 bg-amber-950/30 border border-amber-800/50">
                        {isUr ? selectedItem.clueUr : selectedItem.clueEn}
                      </p>
                    )}
                  </div>

                  <div className="flex gap-2">
                    {selectedItem.consumable && (
                      <button
                        onClick={() => {
                          onUseSupply(selectedItem.id);
                          audioEngine.playSfx('heal');
                        }}
                        className="flex-1 py-2 bg-emerald-800 hover:bg-emerald-700 text-xs font-semibold text-white cursor-pointer"
                      >
                        {t(lang, 'use')}
                      </button>
                    )}
                    {canCombine && selectedItem.combineWith && selectedItem.combineResult && (
                      <button
                        onClick={() => {
                          onCombineItems(
                            selectedItem.id,
                            selectedItem.combineWith!,
                            selectedItem.combineResult!
                          );
                          audioEngine.playSfx('unlock');
                        }}
                        className="flex-1 py-2 bg-rose-800 hover:bg-rose-700 text-xs font-semibold text-white cursor-pointer"
                      >
                        {t(lang, 'combine')} →{' '}
                        {isUr
                          ? ITEMS_CATALOG[selectedItem.combineResult].nameUr
                          : ITEMS_CATALOG[selectedItem.combineResult].nameEn}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {tab === 'bottles' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {BOTTLES.map((b) => {
                const owned = progress.collectedBottleIds.includes(b.id);
                return (
                  <div
                    key={b.id}
                    className={`p-3 border ${
                      owned
                        ? 'bg-[#12131c] border-zinc-700'
                        : 'bg-[#08090d] border-zinc-900 opacity-45'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xl" style={{ color: b.liquidColor }}>
                        {b.symbol}
                      </span>
                      <span className="text-[11px] text-zinc-500">Door {b.doorNumber}</span>
                    </div>
                    <h4 className="text-sm font-semibold text-zinc-100">
                      {owned ? (isUr ? b.nameUr : b.nameEn) : '???'}
                    </h4>
                    {owned && (
                      <>
                        <p className="text-xs text-zinc-400 mt-1">{isUr ? b.labelUr : b.labelEn}</p>
                        <p className="text-xs text-amber-300 mt-2">
                          {isUr ? b.secretHintUr : b.secretHintEn}
                        </p>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'letters' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                {collectedLetters.map((ltr) => (
                  <button
                    key={ltr.id}
                    onClick={() => {
                      setSelectedLetterId(ltr.id);
                      audioEngine.playSfx('paper');
                    }}
                    className={`w-full text-start p-2.5 border text-xs cursor-pointer ${
                      selectedLetterId === ltr.id
                        ? 'bg-rose-950/50 border-rose-500 text-white'
                        : 'bg-[#12131c] border-zinc-800 text-zinc-300'
                    }`}
                  >
                    <div className="font-semibold">{isUr ? ltr.titleUr : ltr.titleEn}</div>
                    <div className="text-[10px] text-zinc-500">
                      {isUr ? ltr.authorUr : ltr.authorEn}
                    </div>
                  </button>
                ))}
                {collectedLetters.length === 0 && (
                  <p className="text-xs text-zinc-500">
                    {isUr ? 'ابھی تک کوئی خط نہیں ملا۔' : 'No letters discovered yet.'}
                  </p>
                )}
              </div>

              {activeLetter && (
                <div className="sm:col-span-2 bg-[#16130f] border border-amber-900/50 p-5 space-y-3">
                  <div className="border-b border-amber-900/40 pb-2">
                    <h3 className="text-base font-display font-bold text-amber-200">
                      {isUr ? activeLetter.titleUr : activeLetter.titleEn}
                    </h3>
                    <p className="text-xs text-amber-400/70">
                      — {isUr ? activeLetter.authorUr : activeLetter.authorEn}
                    </p>
                  </div>
                  <p className="text-sm leading-relaxed text-amber-100/90">
                    {isUr ? activeLetter.bodyUr : activeLetter.bodyEn}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
