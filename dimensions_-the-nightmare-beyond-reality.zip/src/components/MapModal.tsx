import React from 'react';
import { X } from 'lucide-react';
import { MAP_ROOMS } from '../data/gameData';
import { t } from '../i18n/translations';
import { GameProgressState, Language, PlayerHudState } from '../types/game';

interface MapModalProps {
  progress: GameProgressState;
  hud: PlayerHudState;
  lang: Language;
  onClose: () => void;
}

export const MapModal: React.FC<MapModalProps> = ({ progress, hud, lang, onClose }) => {
  const isUr = lang === 'ur';
  const rooms = MAP_ROOMS.filter((r) => r.chapter === progress.chapter);

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      onPointerDown={(e) => e.stopPropagation()}
      className={`fixed inset-0 z-40 flex items-center justify-center bg-[#040407]/88 p-4 ${isUr ? 'font-urdu' : ''}`}
    >
      <div className="w-full max-w-2xl bg-[#0c0d14] border border-zinc-700/80 p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
          <h2 className="text-base font-display font-bold text-rose-400">
            {t(lang, 'map')} — {t(lang, `chapter${progress.chapter}Title` as 'chapter1Title')}
          </h2>
          <button onClick={onClose} className="p-1 text-zinc-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Interactive SVG Fog-of-War Floorplan */}
        <div className="relative bg-[#07080c] border border-zinc-800 aspect-[4/3] w-full overflow-hidden">
          <svg viewBox="-38 -42 76 80" className="w-full h-full">
            {rooms.map((room) => {
              const discovered = progress.discoveredRoomIds.includes(room.id);
              if (room.isSecret && !discovered) return null;
              return (
                <g key={room.id}>
                  <rect
                    x={room.x - room.w / 2}
                    y={room.z - room.d / 2}
                    width={room.w}
                    height={room.d}
                    fill={discovered ? '#151824' : '#0b0c12'}
                    stroke={discovered ? '#9f1239' : '#27272a'}
                    strokeWidth="0.45"
                    strokeDasharray={discovered ? undefined : '1.2 1.2'}
                  />
                  <text
                    x={room.x}
                    y={room.z + 0.6}
                    textAnchor="middle"
                    fill={discovered ? '#e4e4e7' : '#52525b'}
                    fontSize="2.1"
                  >
                    {discovered ? (isUr ? room.nameUr : room.nameEn) : t(lang, 'unknownArea')}
                  </text>
                </g>
              );
            })}

            {/* Player Indicator Marker */}
            <g
              transform={`translate(${hud.playerPos.x}, ${hud.playerPos.z}) rotate(${
                (-hud.playerPos.yaw * 180) / Math.PI
              })`}
            >
              <polygon points="0,-2.4 1.4,1.6 0,0.8 -1.4,1.6" fill="#38bdf8" />
            </g>
          </svg>
        </div>

        <div className="flex items-center justify-between text-xs text-zinc-400">
          <span>
            {t(lang, 'discoveredRooms')}: {rooms.filter((r) => progress.discoveredRoomIds.includes(r.id)).length} / {rooms.length}
          </span>
          <span className="text-sky-400">▲ {t(lang, 'yourPosition')}</span>
        </div>
      </div>
    </div>
  );
};
