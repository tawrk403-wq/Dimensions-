import React, { useState } from 'react';
import {
  AlertTriangle,
  Award,
  BarChart3,
  CheckCircle2,
  Cloud,
  CloudOff,
  LogOut,
  Mail,
  RefreshCw,
  ShieldCheck,
  User as UserIcon,
  X,
} from 'lucide-react';
import { User } from 'firebase/auth';
import { t } from '../i18n/translations';
import {
  ACHIEVEMENTS,
  loginWithEmail,
  loginWithGoogle,
  logoutAccount,
  registerWithEmail,
  resendVerificationEmail,
  sendPasswordReset,
} from '../firebase/syncService';
import { getPendingSyncSlots } from '../state/saveSystem';
import { Language, SaveConflictInfo, SyncStatus, UserProfile } from '../types/game';

interface CloudAccountModalProps {
  lang: Language;
  authUser: User | null;
  profile: UserProfile | null;
  isOnline: boolean;
  syncStatus: SyncStatus;
  conflicts: SaveConflictInfo[];
  onSyncNow: () => Promise<void>;
  onResolveConflict: (conflict: SaveConflictInfo, choice: 'local' | 'cloud') => Promise<void>;
  onProfileUpdated: (profile: UserProfile) => void;
  onClose: () => void;
}

function formatDuration(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}m ${rem}s`;
}

function mapFirebaseAuthError(err: unknown, isUr: boolean): string {
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes('auth/operation-not-allowed')) {
    return isUr
      ? 'فائر بیس کنسول میں Email/Password سائن ان فعال نہیں ہے۔ گوگل سائن ان استعمال کریں یا Firebase Authentication میں Email/Password فعال کریں۔'
      : 'Email/Password sign-in is not yet enabled in Firebase Console (Authentication -> Sign-in method). You can use Google Sign-In now or enable Email/Password in Firebase Console.';
  }
  if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password') || msg.includes('auth/user-not-found')) {
    return isUr ? 'غلط ای میل یا پاس ورڈ۔' : 'Invalid email or password.';
  }
  if (msg.includes('auth/email-already-in-use')) {
    return isUr ? 'یہ ای میل پہلے سے رجسٹرڈ ہے۔ سائن ان کریں۔' : 'An account with this email already exists.';
  }
  if (msg.includes('auth/weak-password')) {
    return isUr ? 'پاس ورڈ کم از کم 6 حروف کا ہونا چاہیے۔' : 'Password must be at least 6 characters.';
  }
  if (msg.includes('auth/popup-closed-by-user')) {
    return isUr ? 'گوگل سائن ان ونڈو بند کر دی گئی۔' : 'Google sign-in window was closed.';
  }
  if (msg.includes('auth/network-request-failed')) {
    return isUr ? 'انٹرنیٹ کنکشن دستیاب نہیں ہے۔' : 'Network unavailable. Story remains playable offline.';
  }
  return msg;
}

export const CloudAccountModal: React.FC<CloudAccountModalProps> = ({
  lang,
  authUser,
  profile,
  isOnline,
  syncStatus,
  conflicts,
  onSyncNow,
  onResolveConflict,
  onProfileUpdated,
  onClose,
}) => {
  const isUr = lang === 'ur';
  const [tab, setTab] = useState<'account' | 'stats' | 'achievements'>('account');
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  const pendingCount = getPendingSyncSlots().length;

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOnline) {
      setErrorMsg(isUr ? 'اکاؤنٹ میں لاگ ان کے لیے انٹرنیٹ درکار ہے۔' : 'Internet connection required to sign in.');
      return;
    }
    setBusy(true);
    setErrorMsg(null);
    setInfoMsg(null);
    try {
      const nextProfile =
        authMode === 'signup'
          ? await registerWithEmail(email, password, displayName)
          : await loginWithEmail(email, password);
      onProfileUpdated(nextProfile);
    } catch (err) {
      setErrorMsg(mapFirebaseAuthError(err, isUr));
    } finally {
      setBusy(false);
    }
  };

  const handleGoogleSignIn = async () => {
    if (!isOnline) {
      setErrorMsg(isUr ? 'گوگل لاگ ان کے لیے انٹرنیٹ درکار ہے۔' : 'Internet connection required for Google Sign-In.');
      return;
    }
    setBusy(true);
    setErrorMsg(null);
    setInfoMsg(null);
    try {
      const nextProfile = await loginWithGoogle();
      onProfileUpdated(nextProfile);
    } catch (err) {
      setErrorMsg(mapFirebaseAuthError(err, isUr));
    } finally {
      setBusy(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!email.trim()) {
      setErrorMsg(isUr ? 'پہلے اپنا ای میل درج کریں۔' : 'Enter your email address first.');
      return;
    }
    setBusy(true);
    setErrorMsg(null);
    try {
      await sendPasswordReset(email);
      setInfoMsg(t(lang, 'resetSent'));
    } catch (err) {
      setErrorMsg(mapFirebaseAuthError(err, isUr));
    } finally {
      setBusy(false);
    }
  };

  const handleResendVerification = async () => {
    setBusy(true);
    setErrorMsg(null);
    try {
      await resendVerificationEmail();
      setInfoMsg(isUr ? 'تصدیقی ای میل بھیج دی گئی ہے۔' : 'Verification email sent.');
    } catch (err) {
      setErrorMsg(mapFirebaseAuthError(err, isUr));
    } finally {
      setBusy(false);
    }
  };

  const stats = profile?.stats;
  const unlockedAch = new Set(profile?.achievements || []);

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      onPointerDown={(e) => e.stopPropagation()}
      className={`fixed inset-0 z-50 flex items-center justify-center bg-[#040407]/90 p-3 sm:p-4 ${isUr ? 'font-urdu' : ''}`}
    >
      <div className="w-full max-w-xl max-h-[90vh] flex flex-col bg-[#0c0d14] border border-zinc-700/80 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800 bg-[#08090e]">
          <div className="flex items-center gap-2.5">
            {isOnline ? (
              <Cloud className="w-4 h-4 text-emerald-400" />
            ) : (
              <CloudOff className="w-4 h-4 text-amber-400" />
            )}
            <span className="text-sm font-display font-bold tracking-widest text-rose-400 uppercase">
              {t(lang, 'cloudAccount')}
            </span>
            <span
              className={`text-[10px] px-2 py-0.5 border uppercase tracking-wider ${
                isOnline
                  ? 'border-emerald-700/60 bg-emerald-950/50 text-emerald-300'
                  : 'border-amber-700/60 bg-amber-950/50 text-amber-300'
              }`}
            >
              {isOnline ? t(lang, 'onlineStatus') : t(lang, 'offlineStatus')}
            </span>
          </div>
          <button
            type="button"
            data-testid="cloud-modal-close"
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 border-b border-zinc-800 bg-[#090a10] text-xs">
          <button
            type="button"
            onClick={() => setTab('account')}
            className={`py-2.5 flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
              tab === 'account'
                ? 'border-rose-500 text-white bg-[#11121b]'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <UserIcon className="w-3.5 h-3.5" />
            <span>{t(lang, 'cloudAccount')}</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('stats')}
            className={`py-2.5 flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
              tab === 'stats'
                ? 'border-rose-500 text-white bg-[#11121b]'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>{t(lang, 'stats')}</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('achievements')}
            className={`py-2.5 flex items-center justify-center gap-1.5 border-b-2 transition cursor-pointer ${
              tab === 'achievements'
                ? 'border-rose-500 text-white bg-[#11121b]'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>{t(lang, 'achievements')}</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto horror-scroll p-4 space-y-3 text-xs">
          {/* Conflict Resolution Banner */}
          {conflicts.length > 0 && (
            <div className="p-3 bg-amber-950/50 border border-amber-500/70 space-y-2.5">
              <div className="flex items-center gap-2 text-amber-300 font-semibold">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{t(lang, 'conflictTitle')}</span>
              </div>
              <p className="text-[11px] text-zinc-300">{t(lang, 'conflictDesc')}</p>
              {conflicts.map((c) => (
                <div key={c.slotId} className="p-2.5 bg-[#0b0c12] border border-zinc-800 space-y-2">
                  <div className="flex justify-between text-[11px] text-zinc-200">
                    <span className="font-semibold uppercase">{c.slotId}</span>
                    <span>
                      Local: Ch.{c.localSlot.chapter} ({c.localSlot.progress.collectedBottleIds.length}B) · Cloud: Ch.
                      {c.cloudSlot.chapter} ({c.cloudSlot.progress.collectedBottleIds.length}B)
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => onResolveConflict(c, 'local')}
                      className="py-1.5 bg-rose-900/80 hover:bg-rose-800 border border-rose-500/60 text-white cursor-pointer"
                    >
                      {t(lang, 'keepLocal')}
                    </button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => onResolveConflict(c, 'cloud')}
                      className="py-1.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-600 text-zinc-100 cursor-pointer"
                    >
                      {t(lang, 'useCloud')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {errorMsg && (
            <div className="p-2.5 bg-rose-950/70 border border-rose-600/70 text-rose-200 text-[11px]">
              {errorMsg}
            </div>
          )}
          {infoMsg && (
            <div className="p-2.5 bg-emerald-950/60 border border-emerald-600/60 text-emerald-200 text-[11px]">
              {infoMsg}
            </div>
          )}

          {tab === 'account' && !authUser && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('signin');
                    setErrorMsg(null);
                  }}
                  className={`py-2 border text-xs font-semibold cursor-pointer ${
                    authMode === 'signin'
                      ? 'bg-rose-900/70 border-rose-500 text-white'
                      : 'bg-[#12131c] border-zinc-800 text-zinc-400'
                  }`}
                >
                  {t(lang, 'signIn')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode('signup');
                    setErrorMsg(null);
                  }}
                  className={`py-2 border text-xs font-semibold cursor-pointer ${
                    authMode === 'signup'
                      ? 'bg-rose-900/70 border-rose-500 text-white'
                      : 'bg-[#12131c] border-zinc-800 text-zinc-400'
                  }`}
                >
                  {t(lang, 'signUp')}
                </button>
              </div>

              <form onSubmit={handleEmailAuth} className="space-y-2.5">
                {authMode === 'signup' && (
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">{t(lang, 'displayName')}</label>
                    <input
                      type="text"
                      required
                      minLength={2}
                      maxLength={32}
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Survivor"
                      className="w-full px-3 py-2 bg-[#12131c] border border-zinc-700 text-zinc-100 focus:outline-none focus:border-rose-500"
                    />
                  </div>
                )}
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">{t(lang, 'email')}</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2 bg-[#12131c] border border-zinc-700 text-zinc-100 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">{t(lang, 'password')}</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••"
                    className="w-full px-3 py-2 bg-[#12131c] border border-zinc-700 text-zinc-100 focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div className="flex items-center justify-between gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={busy || !isOnline}
                    className="flex-1 py-2.5 bg-rose-900/90 hover:bg-rose-800 disabled:opacity-50 border border-rose-500/70 text-white font-semibold cursor-pointer"
                  >
                    {authMode === 'signin' ? t(lang, 'signIn') : t(lang, 'signUp')}
                  </button>
                  {authMode === 'signin' && (
                    <button
                      type="button"
                      disabled={busy || !isOnline}
                      onClick={handleForgotPassword}
                      className="px-3 py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 cursor-pointer"
                    >
                      {t(lang, 'forgotPassword')}
                    </button>
                  )}
                </div>
              </form>

              <div className="relative flex items-center py-1">
                <div className="flex-grow border-t border-zinc-800" />
                <span className="px-2 text-[10px] uppercase tracking-widest text-zinc-500">OR</span>
                <div className="flex-grow border-t border-zinc-800" />
              </div>

              <button
                type="button"
                disabled={busy || !isOnline}
                onClick={handleGoogleSignIn}
                className="w-full py-2.5 bg-[#151722] hover:bg-zinc-800 disabled:opacity-50 border border-zinc-600 text-zinc-100 font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>{t(lang, 'googleSignIn')}</span>
              </button>

              {pendingCount > 0 && (
                <div className="p-2 bg-[#11121a] border border-zinc-800 text-[11px] text-amber-300">
                  {pendingCount} local save(s) queued — sign in when online to sync across devices.
                </div>
              )}
            </div>
          )}

          {tab === 'account' && authUser && (
            <div className="space-y-3">
              <div className="p-3 bg-[#12131c] border border-zinc-800 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-zinc-100 truncate">
                    {profile?.displayName || authUser.displayName || 'Survivor'}
                  </div>
                  <div className="text-[11px] text-zinc-400 truncate flex items-center gap-1.5 mt-0.5">
                    <Mail className="w-3 h-3 shrink-0" />
                    <span>{authUser.email}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => logoutAccount()}
                  className="px-3 py-1.5 bg-zinc-900 hover:bg-rose-950/70 border border-zinc-700 text-zinc-300 flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t(lang, 'signOut')}</span>
                </button>
              </div>

              {authUser.email && !authUser.emailVerified && authUser.providerData.some((p) => p.providerId === 'password') && (
                <div className="p-2.5 bg-amber-950/40 border border-amber-700/60 flex items-center justify-between gap-2 text-[11px]">
                  <span className="text-amber-300">{t(lang, 'emailNotVerified')}</span>
                  <button
                    type="button"
                    disabled={busy || !isOnline}
                    onClick={handleResendVerification}
                    className="px-2.5 py-1 bg-amber-900/70 hover:bg-amber-800 border border-amber-500/60 text-white cursor-pointer"
                  >
                    {t(lang, 'resendVerify')}
                  </button>
                </div>
              )}

              <div className="p-3 bg-[#10111a] border border-zinc-800 flex items-center justify-between gap-2">
                <div>
                  <div className="text-zinc-200 font-semibold">
                    {syncStatus === 'syncing'
                      ? t(lang, 'syncing')
                      : syncStatus === 'synced'
                      ? t(lang, 'synced')
                      : syncStatus === 'offline'
                      ? t(lang, 'offlineStatus')
                      : t(lang, 'syncError')}
                  </div>
                  <div className="text-[11px] text-zinc-400 mt-0.5">
                    {pendingCount > 0
                      ? `${pendingCount} pending local slot(s)`
                      : isUr
                      ? 'آپ کی تمام پیش رفت محفوظ ہے۔'
                      : 'Saves stay playable offline and auto-sync when online.'}
                  </div>
                </div>
                <button
                  type="button"
                  disabled={!isOnline || syncStatus === 'syncing'}
                  onClick={() => onSyncNow()}
                  className="px-3 py-1.5 bg-emerald-900/80 hover:bg-emerald-800 disabled:opacity-45 border border-emerald-500/60 text-white flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${syncStatus === 'syncing' ? 'animate-spin' : ''}`} />
                  <span>{t(lang, 'syncNow')}</span>
                </button>
              </div>
            </div>
          )}

          {tab === 'stats' && (
            <div className="space-y-2.5">
              {!profile ? (
                <div className="p-4 bg-[#12131c] border border-zinc-800 text-center text-zinc-400">
                  {isUr
                    ? 'آن لائن اعداد و شمار دیکھنے کے لیے اپنے اکاؤنٹ میں لاگ ان کریں۔'
                    : 'Sign in on the Account tab to sync and track persistent career statistics.'}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {[
                    ['Play Time', formatDuration(stats?.totalPlayTimeSec || 0)],
                    ['Runs Completed', String(stats?.runsCompleted || 0)],
                    ['Best Bottles', `${stats?.bestBottles || 0} / 9`],
                    ['Best Letters', `${stats?.bestLetters || 0} / 13`],
                    ['Truth Clues', String(stats?.bestTruthClues || 0)],
                    ['Puzzles Solved', String(stats?.puzzlesSolved || 0)],
                    ['Bosses Banished', String(stats?.bossesDefeated || 0)],
                    ['Deaths', String(stats?.deaths || 0)],
                    ['Highest Chapter', `Chapter ${stats?.chaptersReached || 1}`],
                    ['Endings Unlocked', `${stats?.endingsUnlocked?.length || 0} / 5`],
                  ].map(([label, val]) => (
                    <div key={label} className="p-2.5 bg-[#12131c] border border-zinc-800">
                      <div className="text-[10px] uppercase tracking-wider text-zinc-400">{label}</div>
                      <div className="text-sm font-semibold text-zinc-100 mt-0.5">{val}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {tab === 'achievements' && (
            <div className="space-y-2">
              {ACHIEVEMENTS.map((ach) => {
                const isUnlocked = unlockedAch.has(ach.id);
                return (
                  <div
                    key={ach.id}
                    className={`p-2.5 border flex items-start gap-2.5 ${
                      isUnlocked
                        ? 'bg-emerald-950/30 border-emerald-600/60 text-zinc-100'
                        : 'bg-[#11121a] border-zinc-800/80 text-zinc-400 opacity-75'
                    }`}
                  >
                    {isUnlocked ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <Award className="w-4 h-4 text-zinc-600 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="font-semibold text-xs">{isUr ? ach.titleUr : ach.titleEn}</div>
                      <div className="text-[11px] text-zinc-400 mt-0.5">{isUr ? ach.descUr : ach.descEn}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
