import React, { useEffect, useState } from 'react';
import { RefreshCw, Trophy, X } from 'lucide-react';
import { t } from '../i18n/translations';
import { fetchLeaderboard } from '../firebase/syncService';
import { Language, LeaderboardEntry } from '../types/game';

interface LeaderboardModalProps {
  lang: Language;
  currentUid?: string;
  isOnline: boolean;
  onClose: () => void;
}

function formatSec(sec: number): string {
  const s = Math.max(0, Math.round(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${rem.toString().padStart(2, '0')}`;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  lang,
  currentUid,
  isOnline,
  onClose,
}) => {
  const isUr = lang === 'ur';
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    if (!isOnline) {
      setLoading(false);
      setError(isUr ? 'لیڈر بورڈ دیکھنے کے لیے انٹرنیٹ درکار ہے۔' : 'Connect to the internet to load global rankings.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const list = await fetchLeaderboard(25);
      setEntries(list);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load leaderboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOnline]);

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      onPointerDown={(e) => e.stopPropagation()}
      className={`fixed inset-0 z-50 flex items-center justify-center bg-[#040407]/90 p-3 sm:p-4 ${isUr ? 'font-urdu' : ''}`}
    >
      <div className="w-full max-w-2xl max-h-[88vh] flex flex-col bg-[#0c0d14] border border-zinc-700/80 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800 bg-[#08090e]">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span className="text-sm font-display font-bold tracking-widest text-rose-400 uppercase">
              {t(lang, 'leaderboard')}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={load}
              disabled={loading}
              className="p-1 text-zinc-400 hover:text-white cursor-pointer"
              title="Refresh"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              type="button"
              data-testid="leaderboard-modal-close"
              onClick={onClose}
              className="p-1 text-zinc-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto horror-scroll p-3 sm:p-4">
          {loading ? (
            <div className="py-10 text-center text-xs text-zinc-400">Loading global survivors...</div>
          ) : error ? (
            <div className="p-4 bg-rose-950/50 border border-rose-700/60 text-xs text-rose-200 text-center">
              {error}
            </div>
          ) : entries.length === 0 ? (
            <div className="py-10 text-center text-xs text-zinc-400">{t(lang, 'noLeaderboard')}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-zinc-800 text-[10px] uppercase tracking-wider text-zinc-400">
                    <th className="py-2 px-2">{t(lang, 'rank')}</th>
                    <th className="py-2 px-2">{t(lang, 'player')}</th>
                    <th className="py-2 px-2">{t(lang, 'ending')}</th>
                    <th className="py-2 px-2">Diff</th>
                    <th className="py-2 px-2">{t(lang, 'bottles')}</th>
                    <th className="py-2 px-2">{t(lang, 'endingTime')}</th>
                    <th className="py-2 px-2 text-right">{t(lang, 'score')}</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((entry, idx) => {
                    const isMe = currentUid && entry.uid === currentUid;
                    return (
                      <tr
                        key={entry.uid}
                        className={`border-b border-zinc-800/60 ${
                          isMe ? 'bg-rose-950/45 text-white' : 'text-zinc-200 hover:bg-[#12131c]'
                        }`}
                      >
                        <td className="py-2 px-2 font-semibold text-amber-400">#{idx + 1}</td>
                        <td className="py-2 px-2 font-medium max-w-[140px] truncate">{entry.displayName}</td>
                        <td className="py-2 px-2 uppercase text-[10px] text-rose-300">{entry.endingId}</td>
                        <td className="py-2 px-2 uppercase text-[10px] text-zinc-400">{entry.difficulty}</td>
                        <td className="py-2 px-2 text-zinc-300">{entry.bottlesCollected}/9</td>
                        <td className="py-2 px-2 text-zinc-400">{formatSec(entry.completionTimeSec)}</td>
                        <td className="py-2 px-2 text-right font-bold text-emerald-300">
                          {entry.score.toLocaleString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
