import React, { useState } from 'react';
import { HelpCircle, RotateCcw, X } from 'lucide-react';
import { PUZZLES } from '../data/gameData';
import { audioEngine } from '../engine/audio';
import { t } from '../i18n/translations';
import { Language } from '../types/game';

interface PuzzleModalProps {
  puzzleId: string;
  alreadySolved: boolean;
  lang: Language;
  onSolve: (puzzleId: string, rewardItemId?: string) => void;
  onClose: () => void;
}

export const PuzzleModal: React.FC<PuzzleModalProps> = ({
  puzzleId,
  alreadySolved,
  lang,
  onSolve,
  onClose,
}) => {
  const puzzle = PUZZLES[puzzleId];
  const isUr = lang === 'ur';

  const [digits, setDigits] = useState<string[]>(() =>
    puzzle ? puzzle.solution.map((_, i) => (puzzle.type === 'light_mirrors' || puzzle.type === 'statue_alignment' ? 'N' : '0')) : []
  );
  const [sequence, setSequence] = useState<string[]>([]);
  const [showHint, setShowHint] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!puzzle) return null;

  const isDialType =
    puzzle.type === 'number_lock' || puzzle.type === 'quantum_cipher';
  const isDirType =
    puzzle.type === 'light_mirrors' || puzzle.type === 'statue_alignment';
  const isSeqType =
    puzzle.type === 'bottle_altar' || puzzle.type === 'sound_chime';

  const cycleDigit = (idx: number, delta: number) => {
    audioEngine.playSfx('click');
    setErrorMsg(null);
    setDigits((prev) => {
      const next = [...prev];
      if (isDirType) {
        const dirs = ['N', 'E', 'S', 'W'];
        const cur = dirs.indexOf(next[idx]);
        next[idx] = dirs[(cur + delta + 4) % 4];
      } else {
        const cur = parseInt(next[idx], 10) || 0;
        next[idx] = String((cur + delta + 10) % 10);
      }
      return next;
    });
  };

  const pushSequenceChoice = (choiceId: string) => {
    if (puzzle.type === 'sound_chime') {
      if (choiceId === 'low') audioEngine.playSfx('chime_low');
      else if (choiceId === 'mid') audioEngine.playSfx('chime_mid');
      else audioEngine.playSfx('chime_high');
    } else {
      audioEngine.playSfx('bottle');
    }
    setErrorMsg(null);
    setSequence((prev) => {
      if (prev.length >= puzzle.solution.length) return prev;
      return [...prev, choiceId];
    });
  };

  const handleSubmit = () => {
    const attempt = isSeqType ? sequence : digits;
    const ok =
      attempt.length === puzzle.solution.length &&
      attempt.every((val, i) => val === puzzle.solution[i]);

    if (ok) {
      onSolve(puzzle.id, puzzle.rewardItemId);
      onClose();
    } else {
      audioEngine.playSfx('hit');
      setErrorMsg(
        isUr
          ? 'ترتیب درست نہیں ہے۔ اپنی بوتلوں اور خطوط کے سراغ چیک کریں۔'
          : 'The mechanism clicks shut. Check your collected bottles and letters.'
      );
      if (isSeqType) setSequence([]);
    }
  };

  return (
    <div
      dir={isUr ? 'rtl' : 'ltr'}
      onPointerDown={(e) => e.stopPropagation()}
      className={`fixed inset-0 z-40 flex items-center justify-center bg-[#040407]/85 p-4 ${isUr ? 'font-urdu' : ''}`}
    >
      <div className="w-full max-w-lg bg-[#0d0e15] border border-zinc-700/80 p-5 space-y-4">
        <div className="flex items-start justify-between border-b border-zinc-800 pb-3">
          <div>
            <h2 className="text-lg font-display font-bold text-rose-400">
              {isUr ? puzzle.titleUr : puzzle.titleEn}
            </h2>
            <p className="text-xs text-zinc-300 mt-1">
              {isUr ? puzzle.promptUr : puzzle.promptEn}
            </p>
          </div>
          <button onClick={onClose} className="p-1 text-zinc-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {alreadySolved ? (
          <div className="p-4 bg-emerald-950/40 border border-emerald-700/60 text-emerald-300 text-sm text-center">
            {isUr ? 'یہ معمہ پہلے ہی حل ہو چکا ہے۔' : 'Mechanism unlocked.'}
          </div>
        ) : (
          <>
            {(isDialType || isDirType) && (
              <div className="flex items-center justify-center gap-3 py-4">
                {digits.map((val, idx) => (
                  <div key={idx} className="flex flex-col items-center gap-1.5">
                    <button
                      onClick={() => cycleDigit(idx, 1)}
                      className="w-14 h-9 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 text-sm cursor-pointer"
                    >
                      ▲
                    </button>
                    <div className="w-14 h-14 flex items-center justify-center bg-[#06070a] border border-rose-700/60 text-2xl font-display font-bold text-zinc-100 tabular-nums">
                      {val}
                    </div>
                    <button
                      onClick={() => cycleDigit(idx, -1)}
                      className="w-14 h-9 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 text-sm cursor-pointer"
                    >
                      ▼
                    </button>
                  </div>
                ))}
              </div>
            )}

            {isSeqType && (
              <div className="space-y-4 py-2">
                <div className="flex items-center justify-center gap-2 min-h-[48px] bg-[#06070a] border border-zinc-800 p-2">
                  {puzzle.solution.map((_, i) => {
                    const chosen = sequence[i];
                    const choiceObj = puzzle.choices?.find((c) => c.id === chosen);
                    return (
                      <div
                        key={i}
                        className="px-3 py-1.5 border border-zinc-700 bg-zinc-900 text-xs text-zinc-200 min-w-[68px] text-center"
                      >
                        {choiceObj
                          ? isUr
                            ? choiceObj.labelUr
                            : choiceObj.labelEn
                          : '—'}
                      </div>
                    );
                  })}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {puzzle.choices?.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => pushSequenceChoice(c.id)}
                      className="p-3 bg-[#141520] hover:bg-rose-950/60 border border-zinc-700 hover:border-rose-500 text-sm text-zinc-100 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {c.symbol && (
                        <span style={{ color: c.color || '#f4f4f5' }} className="text-lg">
                          {c.symbol}
                        </span>
                      )}
                      <span>{isUr ? c.labelUr : c.labelEn}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {errorMsg && (
              <div className="p-2.5 bg-rose-950/60 border border-rose-700/70 text-xs text-rose-200 text-center">
                {errorMsg}
              </div>
            )}

            {showHint && (
              <div className="p-2.5 bg-amber-950/40 border border-amber-700/50 text-xs text-amber-200">
                {isUr ? puzzle.hintUr : puzzle.hintEn}
              </div>
            )}

            <div className="flex items-center justify-between gap-2 pt-2">
              <button
                onClick={() => setShowHint((v) => !v)}
                className="flex items-center gap-1.5 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-300 cursor-pointer"
              >
                <HelpCircle className="w-4 h-4 text-amber-400" />
                <span>{t(lang, 'hint')}</span>
              </button>

              {isSeqType && (
                <button
                  onClick={() => setSequence([])}
                  className="flex items-center gap-1.5 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-300 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{t(lang, 'reset')}</span>
                </button>
              )}

              <button
                onClick={handleSubmit}
                className="px-5 py-2 bg-rose-800 hover:bg-rose-700 border border-rose-500 text-sm font-semibold text-white cursor-pointer"
              >
                {t(lang, 'submit')}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
