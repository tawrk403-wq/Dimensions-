import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  User,
} from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import {
  clearSlotPendingCloudSync,
  getPendingSyncSlots,
  loadAllSaveSlots,
  markSlotPendingCloudSync,
  writeAllSaveSlots,
} from '../state/saveSystem';
import {
  AchievementDef,
  EndingId,
  GameProgressState,
  LeaderboardEntry,
  SaveConflictInfo,
  SaveSlot,
  UserProfile,
  UserStats,
} from '../types/game';
import { auth, db } from './config';
import { handleFirestoreError, OperationType } from './errorHandler';

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'rescue_ali',
    titleEn: 'Out of Door IX',
    titleUr: 'نویں دروازے سے رہائی',
    descEn: 'Unlock Door IX and rescue Ali Ahmed from the abandoned house.',
    descUr: 'نواں دروازہ کھولیں اور علی احمد کو ویران حویلی سے بچائیں۔',
  },
  {
    id: 'banish_matriarch',
    titleEn: 'Blood Moon Severed',
    titleUr: 'خونی چاند کی شکست',
    descEn: 'Purify the 3 ward seals and banish the House Matriarch.',
    descUr: 'تین مقدس مہریں روشن کر کے حویلی کی ملکہ کو شکست دیں۔',
  },
  {
    id: 'banish_caretaker',
    titleEn: 'Keeper of Ashes',
    titleUr: 'قبرستان کی آزادی',
    descEn: 'Light all ward braziers and defeat the Caretaker Revenant.',
    descUr: 'تینوں مشعلیں جلا کر قبرستان کے محافظ بھوت کو ختم کریں۔',
  },
  {
    id: 'bottles_all',
    titleEn: 'Nine Elixirs',
    titleUr: 'نو پراسرار بوتلیں',
    descEn: 'Recover all 9 spectral drink bottles across the house.',
    descUr: 'حویلی سے تمام 9 پراسرار بوتلیں جمع کریں۔',
  },
  {
    id: 'truth_seeker',
    titleEn: 'The Unredacted Past',
    titleUr: 'ماضی کا راز',
    descEn: 'Uncover 5 or more truth clues from scattered letters.',
    descUr: 'بکھرے خطوط سے کم از کم 5 سچائی کے سراغ حاصل کریں۔',
  },
  {
    id: 'secret_ending',
    titleEn: 'Architect of Nothing',
    titleUr: 'خفیہ جہان کا فاتح',
    descEn: 'Unlock the hidden Rift Sanctum and achieve the Secret Ending.',
    descUr: 'خفیہ خلائی مقام کھول کر خفیہ انجام حاصل کریں۔',
  },
  {
    id: 'nightmare_clear',
    titleEn: 'Beyond Nightmare',
    titleUr: 'ڈراؤنے خواب سے پار',
    descEn: 'Complete the story on Nightmare difficulty.',
    descUr: 'ڈراؤنا خواب (Nightmare) مشکل میں کہانی مکمل کریں۔',
  },
];

const DEFAULT_STATS: UserStats = {
  totalPlayTimeSec: 0,
  endingsUnlocked: [],
  chaptersReached: 1,
  bestBottles: 0,
  bestLetters: 0,
  bestTruthClues: 0,
  bossesDefeated: 0,
  puzzlesSolved: 0,
  runsCompleted: 0,
  deaths: 0,
};

function sanitizeDisplayName(name: string | null | undefined, email?: string | null): string {
  const raw = (name || email?.split('@')[0] || 'Survivor').replace(/[^a-zA-Z0-9 _.-]/g, '').trim();
  if (raw.length >= 2) return raw.slice(0, 32);
  return 'Survivor';
}

export async function ensureUserDocuments(user: User, preferredName?: string): Promise<UserProfile> {
  const userPath = `users/${user.uid}`;
  const privatePath = `users/${user.uid}/private/account`;
  try {
    const userRef = doc(db, 'users', user.uid);
    const snap = await getDoc(userRef);

    // Ensure private PII doc exists for owner
    const privateRef = doc(db, 'users', user.uid, 'private', 'account');
    const privSnap = await getDoc(privateRef);
    if (!privSnap.exists()) {
      await setDoc(privateRef, {
        uid: user.uid,
        email: user.email || `${user.uid}@dimensions.local`,
        role: 'player',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    if (snap.exists()) {
      const data = snap.data();
      return {
        uid: data.uid,
        displayName: data.displayName,
        avatarAccent: data.avatarAccent || '#e11d48',
        stats: { ...DEFAULT_STATS, ...(data.stats || {}) },
        achievements: Array.isArray(data.achievements) ? data.achievements : [],
      };
    }

    const displayName = sanitizeDisplayName(preferredName || user.displayName, user.email);
    const createdProfile = {
      uid: user.uid,
      displayName,
      avatarAccent: '#e11d48',
      stats: DEFAULT_STATS,
      achievements: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(userRef, createdProfile);

    return {
      uid: user.uid,
      displayName,
      avatarAccent: '#e11d48',
      stats: DEFAULT_STATS,
      achievements: [],
    };
  } catch (err) {
    if (err instanceof Error && err.message.includes('permission')) {
      handleFirestoreError(err, OperationType.WRITE, userPath || privatePath);
    }
    throw err;
  }
}

export async function registerWithEmail(email: string, password: string, displayName: string): Promise<UserProfile> {
  const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
  const cleanName = sanitizeDisplayName(displayName, email);
  await updateProfile(cred.user, { displayName: cleanName });
  try {
    await sendEmailVerification(cred.user);
  } catch {
    // Non-fatal if verification email dispatch is throttled
  }
  return ensureUserDocuments(cred.user, cleanName);
}

export async function loginWithEmail(email: string, password: string): Promise<UserProfile> {
  const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
  return ensureUserDocuments(cred.user);
}

export async function loginWithGoogle(): Promise<UserProfile> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  const cred = await signInWithPopup(auth, provider);
  return ensureUserDocuments(cred.user);
}

export async function logoutAccount(): Promise<void> {
  await signOut(auth);
}

export async function sendPasswordReset(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

export async function resendVerificationEmail(): Promise<void> {
  if (auth.currentUser) {
    await sendEmailVerification(auth.currentUser);
  }
}

export async function pushSaveSlotToCloud(uid: string, slot: SaveSlot): Promise<void> {
  const path = `users/${uid}/saves/${slot.slotId}`;
  try {
    const ref = doc(db, 'users', uid, 'saves', slot.slotId);
    await setDoc(ref, {
      uid,
      slotId: slot.slotId,
      chapter: slot.chapter,
      difficulty: slot.difficulty,
      savedAt: slot.savedAt,
      clientUpdatedAtMs: slot.clientUpdatedAtMs || Date.now(),
      progress: slot.progress,
      updatedAt: serverTimestamp(),
    });
    clearSlotPendingCloudSync(slot.slotId);
  } catch (err) {
    markSlotPendingCloudSync(slot.slotId);
    if (err instanceof Error && err.message.includes('permission')) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
    throw err;
  }
}

export async function fetchCloudSaves(uid: string): Promise<Record<string, SaveSlot>> {
  const path = `users/${uid}/saves`;
  try {
    const snap = await getDocs(collection(db, 'users', uid, 'saves'));
    const out: Record<string, SaveSlot> = {};
    snap.forEach((docSnap) => {
      const d = docSnap.data();
      out[docSnap.id] = {
        slotId: d.slotId || docSnap.id,
        savedAt: d.savedAt || '',
        clientUpdatedAtMs: typeof d.clientUpdatedAtMs === 'number' ? d.clientUpdatedAtMs : 0,
        chapter: d.chapter,
        difficulty: d.difficulty,
        progress: d.progress,
      };
    });
    return out;
  } catch (err) {
    if (err instanceof Error && err.message.includes('permission')) {
      handleFirestoreError(err, OperationType.LIST, path);
    }
    throw err;
  }
}

function progressDiverges(a: GameProgressState, b: GameProgressState): boolean {
  return (
    a.chapter !== b.chapter ||
    a.difficulty !== b.difficulty ||
    a.collectedBottleIds.length !== b.collectedBottleIds.length ||
    a.collectedLetterIds.length !== b.collectedLetterIds.length ||
    Math.abs((a.playTimeSeconds || 0) - (b.playTimeSeconds || 0)) > 20
  );
}

/**
 * Bi-directional offline-safe cloud sync with explicit conflict detection.
 */
export async function syncSavesWithCloud(uid: string): Promise<{
  mergedSlots: Record<string, SaveSlot>;
  conflicts: SaveConflictInfo[];
}> {
  const localSlots = loadAllSaveSlots();
  const pendingSet = new Set(getPendingSyncSlots());
  const cloudSlots = await fetchCloudSaves(uid);
  const merged: Record<string, SaveSlot> = { ...localSlots };
  const conflicts: SaveConflictInfo[] = [];

  const allKeys = new Set([...Object.keys(localSlots), ...Object.keys(cloudSlots)]);
  for (const slotId of allKeys) {
    const local = localSlots[slotId];
    const cloud = cloudSlots[slotId];

    if (local && !cloud) {
      await pushSaveSlotToCloud(uid, local);
    } else if (!local && cloud) {
      merged[slotId] = cloud;
      clearSlotPendingCloudSync(slotId);
    } else if (local && cloud) {
      const localTs = local.clientUpdatedAtMs || 0;
      const cloudTs = cloud.clientUpdatedAtMs || 0;
      const hasPendingLocal = pendingSet.has(slotId);

      if (hasPendingLocal && cloudTs > localTs + 5000 && progressDiverges(local.progress, cloud.progress)) {
        conflicts.push({ slotId, localSlot: local, cloudSlot: cloud });
      } else if (localTs >= cloudTs) {
        await pushSaveSlotToCloud(uid, local);
      } else {
        merged[slotId] = cloud;
        clearSlotPendingCloudSync(slotId);
      }
    }
  }

  writeAllSaveSlots(merged);
  return { mergedSlots: merged, conflicts };
}

export async function resolveSaveConflict(
  uid: string,
  conflict: SaveConflictInfo,
  choice: 'local' | 'cloud'
): Promise<Record<string, SaveSlot>> {
  const all = loadAllSaveSlots();
  if (choice === 'local') {
    const stamped: SaveSlot = { ...conflict.localSlot, clientUpdatedAtMs: Date.now() };
    all[conflict.slotId] = stamped;
    writeAllSaveSlots(all);
    await pushSaveSlotToCloud(uid, stamped);
  } else {
    all[conflict.slotId] = conflict.cloudSlot;
    writeAllSaveSlots(all);
    clearSlotPendingCloudSync(conflict.slotId);
  }
  return all;
}

export function computeRunScore(progress: GameProgressState, endingId: EndingId): number {
  const endingBonus: Record<EndingId, number> = {
    bad: 400,
    normal: 1000,
    good: 1800,
    true: 2800,
    secret: 4500,
  };
  const diffMult = progress.difficulty === 'nightmare' ? 2.0 : progress.difficulty === 'hard' ? 1.45 : 1.0;
  const collectibles =
    progress.collectedBottleIds.length * 150 +
    progress.collectedLetterIds.length * 90 +
    progress.truthCluesFound * 220 +
    progress.solvedPuzzleIds.length * 160 +
    progress.defeatedBossIds.length * 400;
  const speedBonus = Math.max(0, Math.round(1200 - Math.min(1200, (progress.playTimeSeconds || 0) * 0.6)));
  return Math.min(1000000, Math.round((endingBonus[endingId] + collectibles + speedBonus) * diffMult));
}

export async function syncPlayerStatsAndLeaderboard(
  uid: string,
  displayName: string,
  progress: GameProgressState,
  opts: { endingId?: EndingId; isDeath?: boolean } = {}
): Promise<UserProfile | null> {
  if (!navigator.onLine) return null;
  const userPath = `users/${uid}`;
  try {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    const existing = snap.exists() ? snap.data() : null;
    const prevStats: UserStats = { ...DEFAULT_STATS, ...(existing?.stats || {}) };
    const prevAch = new Set<string>(Array.isArray(existing?.achievements) ? existing.achievements : []);
    const endings = new Set<EndingId>(prevStats.endingsUnlocked || []);
    if (opts.endingId) endings.add(opts.endingId);

    // Evaluate achievements
    if (progress.aliRescued) prevAch.add('rescue_ali');
    if (progress.defeatedBossIds.includes('boss_matriarch')) prevAch.add('banish_matriarch');
    if (progress.defeatedBossIds.includes('boss_caretaker')) prevAch.add('banish_caretaker');
    if (progress.collectedBottleIds.length >= 9) prevAch.add('bottles_all');
    if (progress.truthCluesFound >= 5) prevAch.add('truth_seeker');
    if (opts.endingId === 'secret') prevAch.add('secret_ending');
    if (opts.endingId && progress.difficulty === 'nightmare') prevAch.add('nightmare_clear');

    const nextStats: UserStats = {
      totalPlayTimeSec: Math.round(Math.max(prevStats.totalPlayTimeSec, progress.playTimeSeconds || 0)),
      endingsUnlocked: Array.from(endings).slice(0, 5),
      chaptersReached: Math.max(prevStats.chaptersReached, progress.chapter),
      bestBottles: Math.max(prevStats.bestBottles, progress.collectedBottleIds.length),
      bestLetters: Math.max(prevStats.bestLetters, progress.collectedLetterIds.length),
      bestTruthClues: Math.max(prevStats.bestTruthClues, progress.truthCluesFound),
      bossesDefeated: Math.max(prevStats.bossesDefeated, progress.defeatedBossIds.length),
      puzzlesSolved: Math.max(prevStats.puzzlesSolved, progress.solvedPuzzleIds.length),
      runsCompleted: prevStats.runsCompleted + (opts.endingId ? 1 : 0),
      deaths: prevStats.deaths + (opts.isDeath ? 1 : 0),
    };

    const achievements = Array.from(prevAch);
    if (snap.exists()) {
      await setDoc(
        userRef,
        {
          uid,
          displayName: existing?.displayName || sanitizeDisplayName(displayName),
          avatarAccent: existing?.avatarAccent || '#e11d48',
          stats: nextStats,
          achievements,
          createdAt: existing?.createdAt,
          updatedAt: serverTimestamp(),
        }
      );
    }

    if (opts.endingId) {
      const score = computeRunScore(progress, opts.endingId);
      const lbRef = doc(db, 'leaderboard', uid);
      const lbSnap = await getDoc(lbRef);
      const prevScore = lbSnap.exists() ? Number(lbSnap.data().score || 0) : -1;
      if (score >= prevScore) {
        await setDoc(lbRef, {
          uid,
          displayName: existing?.displayName || sanitizeDisplayName(displayName),
          score,
          endingId: opts.endingId,
          difficulty: progress.difficulty,
          chapter: progress.chapter,
          completionTimeSec: Math.round(progress.playTimeSeconds || 0),
          bottlesCollected: progress.collectedBottleIds.length,
          lettersCollected: progress.collectedLetterIds.length,
          truthClues: progress.truthCluesFound,
          updatedAt: serverTimestamp(),
        });
      }
    }

    return {
      uid,
      displayName: existing?.displayName || sanitizeDisplayName(displayName),
      avatarAccent: existing?.avatarAccent || '#e11d48',
      stats: nextStats,
      achievements,
    };
  } catch (err) {
    if (err instanceof Error && err.message.includes('permission')) {
      handleFirestoreError(err, OperationType.UPDATE, userPath);
    }
    return null;
  }
}

export async function fetchLeaderboard(maxResults = 25): Promise<LeaderboardEntry[]> {
  const path = 'leaderboard';
  try {
    const q = query(collection(db, 'leaderboard'), orderBy('score', 'desc'), limit(maxResults));
    const snap = await getDocs(q);
    return snap.docs.map((d) => {
      const x = d.data();
      return {
        uid: x.uid,
        displayName: x.displayName,
        score: x.score,
        endingId: x.endingId,
        difficulty: x.difficulty,
        chapter: x.chapter,
        completionTimeSec: x.completionTimeSec,
        bottlesCollected: x.bottlesCollected,
        lettersCollected: x.lettersCollected,
        truthClues: x.truthClues,
      };
    });
  } catch (err) {
    if (err instanceof Error && err.message.includes('permission')) {
      handleFirestoreError(err, OperationType.LIST, path);
    }
    throw err;
  }
}
