import { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { ITEMS_CATALOG } from './data/gameData';
import { audioEngine } from './engine/audio';
import { GameEngine } from './engine/GameEngine';
import { auth, testFirestoreConnection } from './firebase/config';
import {
  ensureUserDocuments,
  pushSaveSlotToCloud,
  resolveSaveConflict,
  syncPlayerStatsAndLeaderboard,
  syncSavesWithCloud,
} from './firebase/syncService';
import { t } from './i18n/translations';
import {
  createNewGameProgress,
  getLatestSaveSlot,
  loadAllSaveSlots,
  loadSettings,
  saveSettings,
  saveToSlot,
} from './state/saveSystem';
import {
  ChapterId,
  Difficulty,
  EndingId,
  GameProgressState,
  GameSettings,
  PlayerHudState,
  SaveConflictInfo,
  SaveSlot,
  ScreenMode,
  SubtitleLine,
  SyncStatus,
  UserProfile,
} from './types/game';
import { CinematicOverlay } from './components/CinematicOverlay';
import { CloudAccountModal } from './components/CloudAccountModal';
import { GameHUD } from './components/GameHUD';
import { InventoryModal } from './components/InventoryModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { MapModal } from './components/MapModal';
import { PauseSettingsModal } from './components/PauseSettingsModal';
import { PuzzleModal } from './components/PuzzleModal';
import { TitleScreen } from './components/TitleScreen';

const INITIAL_HUD: PlayerHudState = {
  health: 100,
  maxHealth: 100,
  stamina: 100,
  battery: 100,
  flashlightOn: true,
  isCrouching: false,
  isHiding: false,
  noiseLevel: 0,
  chapter: 1,
  objectiveEn: '',
  objectiveUr: '',
  interactPromptEn: null,
  interactPromptUr: null,
  interactTargetId: null,
  interactActionType: null,
  aliRescued: false,
  aliFollowing: false,
  aliSuspicion: 0,
  playerPos: { x: 0, y: 0, z: 10, yaw: 0 },
  currentRoomId: 'c1_foyer',
  enemyStatus: { nearestThreatDist: 999, isChased: false },
};

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());
  const [saveSlots, setSaveSlots] = useState<Record<string, SaveSlot>>(() => loadAllSaveSlots());
  const progressRef = useRef<GameProgressState>(createNewGameProgress(settings.difficulty, 1));
  const [, forceProgressRender] = useState(0);

  const [screenMode, setScreenMode] = useState<ScreenMode>('title');
  const [hud, setHud] = useState<PlayerHudState>(INITIAL_HUD);
  const [subtitle, setSubtitle] = useState<SubtitleLine | null>(null);
  const subtitleTimerRef = useRef<number>(0);

  const [activePuzzleId, setActivePuzzleId] = useState<string | null>(null);
  const [inventoryOpen, setInventoryOpen] = useState<{
    open: boolean;
    tab: 'items' | 'bottles' | 'letters';
    letterId?: string | null;
  }>({ open: false, tab: 'items' });
  const [mapOpen, setMapOpen] = useState(false);
  const [pauseMode, setPauseMode] = useState<'none' | 'pause' | 'settings_only' | 'save_shrine'>('none');
  const [activeCinematic, setActiveCinematic] = useState<string | null>(null);
  const [activeEnding, setActiveEnding] = useState<EndingId | null>(null);

  // Firebase Auth, Cloud Save Sync & Leaderboard state (never blocks offline story)
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(
    typeof navigator !== 'undefined' && !navigator.onLine ? 'offline' : 'idle'
  );
  const [conflicts, setConflicts] = useState<SaveConflictInfo[]>([]);
  const [cloudModalOpen, setCloudModalOpen] = useState(false);
  const [leaderboardOpen, setLeaderboardOpen] = useState(false);

  const runCloudSync = useCallback(async (uid: string) => {
    if (!navigator.onLine) {
      setSyncStatus('offline');
      return;
    }
    setSyncStatus('syncing');
    try {
      const res = await syncSavesWithCloud(uid);
      setSaveSlots(res.mergedSlots);
      setConflicts(res.conflicts);
      setSyncStatus('synced');
    } catch {
      setSyncStatus('error');
    }
  }, []);

  const persistSlotWithCloud = useCallback(
    (slotId: string) => {
      engineRef.current?.syncPlayerPositionToProgress();
      const entry = saveToSlot(slotId, progressRef.current);
      setSaveSlots(loadAllSaveSlots());
      if (authUser && navigator.onLine) {
        setSyncStatus('syncing');
        void pushSaveSlotToCloud(authUser.uid, entry)
          .then(() => setSyncStatus('synced'))
          .catch(() => setSyncStatus('error'));
      }
      return entry;
    },
    [authUser]
  );

  // Monitor online/offline transitions + Firestore boot probe + Firebase Auth observer
  useEffect(() => {
    void testFirestoreConnection();

    const handleOnline = () => {
      setIsOnline(true);
      if (auth.currentUser) {
        void runCloudSync(auth.currentUser.uid);
      } else {
        setSyncStatus('idle');
      }
    };
    const handleOffline = () => {
      setIsOnline(false);
      setSyncStatus('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setAuthUser(user);
      if (!user) {
        setProfile(null);
        setConflicts([]);
        setSyncStatus(navigator.onLine ? 'idle' : 'offline');
        return;
      }
      if (navigator.onLine) {
        void ensureUserDocuments(user)
          .then((p) => {
            setProfile(p);
            return runCloudSync(user.uid);
          })
          .catch(() => {});
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      unsubAuth();
    };
  }, [runCloudSync]);

  const showSubtitle = useCallback(
    (speakerEn: string, speakerUr: string, textEn: string, textUr: string, duration = 3.5) => {
      window.clearTimeout(subtitleTimerRef.current);
      setSubtitle({ speakerEn, speakerUr, textEn, textUr, duration });
      subtitleTimerRef.current = window.setTimeout(() => {
        setSubtitle(null);
      }, duration * 1000);
    },
    []
  );

  // Mount isolated WebGL canvas once
  useEffect(() => {
    const mountEl = canvasMountRef.current;
    if (!mountEl) return;

    const engine = new GameEngine(mountEl, settings, progressRef.current, {
      onHudUpdate: (nextHud) => setHud(nextHud),
      onShowSubtitle: showSubtitle,
      onOpenPuzzle: (puzzleId) => {
        engineRef.current?.setMode('paused');
        setActivePuzzleId(puzzleId);
      },
      onOpenLetter: (letterId) => {
        engineRef.current?.setMode('paused');
        setInventoryOpen({ open: true, tab: 'letters', letterId });
      },
      onOpenSaveShrine: () => {
        engineRef.current?.setMode('paused');
        setPauseMode('save_shrine');
      },
      onTriggerCinematic: (cinId) => {
        if (!progressRef.current.viewedCinematics.includes(cinId)) {
          progressRef.current.viewedCinematics.push(cinId);
        }
        engineRef.current?.setMode('paused');
        setActiveCinematic(cinId);
        setScreenMode('cinematic');
      },
      onTriggerEnding: (endingId) => {
        engineRef.current?.setMode('paused');
        setActiveEnding(endingId);
        setScreenMode('ending');
        const user = auth.currentUser;
        if (user && navigator.onLine) {
          void syncPlayerStatsAndLeaderboard(
            user.uid,
            user.displayName || 'Survivor',
            progressRef.current,
            { endingId }
          ).then((p) => {
            if (p) setProfile(p);
          });
        }
      },
      onGameOver: () => {
        setScreenMode('gameover');
        const user = auth.currentUser;
        if (user && navigator.onLine) {
          void syncPlayerStatsAndLeaderboard(
            user.uid,
            user.displayName || 'Survivor',
            progressRef.current,
            { isDeath: true }
          ).then((p) => {
            if (p) setProfile(p);
          });
        }
      },
      onProgressMutated: () => {
        engineRef.current?.syncPlayerPositionToProgress();
        const entry = saveToSlot('auto', progressRef.current);
        setSaveSlots(loadAllSaveSlots());
        forceProgressRender((n) => n + 1);
        const user = auth.currentUser;
        if (user && navigator.onLine) {
          void pushSaveSlotToCloud(user.uid, entry)
            .then(() => setSyncStatus('synced'))
            .catch(() => setSyncStatus('error'));
        }
      },
    });

    engineRef.current = engine;
    (window as Window & { __DIMENSIONS_ENGINE__?: GameEngine }).__DIMENSIONS_ENGINE__ = engine;
    return () => {
      delete (window as Window & { __DIMENSIONS_ENGINE__?: GameEngine }).__DIMENSIONS_ENGINE__;
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleUpdateSettings = useCallback((next: GameSettings) => {
    setSettings(next);
    saveSettings(next);
    engineRef.current?.applySettings(next);
    audioEngine.applySettings(next);
  }, []);

  const tryLockLandscape = useCallback(() => {
    try {
      const orientation = screen.orientation as ScreenOrientation & {
        lock?: (o: string) => Promise<void>;
      };
      if (orientation && typeof orientation.lock === 'function') {
        orientation.lock('landscape').catch(() => {});
      }
    } catch {
      // Orientation lock requires fullscreen or installed PWA on some browsers
    }
  }, []);

  const [isPortraitMobile, setIsPortraitMobile] = useState(false);
  const [dismissPortraitWarn, setDismissPortraitWarn] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      const isTouch = window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 768;
      setIsPortraitMobile(isTouch && window.innerHeight > window.innerWidth);
    };
    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    return () => window.removeEventListener('resize', checkOrientation);
  }, []);

  const handleStartNewGame = useCallback(
    (difficulty: Difficulty, chapter: ChapterId = 1) => {
      audioEngine.init();
      tryLockLandscape();
      const fresh = createNewGameProgress(difficulty, chapter);
      progressRef.current = fresh;
      const entry = saveToSlot('auto', fresh);
      setSaveSlots(loadAllSaveSlots());
      if (auth.currentUser && navigator.onLine) {
        void pushSaveSlotToCloud(auth.currentUser.uid, entry).catch(() => {});
      }
      engineRef.current?.loadChapter(fresh, false);

      const cinId = chapter === 1 ? 'intro' : chapter === 2 ? 'chapter2_intro' : 'chapter3_intro';
      engineRef.current?.setMode('paused');
      setActiveCinematic(cinId);
      setScreenMode('cinematic');
    },
    [tryLockLandscape]
  );

  const handleLoadSlot = useCallback(
    (slot: SaveSlot) => {
      audioEngine.init();
      tryLockLandscape();
      const loaded: GameProgressState = JSON.parse(JSON.stringify(slot.progress));
      progressRef.current = loaded;
      engineRef.current?.loadChapter(loaded, true);
      setScreenMode('playing');
    },
    [tryLockLandscape]
  );

  const handleContinue = useCallback(() => {
    const latest = getLatestSaveSlot();
    if (latest) handleLoadSlot(latest);
  }, [handleLoadSlot]);

  const handleRestartChapter = useCallback(() => {
    const curChapter = progressRef.current.chapter;
    const curDiff = progressRef.current.difficulty;
    const fresh = createNewGameProgress(curDiff, curChapter);
    progressRef.current = fresh;
    const entry = saveToSlot('auto', fresh);
    setSaveSlots(loadAllSaveSlots());
    if (auth.currentUser && navigator.onLine) {
      void pushSaveSlotToCloud(auth.currentUser.uid, entry).catch(() => {});
    }
    setPauseMode('none');
    setActivePuzzleId(null);
    setInventoryOpen({ open: false, tab: 'items' });
    setMapOpen(false);
    setActiveCinematic(null);
    setActiveEnding(null);
    engineRef.current?.loadChapter(fresh, false);
    setScreenMode('playing');
  }, []);

  const resumePlaying = useCallback(() => {
    setActivePuzzleId(null);
    setInventoryOpen((s) => ({ ...s, open: false }));
    setMapOpen(false);
    setPauseMode('none');
    if (screenMode === 'title') {
      engineRef.current?.setMode('title');
    } else {
      setScreenMode('playing');
      engineRef.current?.setMode('playing');
    }
  }, [screenMode]);

  const handleMoveInput = useCallback((x: number, y: number, s: boolean) => {
    engineRef.current?.setTouchMove(x, y, s);
  }, []);
  const handleSprintToggle = useCallback((active: boolean) => {
    engineRef.current?.setTouchSprintLocked(active);
  }, []);
  const handleLookDelta = useCallback((dx: number, dy: number) => {
    engineRef.current?.addLookDelta(dx, dy);
  }, []);
  const handleInteract = useCallback(() => {
    engineRef.current?.handlePrimaryInteract();
  }, []);
  const handleToggleFlashlight = useCallback(() => {
    engineRef.current?.toggleFlashlight();
  }, []);
  const handleToggleCrouch = useCallback(() => {
    engineRef.current?.toggleCrouch();
  }, []);
  const handleJump = useCallback(() => {
    engineRef.current?.triggerJump();
  }, []);
  const handleToggleCamera = useCallback(() => {
    const nextPersp = engineRef.current?.toggleCameraPerspective();
    if (nextPersp) handleUpdateSettings({ ...settings, cameraPerspective: nextPersp });
  }, [handleUpdateSettings, settings]);
  const handleOpenInventory = useCallback(() => {
    engineRef.current?.setMode('paused');
    setInventoryOpen({ open: true, tab: 'items' });
  }, []);
  const handleOpenMap = useCallback(() => {
    engineRef.current?.setMode('paused');
    setMapOpen(true);
  }, []);
  const handlePause = useCallback(() => {
    engineRef.current?.setMode('paused');
    setPauseMode('pause');
  }, []);
  const handleToggleMute = useCallback(() => {
    handleUpdateSettings({ ...settings, muted: !settings.muted });
  }, [handleUpdateSettings, settings]);

  // Global keyboard shortcuts for modals & pause
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (screenMode !== 'playing') return;
      if (e.code === 'Escape') {
        if (activePuzzleId || inventoryOpen.open || mapOpen || pauseMode !== 'none') {
          resumePlaying();
        } else {
          engineRef.current?.setMode('paused');
          setPauseMode('pause');
        }
      } else if (e.code === 'KeyM' && pauseMode === 'none' && !activePuzzleId) {
        if (mapOpen) resumePlaying();
        else {
          engineRef.current?.setMode('paused');
          setInventoryOpen((s) => ({ ...s, open: false }));
          setMapOpen(true);
        }
      } else if ((e.code === 'KeyI' || e.code === 'Tab') && pauseMode === 'none' && !activePuzzleId) {
        e.preventDefault();
        if (inventoryOpen.open) resumePlaying();
        else {
          engineRef.current?.setMode('paused');
          setMapOpen(false);
          setInventoryOpen({ open: true, tab: 'items' });
        }
      } else if (e.code === 'KeyV' && pauseMode === 'none') {
        const nextPersp = engineRef.current?.toggleCameraPerspective();
        if (nextPersp) {
          handleUpdateSettings({ ...settings, cameraPerspective: nextPersp });
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [
    screenMode,
    activePuzzleId,
    inventoryOpen.open,
    mapOpen,
    pauseMode,
    resumePlaying,
    handleUpdateSettings,
    settings,
  ]);

  const handleUseSupply = (itemId: string) => {
    const prog = progressRef.current;
    const item = prog.inventory.find((i) => i.id === itemId);
    if (!item || item.quantity <= 0) return;

    if (itemId === 'bandage') {
      prog.health = Math.min(100, prog.health + 40);
    } else if (itemId === 'battery') {
      prog.battery = Math.min(100, prog.battery + 45);
    }
    item.quantity -= 1;
    if (item.quantity <= 0) {
      prog.inventory = prog.inventory.filter((i) => i.id !== itemId);
    }
    forceProgressRender((n) => n + 1);
  };

  const handleCombineItems = (itemA: string, itemB: string, resultId: string) => {
    const prog = progressRef.current;
    prog.inventory = prog.inventory.filter((i) => i.id !== itemA && i.id !== itemB);
    const cat = ITEMS_CATALOG[resultId];
    if (cat) {
      prog.inventory.push({ ...cat, quantity: 1 });
    }
    forceProgressRender((n) => n + 1);
  };

  const handleResolveConflict = async (conflict: SaveConflictInfo, choice: 'local' | 'cloud') => {
    if (!authUser) return;
    const updated = await resolveSaveConflict(authUser.uid, conflict, choice);
    setSaveSlots(updated);
    setConflicts((prev) => prev.filter((c) => c.slotId !== conflict.slotId));
    setSyncStatus('synced');
  };

  const lang = settings.language;
  const isUr = lang === 'ur';

  return (
    <div className="relative w-full h-full bg-[#050608] overflow-hidden">
      {/* Isolated WebGL Canvas Container */}
      <div ref={canvasMountRef} className="fixed inset-0 w-full h-full" />

      {/* Title Screen */}
      {screenMode === 'title' && pauseMode !== 'settings_only' && (
        <TitleScreen
          settings={settings}
          saveSlots={saveSlots}
          hasContinue={!!getLatestSaveSlot()}
          isOnline={isOnline}
          syncStatus={syncStatus}
          authUser={authUser}
          profile={profile}
          conflictCount={conflicts.length}
          onStartNewGame={handleStartNewGame}
          onContinue={handleContinue}
          onLoadSlot={handleLoadSlot}
          onUpdateSettings={handleUpdateSettings}
          onOpenSettings={() => setPauseMode('settings_only')}
          onOpenCloudAccount={() => setCloudModalOpen(true)}
          onOpenLeaderboard={() => setLeaderboardOpen(true)}
        />
      )}

      {/* Active Gameplay HUD */}
      {screenMode === 'playing' && (
        <GameHUD
          hud={hud}
          settings={settings}
          activeSubtitle={subtitle}
          onMoveInput={handleMoveInput}
          onSprintToggle={handleSprintToggle}
          onLookDelta={handleLookDelta}
          onInteract={handleInteract}
          onToggleFlashlight={handleToggleFlashlight}
          onToggleCrouch={handleToggleCrouch}
          onJump={handleJump}
          onToggleCamera={handleToggleCamera}
          onOpenInventory={handleOpenInventory}
          onOpenMap={handleOpenMap}
          onPause={handlePause}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Interactive Puzzle Modal */}
      {activePuzzleId && (
        <PuzzleModal
          puzzleId={activePuzzleId}
          alreadySolved={progressRef.current.solvedPuzzleIds.includes(activePuzzleId)}
          lang={lang}
          onSolve={(pid, rewardId) => engineRef.current?.onPuzzleSolved(pid, rewardId)}
          onClose={resumePlaying}
        />
      )}

      {/* Inventory & Letters Modal */}
      {inventoryOpen.open && (
        <InventoryModal
          progress={progressRef.current}
          lang={lang}
          initialTab={inventoryOpen.tab}
          initialLetterId={inventoryOpen.letterId}
          onUseSupply={handleUseSupply}
          onCombineItems={handleCombineItems}
          onClose={resumePlaying}
        />
      )}

      {/* Interactive Map Modal */}
      {mapOpen && (
        <MapModal
          progress={progressRef.current}
          hud={hud}
          lang={lang}
          onClose={resumePlaying}
        />
      )}

      {/* Pause / Save Shrine / Settings Modal */}
      {pauseMode !== 'none' && (
        <PauseSettingsModal
          mode={pauseMode === 'settings_only' ? 'settings_only' : pauseMode === 'save_shrine' ? 'save_shrine' : 'pause'}
          settings={settings}
          saveSlots={saveSlots}
          onUpdateSettings={handleUpdateSettings}
          onSaveToSlot={(slotId) => {
            persistSlotWithCloud(slotId);
          }}
          onResume={resumePlaying}
          onRestart={handleRestartChapter}
          onExitToTitle={() => {
            setPauseMode('none');
            setScreenMode('title');
            engineRef.current?.setMode('title');
          }}
        />
      )}

      {/* Cloud Account, Offline Conflict Resolution, Career Stats & Achievements Modal */}
      {cloudModalOpen && (
        <CloudAccountModal
          lang={lang}
          authUser={authUser}
          profile={profile}
          isOnline={isOnline}
          syncStatus={syncStatus}
          conflicts={conflicts}
          onSyncNow={async () => {
            if (authUser) await runCloudSync(authUser.uid);
          }}
          onResolveConflict={handleResolveConflict}
          onProfileUpdated={(nextProfile) => {
            setProfile(nextProfile);
            if (auth.currentUser) {
              void runCloudSync(auth.currentUser.uid);
            }
          }}
          onClose={() => setCloudModalOpen(false)}
        />
      )}

      {/* Global Leaderboard Modal */}
      {leaderboardOpen && (
        <LeaderboardModal
          lang={lang}
          currentUid={authUser?.uid}
          isOnline={isOnline}
          onClose={() => setLeaderboardOpen(false)}
        />
      )}

      {/* Cinematics & 5 Endings */}
      {(screenMode === 'cinematic' || screenMode === 'ending') && (
        <CinematicOverlay
          cinematicId={activeCinematic}
          endingId={activeEnding}
          progress={progressRef.current}
          lang={lang}
          onFinishCinematic={() => {
            setActiveCinematic(null);
            setScreenMode('playing');
            engineRef.current?.setMode('playing');
          }}
          onReturnToTitle={() => {
            setActiveEnding(null);
            setActiveCinematic(null);
            setScreenMode('title');
            engineRef.current?.setMode('title');
          }}
        />
      )}

      {/* Game Over Screen */}
      {screenMode === 'gameover' && (
        <div
          dir={isUr ? 'rtl' : 'ltr'}
          className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#060305]/95 p-6 text-center space-y-5 ${isUr ? 'font-urdu' : ''}`}
        >
          <h1 className="text-3xl sm:text-4xl font-display font-black tracking-widest text-rose-500">
            {t(lang, 'youDied')}
          </h1>
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={handleContinue}
              className="px-6 py-3 bg-rose-800 hover:bg-rose-700 border border-rose-500 text-sm font-semibold text-white cursor-pointer"
            >
              {t(lang, 'tryAgain')}
            </button>
            <button
              type="button"
              onClick={() => {
                setScreenMode('title');
                engineRef.current?.setMode('title');
              }}
              className="px-6 py-3 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-sm text-zinc-200 cursor-pointer"
            >
              {t(lang, 'exitToTitle')}
            </button>
          </div>
        </div>
      )}

      {/* Landscape Orientation Prompt on Portrait Mobile Devices */}
      {isPortraitMobile && !dismissPortraitWarn && (
        <div
          dir={isUr ? 'rtl' : 'ltr'}
          className={`fixed inset-0 z-[60] flex flex-col items-center justify-center bg-[#050609]/96 p-6 text-center space-y-4 ${isUr ? 'font-urdu' : ''}`}
        >
          <img
            src="/assets/aistudio/Haunted_Dimensions__Blood_Moon_Manor_889d9a7a.png"
            alt="DIMENSIONS"
            className="w-full max-w-sm aspect-video object-cover border border-rose-800/60"
          />
          <h2 className="text-lg font-display font-bold tracking-widest text-rose-400">
            {isUr ? 'براہ کرم فون کو لینڈ اسکیپ میں گھمائیں' : 'ROTATE DEVICE TO LANDSCAPE'}
          </h2>
          <p className="text-xs text-zinc-400 max-w-xs">
            {isUr
              ? 'بہترین تھری ڈی ہارر تجربے اور ٹچ کنٹرولز کے لیے لینڈ اسکیپ موڈ ضروری ہے۔'
              : 'DIMENSIONS is built for widescreen landscape play and dual-thumb controls.'}
          </p>
          <button
            type="button"
            onClick={() => {
              tryLockLandscape();
              setDismissPortraitWarn(true);
            }}
            className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-300 cursor-pointer"
          >
            {isUr ? 'پھر بھی جاری رکھیں' : 'Continue Anyway'}
          </button>
        </div>
      )}
    </div>
  );
}
